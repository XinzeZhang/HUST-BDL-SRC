﻿Public Class Form2
    Dim CardReceiveData(2048, 7) As Byte
    Dim lin_CardReceiveData As Integer
    Dim Row_CardReceiveData As Integer
    Dim CardLocationDatabase(2048, 8) As Byte
    Dim CardLocationDatabase_row As Integer
    Dim CardReceiveTime(2048) As String

    Dim display_area_00 As Long = 0          '------Coordinator所在区域，地址永远为0
    Dim display_area_01 As Long = &H101          '------将Router的自定义地址设定到对应的显示区域，地址为&H0001的Router在diaplay_area_01显示区域
    Dim display_area_02 As Long = &H102
    Dim display_area_03 As Long = &H103
    Dim display_area_04 As Long = &H201    '------显示区display_area_04的读卡器地址为 &H201

    Dim display_area_05 As Long = &H101
    Dim display_area_06 As Long = &H102
    Dim display_area_07 As Long = &H103
    Dim display_area_08 As Long = &H104
    Dim display_area_09 As Long = &H201
    Dim display_area_10 As Long = &H202
    Dim display_area_11 As Long = &H203
    Dim display_area_12 As Long = &H204
    Dim display_area_13 As Long = &H205
    Dim display_area_14 As Long = &H206

    Dim currentImage As Byte = 1
    Dim currentImage_count As Byte = 1

    Dim cardnumbers_area01 As Integer, cardnumbers_area02, cardnumbers_area03, cardnumbers_area04, cardnumbers_area00
    Dim cardnumbers_area05 As Integer, cardnumbers_area06, cardnumbers_area07, cardnumbers_area08, cardnumbers_area09, cardnumbers_area10, cardnumbers_area11, cardnumbers_area12, cardnumbers_area13, cardnumbers_area14


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Button1.Text = "连接模块" Then

            If ComboBox1.Text = "" Then
                Label3.Text = "请选择串口"
                Label2.Text = "------"
            Else
                Try
                    Button1.Text = "断开模块"
                    MyComPort.PortName = ComboBox1.Text
                    Label3.Text = "串口已打开"
                    Label2.Text = "波特率=38400"
                    OvalShape1.FillColor = Color.Green

                    MyComPort.BaudRate = 38400
                    MyComPort.ReceivedBytesThreshold = 8
                    MyComPort.Open()

                    Me.Timer1.Interval = 3000
                    Me.Timer1.Enabled = True


                    'Call SendInstruction(Instruction_Item)
                Catch ex As Exception
                    Label3.Text = "选择串口错误"
                    Label2.Text = "------"
                    Button1.Text = "连接模块"
                End Try

            End If


        Else
            Button1.Text = "连接模块"

            OvalShape1.FillColor = Color.Gray
            Label3.Text = "连接已断开"
            Label2.Text = "---------"
            Timer1.Enabled = False

            Try
                MyComPort.Close()
            Catch ex As Exception
                Button1.Text = "断开模块"
                MyComPort.PortName = ComboBox1.Text
                Label3.Text = "串口已打开"
                Label2.Text = "波特率=38400"
                OvalShape1.FillColor = Color.Green
            End Try

        End If
    End Sub


    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim MyComPort_Names As String()
        Dim MyComPort_Name As String

        MyComPort_Names = IO.Ports.SerialPort.GetPortNames()

        For Each MyComPort_Name In MyComPort_Names
            ComboBox1.Items.Add(MyComPort_Name)
        Next

        '-------显示各个显示区域读卡器的地址-----------------
        Dim temp_display(1) As Byte
        Dim k As Byte

        temp_display(0) = display_area_01 \ &H100
        temp_display(1) = display_area_01 And &HFF
        TextBox11.Text = ""
        For k = 0 To 1 Step 1
            If temp_display(k) <= &HF Then
                TextBox11.Text = TextBox11.Text + "0" + Hex(temp_display(k)) + " "
            Else
                TextBox11.Text = TextBox11.Text + Hex(temp_display(k)) + " "
            End If
        Next

        temp_display(0) = display_area_02 \ &H100
        temp_display(1) = display_area_02 And &HFF
        TextBox12.Text = ""
        For k = 0 To 1 Step 1
            If temp_display(k) <= &HF Then
                TextBox12.Text = TextBox12.Text + "0" + Hex(temp_display(k)) + " "
            Else
                TextBox12.Text = TextBox12.Text + Hex(temp_display(k)) + " "
            End If
        Next

        temp_display(0) = display_area_03 \ &H100
        temp_display(1) = display_area_03 And &HFF
        TextBox13.Text = ""
        For k = 0 To 1 Step 1
            If temp_display(k) <= &HF Then
                TextBox13.Text = TextBox13.Text + "0" + Hex(temp_display(k)) + " "
            Else
                TextBox13.Text = TextBox13.Text + Hex(temp_display(k)) + " "
            End If
        Next

        temp_display(0) = display_area_04 \ &H100
        temp_display(1) = display_area_04 And &HFF
        TextBox14.Text = ""
        For k = 0 To 1 Step 1
            If temp_display(k) <= &HF Then
                TextBox14.Text = TextBox14.Text + "0" + Hex(temp_display(k)) + " "
            Else
                TextBox14.Text = TextBox14.Text + Hex(temp_display(k)) + " "
            End If
        Next

        lin_CardReceiveData = 0
        Row_CardReceiveData = 0
        CardLocationDatabase_row = 0

        Count_text_box_disview()   '-----不显示第5张图上的统计数字

    End Sub


    Private Sub MyComPort_DataReceived(ByVal sender As System.Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles MyComPort.DataReceived

        '-------------------
        Dim i As Byte
        Dim m As Integer, a

        m = MyComPort.BytesToRead \ 8

        For a = 1 To m
            For i = 0 To 7
                Try
                    CardReceiveData(lin_CardReceiveData, i) = MyComPort.ReadByte
                Catch ex As Exception
                    GoTo receive_end
                End Try

            Next
            lin_CardReceiveData = lin_CardReceiveData + 1
        Next

        'MyComPort.DiscardInBuffer()

receive_end:
        MyComPort.DiscardInBuffer()   '-----清除接收区Buffer

    End Sub

    '----- 每隔一段时间（2S），整理数据 ----------------
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim i As Integer, j, n
        Dim temp_receive_data(1024, 7) As Byte
        Dim temp_lin As Integer
        Dim temp_XY As Integer
        Dim data_XY As Byte

        Dim temp_CardNumber As Long, CardNumbetinDatabase
        Dim temp_count As Byte = 0
        Dim replace_status As Byte

        replace_status = 0

        If lin_CardReceiveData >= 1 Then                              '---------是否有数据，如果有，lin_CardReceiveData >= 1，将接收到的数据比较后，写入到卡片数据区
            temp_lin = lin_CardReceiveData - 1

            For i = 0 To lin_CardReceiveData - 1 Step 1
                For j = 0 To 7
                    temp_receive_data(i, j) = CardReceiveData(i, j)
                Next
            Next
            lin_CardReceiveData = 0

            For i = 0 To temp_lin                                     '----------逐条比较
                replace_status = 0                                    '----------数据替换标志清0，开始时

                temp_XY = 0                                           '----------计算效验和
                For j = 0 To 6 Step 1
                    temp_XY = temp_XY + temp_receive_data(i, j)
                Next
                data_XY = temp_XY And &HFF

                If temp_receive_data(i, 0) = &HFA And data_XY = temp_receive_data(i, 7) Then   '-----数据包是否正确：第一个字节为FA 及 效验和

                    If CardLocationDatabase_row = 0 Then                              '---如果是第一行数据

                        CardLocationDatabase_row = CardLocationDatabase_row + 1       '-----卡片数据区指针加1
                        For j = 0 To 7                                                '-----数据写入卡片数据区
                            CardLocationDatabase(0, j) = temp_receive_data(0, j)
                        Next
                        CardReceiveTime(0) = TimeString                               '-----记录收到数据的时间
                    Else                                                              '-----不是第一行数据，则逐行比较，找出相同卡号
                        For n = 0 To CardLocationDatabase_row - 1 Step 1
                            temp_CardNumber = temp_receive_data(i, 2) * 256 + temp_receive_data(i, 3)                  '---收到数据的卡号   Card Number------------------
                            CardNumbetinDatabase = CardLocationDatabase(n, 2) * 256 + CardLocationDatabase(n, 3)       '---存在数据区的卡号 CardNumber in Database ------
                            If temp_CardNumber = CardNumbetinDatabase Then            '----找到相同的卡号，数据被替换
                                For j = 0 To 7
                                    CardLocationDatabase(n, j) = temp_receive_data(i, j)
                                Next
                                replace_status = 1                                   '----写替换数据标志
                                CardLocationDatabase(n, 8) = 0                       '----写数据更新标志
                                CardReceiveTime(n) = TimeString                      '-----记录收到数据的时间
                            End If
                        Next
                        If replace_status <> 1 Then                                  '----数据没有被替换，即没有找到相同的卡号
                            For j = 0 To 7
                                CardLocationDatabase(CardLocationDatabase_row, j) = temp_receive_data(i, j)     '----将数据添加到最后
                            Next
                            CardLocationDatabase(CardLocationDatabase_row, 8) = 0    '----写数据更新标志
                            CardReceiveTime(n) = TimeString                          '-----记录收到数据的时间
                            CardLocationDatabase_row = CardLocationDatabase_row + 1
                        End If
                    End If

                End If
            Next
        End If

        DataGridView1.Rows.Clear()                                              '------清除数据表显示

        PictureBox1.Image = New Bitmap(PictureBox1.Width, PictureBox1.Height)   '------清除图形显示
        Dim aClear As Graphics = Graphics.FromImage(PictureBox1.Image)
        aClear.Clear(Color.Transparent)
        aClear.Dispose()

        TextBox15.Text = ""                  '---------清除统计区显示
        TextBox16.Text = ""
        TextBox17.Text = ""
        TextBox18.Text = ""
        TextBox19.Text = ""

        Timer2.Interval = 10
        Timer2.Enabled = True

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim text_01 As String, text_02, text_03, text_04
        Dim i As Integer

        Timer2.Enabled = False

        For i = 0 To CardLocationDatabase_row
            If CardLocationDatabase(i, 8) <= 10 Then         '-----‘防止数据溢出
                CardLocationDatabase(i, 8) = CardLocationDatabase(i, 8) + 1
            End If

            If CardLocationDatabase(i, 8) >= 7 Then          '------几个周期(n-1)没有更新，没有收到数据，则认为该卡离开
                CardLocationDatabase(i, 0) = 0               '------清除这条记录，将数据头清除了，这条记录（卡号）还是存在
            End If
        Next


        '----显示数据--------------------------------
        For i = 0 To CardLocationDatabase_row
            If CardLocationDatabase(i, 0) = &HFA Then
                text_01 = ""                                                    '--------第一列
                For m = 1 To 3
                    If CardLocationDatabase(i, m) <= &HF Then
                        text_01 = text_01 + "0" + Hex(CardLocationDatabase(i, m)) + " "
                    Else
                        text_01 = text_01 + Hex(CardLocationDatabase(i, m)) + " "
                    End If
                Next

                text_02 = ""                                             '------------第二列
                If CardLocationDatabase(i, 4) <= &HF Then
                    text_02 = text_02 + "0" + Hex(CardLocationDatabase(i, 4)) + " "
                Else
                    text_02 = text_02 + Hex(CardLocationDatabase(i, 4)) + " "
                End If

                text_03 = ""                                             '-----------第三列
                For m = 5 To 6
                    If CardLocationDatabase(i, m) <= &HF Then
                        text_03 = text_03 + "0" + Hex(CardLocationDatabase(i, m)) + " "
                    Else
                        text_03 = text_03 + Hex(CardLocationDatabase(i, m)) + " "
                    End If
                Next

                text_04 = ""                                            '-----------第四列，显示时间
                'text_04 = TimeString
                text_04 = CardReceiveTime(i)

                Dim row As String() = {text_01, text_02, text_03, text_04}

                With Me.DataGridView1.Rows                '---------添加显示
                    .Add(row)
                End With
            End If
        Next

        '---------显示图形----------------------------------
        PictureBox1.Image = New Bitmap(PictureBox1.Width, PictureBox1.Height)
        Dim settingCardPosition As Graphics = Graphics.FromImage(PictureBox1.Image)
        Dim redBrush As New SolidBrush(Color.Red)
        Dim greenBrush As New SolidBrush(Color.Green)
        Dim grayBrush As New SolidBrush(Color.Gray)
        Dim temp_card_position As Long
        Dim offset As Byte, temp_offset
        Dim aa1 As Point
        Dim card_position_base As Point
        Dim card_distance As Byte

        cardnumbers_area00 = 0

        cardnumbers_area01 = 0
        cardnumbers_area02 = 0
        cardnumbers_area03 = 0
        cardnumbers_area04 = 0

        cardnumbers_area05 = 0
        cardnumbers_area06 = 0
        cardnumbers_area07 = 0
        cardnumbers_area08 = 0
        cardnumbers_area09 = 0
        cardnumbers_area10 = 0
        cardnumbers_area11 = 0
        cardnumbers_area12 = 0
        cardnumbers_area13 = 0
        cardnumbers_area14 = 0


        If currentImage = 1 Then   '------第一张地图显示-------------------------------------------
            For i = 0 To CardLocationDatabase_row
                If CardLocationDatabase(i, 0) = &HFA Then

                    temp_card_position = CardLocationDatabase(i, 5) * 256 + CardLocationDatabase(i, 6)    '-----卡片所在区域

                    If CardLocationDatabase(i, 4) = &HFE Or CardLocationDatabase(i, 4) = &HFF Then    '-----如果收到报警信息（低电压（FF)、手动报警(FE)），则显示在50这个地方，分不同的颜色
                        card_distance = 10
                    Else
                        card_distance = 120 - CardLocationDatabase(i, 4)
                    End If


                    temp_offset = Int(Rnd() * 100) + 1
                    offset = Int(Rnd() * 10)

                    Select Case temp_card_position          '-----确定在哪个区域，设定基准点坐标
                        Case display_area_00
                            card_position_base.X = 600
                            card_position_base.Y = 300
                            cardnumbers_area00 = cardnumbers_area00 + 1

                        Case display_area_01
                            card_position_base.X = 40
                            card_position_base.Y = 40
                            cardnumbers_area01 = cardnumbers_area01 + 1

                        Case display_area_02
                            card_position_base.X = 300
                            card_position_base.Y = 40
                            cardnumbers_area02 = cardnumbers_area02 + 1

                        Case display_area_03
                            card_position_base.X = 40
                            card_position_base.Y = 300
                            cardnumbers_area03 = cardnumbers_area03 + 1

                        Case display_area_04
                            card_position_base.X = 300
                            card_position_base.Y = 300
                            cardnumbers_area04 = cardnumbers_area04 + 1

                        Case Else                                    '---------如果对应的读卡器没在地图上，则显示在（600，100）
                            card_position_base.X = 600
                            card_position_base.Y = 100
                            cardnumbers_area00 = cardnumbers_area00 + 1

                    End Select

                    If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                        aa1.X = card_position_base.X + offset + card_distance    '----加入相对距离 card_distance
                        aa1.Y = card_position_base.Y - offset + card_distance
                    Else
                        aa1.X = card_position_base.X - offset + card_distance
                        aa1.Y = card_position_base.Y + offset + card_distance
                    End If

                    Dim rect As New Rectangle(aa1.X, aa1.Y, 13, 13)              '-----标出定位点
                    Select Case CardLocationDatabase(i, 4)
                        Case &HFE
                            settingCardPosition.FillEllipse(redBrush, rect)
                        Case &HFF
                            settingCardPosition.FillEllipse(grayBrush, rect)
                        Case Else
                            settingCardPosition.FillEllipse(greenBrush, rect)
                    End Select

                End If
            Next
        End If

        If currentImage = 2 Then '------第二张地图显示----------------------------------------
            For i = 0 To CardLocationDatabase_row
                If CardLocationDatabase(i, 0) = &HFA Then

                    temp_card_position = CardLocationDatabase(i, 5) * 256 + CardLocationDatabase(i, 6)    '-----卡片所在区域
                    If CardLocationDatabase(i, 4) = &HFE Or CardLocationDatabase(i, 4) = &HFF Then    '-----如果收到报警信息（低电压（FF)、手动报警(FE)），则显示在50这个地方，分不同的颜色
                        card_distance = 10
                    Else
                        card_distance = 120 - CardLocationDatabase(i, 4)
                    End If
                    temp_offset = Int(Rnd() * 100) + 1
                    offset = Int(Rnd() * 5)

                    Select Case temp_card_position          '-----确定在哪个区域，设定基准点坐标
                        Case display_area_00
                            card_position_base.X = 600
                            card_position_base.Y = 300
                            cardnumbers_area00 = cardnumbers_area00 + 1

                        Case display_area_01
                            card_position_base.X = 120
                            card_position_base.Y = 180
                            cardnumbers_area01 = cardnumbers_area01 + 1

                        Case display_area_02
                            card_position_base.X = 360
                            card_position_base.Y = 150
                            cardnumbers_area02 = cardnumbers_area02 + 1

                        Case display_area_03
                            card_position_base.X = 120
                            card_position_base.Y = 360
                            cardnumbers_area03 = cardnumbers_area03 + 1

                        Case display_area_04
                            card_position_base.X = 360
                            card_position_base.Y = 360
                            cardnumbers_area04 = cardnumbers_area04 + 1

                        Case Else                                  '---------如果对应的读卡器没在地图上，则显示在（600，100）
                            card_position_base.X = 600
                            card_position_base.Y = 100
                            cardnumbers_area00 = cardnumbers_area00 + 1
                    End Select

                    If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                        aa1.X = card_position_base.X + offset + card_distance    '----加入相对距离 card_distance
                        aa1.Y = card_position_base.Y - offset
                    Else
                        aa1.X = card_position_base.X - offset + card_distance
                        aa1.Y = card_position_base.Y + offset
                    End If

                    Dim rect As New Rectangle(aa1.X, aa1.Y, 13, 13)              '-----标出定位点
                    Select Case CardLocationDatabase(i, 4)
                        Case &HFE
                            settingCardPosition.FillEllipse(redBrush, rect)
                        Case &HFF
                            settingCardPosition.FillEllipse(grayBrush, rect)
                        Case Else
                            settingCardPosition.FillEllipse(greenBrush, rect)
                    End Select
                End If
            Next
        End If

        If currentImage = 3 Then   '------第三张地图显示-----------------------------------------------
            For i = 0 To CardLocationDatabase_row
                If CardLocationDatabase(i, 0) = &HFA Then

                    temp_card_position = CardLocationDatabase(i, 5) * 256 + CardLocationDatabase(i, 6)    '-----卡片所在区域
                    If CardLocationDatabase(i, 4) = &HFE Or CardLocationDatabase(i, 4) = &HFF Then    '-----如果收到报警信息（低电压（FF)、手动报警(FE)），则显示在50这个地方，分不同的颜色
                        card_distance = 10
                    Else
                        card_distance = 120 - CardLocationDatabase(i, 4)
                    End If
                    temp_offset = Int(Rnd() * 100) + 1
                    offset = Int(Rnd() * 10) + 20

                    Select Case temp_card_position          '-----确定在哪个区域，设定基准点坐标
                        Case display_area_00
                            card_position_base.X = 600
                            card_position_base.Y = 300

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + card_distance + offset            '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset + card_distance
                            Else
                                aa1.X = card_position_base.X + card_distance - offset
                                aa1.Y = card_position_base.Y + offset + card_distance
                            End If
                            cardnumbers_area00 = cardnumbers_area00 + 1

                        Case display_area_01
                            card_position_base.X = 200
                            card_position_base.Y = 220

                            cardnumbers_area01 = cardnumbers_area01 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X - card_distance             '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset
                            Else
                                aa1.X = card_position_base.X - card_distance
                                aa1.Y = card_position_base.Y + offset
                            End If

                        Case display_area_02
                            card_position_base.X = 300
                            card_position_base.Y = 220

                            cardnumbers_area02 = cardnumbers_area02 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + card_distance             '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset
                            Else
                                aa1.X = card_position_base.X + card_distance
                                aa1.Y = card_position_base.Y + offset
                            End If

                        Case Else                             '---------如果对应的读卡器没在地图上，则显示在（600，100）
                            card_position_base.X = 600
                            card_position_base.Y = 100

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + card_distance             '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y + card_distance + offset
                            Else
                                aa1.X = card_position_base.X + card_distance
                                aa1.Y = card_position_base.Y + card_distance - offset
                            End If

                            cardnumbers_area00 = cardnumbers_area00 + 1

                    End Select

                    Dim rect As New Rectangle(aa1.X, aa1.Y, 13, 13)              '-----标出定位点
                    Select Case CardLocationDatabase(i, 4)
                        Case &HFE
                            settingCardPosition.FillEllipse(redBrush, rect)
                        Case &HFF
                            settingCardPosition.FillEllipse(grayBrush, rect)
                        Case Else
                            settingCardPosition.FillEllipse(greenBrush, rect)
                    End Select
                End If
            Next
        End If


        If currentImage = 4 Then    '------第四张地图显示--------------------------------------------------------
            For i = 0 To CardLocationDatabase_row
                If CardLocationDatabase(i, 0) = &HFA Then

                    temp_card_position = CardLocationDatabase(i, 5) * 256 + CardLocationDatabase(i, 6)    '-----卡片所在区域
                    If CardLocationDatabase(i, 4) = &HFE Or CardLocationDatabase(i, 4) = &HFF Then    '-----如果收到报警信息（低电压（FF)、手动报警(FE)），则显示在50这个地方，分不同的颜色
                        card_distance = 10
                    Else
                        card_distance = 120 - CardLocationDatabase(i, 4)
                    End If
                    temp_offset = Int(Rnd() * 100) + 1
                    offset = Int(Rnd() * 10)

                    Select Case temp_card_position          '-----确定在哪个区域，设定基准点坐标
                        Case display_area_00                '-----Coordinator所在的区域
                            card_position_base.X = 600
                            card_position_base.Y = 300
                            cardnumbers_area00 = cardnumbers_area00 + 1

                        Case display_area_01                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 260
                            card_position_base.Y = 220
                            cardnumbers_area01 = cardnumbers_area01 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + offset - card_distance - 100    '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset - card_distance - 100
                            Else
                                aa1.X = card_position_base.X - offset - card_distance - 100
                                aa1.Y = card_position_base.Y + offset - card_distance - 100
                            End If

                        Case display_area_02                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 260
                            card_position_base.Y = 220
                            cardnumbers_area02 = cardnumbers_area02 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + offset + card_distance + 100   '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset - card_distance - 100
                            Else
                                aa1.X = card_position_base.X - offset + card_distance + 100
                                aa1.Y = card_position_base.Y + offset - card_distance - 100
                            End If

                        Case display_area_03                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 260
                            card_position_base.Y = 220
                            cardnumbers_area03 = cardnumbers_area03 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + offset - card_distance - 100   '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset + card_distance + 100
                            Else
                                aa1.X = card_position_base.X - offset - card_distance - 100
                                aa1.Y = card_position_base.Y + offset + card_distance + 100
                            End If

                        Case display_area_04                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 260
                            card_position_base.Y = 220
                            cardnumbers_area04 = cardnumbers_area04 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + offset + card_distance + 100    '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset + card_distance + 100
                            Else
                                aa1.X = card_position_base.X - offset + card_distance + 100
                                aa1.Y = card_position_base.Y + offset + card_distance + 100
                            End If

                        Case Else                             '---------如果对应的读卡器没在地图上，则显示在（600，100）
                            card_position_base.X = 600        '----加入相对距离 card_distance
                            card_position_base.Y = 100

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + card_distance    '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y + card_distance + offset
                            Else
                                aa1.X = card_position_base.X + card_distance
                                aa1.Y = card_position_base.Y + card_distance - offset
                            End If
                            cardnumbers_area00 = cardnumbers_area00 + 1

                    End Select

                    Dim rect As New Rectangle(aa1.X, aa1.Y, 13, 13)              '-----标出定位点
                    Select Case CardLocationDatabase(i, 4)
                        Case &HFE
                            settingCardPosition.FillEllipse(redBrush, rect)
                        Case &HFF
                            settingCardPosition.FillEllipse(grayBrush, rect)
                        Case Else
                            settingCardPosition.FillEllipse(greenBrush, rect)
                    End Select
                End If
            Next
        End If


        If currentImage = 5 Then    '------第五张地图显示--------------------------------------------------------
            For i = 0 To CardLocationDatabase_row
                If CardLocationDatabase(i, 0) = &HFA Then
                    temp_card_position = CardLocationDatabase(i, 5) * 256 + CardLocationDatabase(i, 6)    '-----卡片所在区域
                    If CardLocationDatabase(i, 4) = &HFE Or CardLocationDatabase(i, 4) = &HFF Then    '-----如果收到报警信息（低电压（FF)、手动报警(FE)），则显示在50这个地方，分不同的颜色
                        card_distance = 10
                    Else
                        card_distance = 120 - CardLocationDatabase(i, 4)
                    End If

                    temp_offset = Int(Rnd() * 100) + 1
                    offset = Int(Rnd() * 10)

                    Select Case temp_card_position          '-----确定在哪个区域，设定基准点坐标
                        Case display_area_00                '-----Coordinator所在的区域
                            card_position_base.X = 600
                            card_position_base.Y = 300

                        Case display_area_05                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 120
                            card_position_base.Y = 50
                            cardnumbers_area05 = cardnumbers_area05 + 1

                            aa1.Y = card_position_base.Y + card_distance

                        Case display_area_06                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 168
                            card_position_base.Y = 50
                            cardnumbers_area06 = cardnumbers_area06 + 1

                            aa1.Y = card_position_base.Y + card_distance

                            '-------未完成
                        Case display_area_03                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 260
                            card_position_base.Y = 220
                            cardnumbers_area03 = cardnumbers_area03 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + offset - card_distance - 100   '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset + card_distance + 100
                            Else
                                aa1.X = card_position_base.X - offset - card_distance - 100
                                aa1.Y = card_position_base.Y + offset + card_distance + 100
                            End If

                        Case display_area_04                '-----基准坐标点设在4个读卡器的中心
                            card_position_base.X = 260
                            card_position_base.Y = 220
                            cardnumbers_area04 = cardnumbers_area04 + 1

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + offset + card_distance + 100    '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y - offset + card_distance + 100
                            Else
                                aa1.X = card_position_base.X - offset + card_distance + 100
                                aa1.Y = card_position_base.Y + offset + card_distance + 100
                            End If

                        Case Else                             '---------如果对应的读卡器没在地图上，则显示在（600，100）
                            card_position_base.X = 600        '----加入相对距离 card_distance
                            card_position_base.Y = 100

                            If temp_offset > 50 Then                                     '--------随机摆动下，加强动态效果
                                aa1.X = card_position_base.X + card_distance    '----加入相对距离 card_distance
                                aa1.Y = card_position_base.Y + card_distance + offset
                            Else
                                aa1.X = card_position_base.X + card_distance
                                aa1.Y = card_position_base.Y + card_distance - offset
                            End If

                    End Select

                    Dim rect As New Rectangle(aa1.X, aa1.Y, 13, 13)              '-----标出定位点
                    Select Case CardLocationDatabase(i, 4)
                        Case &HFE
                            settingCardPosition.FillEllipse(redBrush, rect)
                        Case &HFF
                            settingCardPosition.FillEllipse(grayBrush, rect)
                        Case Else
                            settingCardPosition.FillEllipse(greenBrush, rect)
                    End Select

                End If
            Next
        End If

        'cardnumbers_area00 = 0
        'cardnumbers_area05 = 0
        'cardnumbers_area06 = 0
        'cardnumbers_area07 = 0
        'cardnumbers_area08 = 0
        'cardnumbers_area09 = 0
        'cardnumbers_area10 = 0

        settingCardPosition.Dispose()

        '---------------显示统计数----------------------
        TextBox15.Text = Str(cardnumbers_area01 + cardnumbers_area02 + cardnumbers_area03 + cardnumbers_area04 + cardnumbers_area00)
        TextBox16.Text = Str(cardnumbers_area01)
        TextBox17.Text = Str(cardnumbers_area02)
        TextBox18.Text = Str(cardnumbers_area03)
        TextBox19.Text = Str(cardnumbers_area04)

        TextBox31.Text = Str(cardnumbers_area05)
        TextBox32.Text = Str(cardnumbers_area06)
        TextBox33.Text = Str(cardnumbers_area09)
        TextBox34.Text = Str(cardnumbers_area10)
        TextBox35.Text = Str(cardnumbers_area11)
        TextBox36.Text = Str(cardnumbers_area07)
        TextBox37.Text = Str(cardnumbers_area08)
        TextBox38.Text = Str(cardnumbers_area12)
        TextBox39.Text = Str(cardnumbers_area13)
        TextBox40.Text = Str(cardnumbers_area14)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        currentImage_count += 1
        Select Case currentImage_count
            Case 1
                currentImage = 1
                Count_text_box_disview()
                'PictureBox1.BackgroundImage = Image.FromFile("D:\360云盘\DTK Zigbee Configure V61\DTK APPLICATION COM\Pic\location-01.jpg")
                PictureBox1.BackgroundImage = Image.FromFile(Application.StartupPath & "\Pic\location01.jpg")

            Case 2
                currentImage = 2
                Count_text_box_disview()
                'PictureBox1.BackgroundImage = Image.FromFile("D:\360云盘\DTK Zigbee Configure V61\DTK APPLICATION COM\Pic\location-02.jpg")
                PictureBox1.BackgroundImage = Image.FromFile(Application.StartupPath & "\Pic\location02.jpg")
            Case 3
                currentImage = 3
                Count_text_box_disview()
                'PictureBox1.BackgroundImage = Image.FromFile("D:\360云盘\DTK Zigbee Configure V61\DTK APPLICATION COM\Pic\location-03.jpg")
                PictureBox1.BackgroundImage = Image.FromFile(Application.StartupPath & "\Pic\location03.jpg")
            Case 4
                currentImage = 4
                Count_text_box_disview()
                'PictureBox1.BackgroundImage = Image.FromFile("D:\360云盘\DTK Zigbee Configure V61\DTK APPLICATION COM\Pic\location-04.jpg")
                PictureBox1.BackgroundImage = Image.FromFile(Application.StartupPath & "\Pic\location04.jpg")
            Case 5
                currentImage = 5
                Count_text_box_view()
                PictureBox1.BackgroundImage = Image.FromFile(Application.StartupPath & "\Pic\location05.jpg")
        End Select

        If currentImage_count >= 5 Then
            currentImage_count = 0
        End If

        PictureBox1.Image = New Bitmap(PictureBox1.Width, PictureBox1.Height)   '------清除图形显示
        Dim aClear As Graphics = Graphics.FromImage(PictureBox1.Image)
        aClear.Clear(Color.Transparent)
        aClear.Dispose()

    End Sub

    Private Sub Count_text_box_view()
        TextBox31.Visible = True
        TextBox32.Visible = True
        TextBox33.Visible = True
        TextBox34.Visible = True
        TextBox35.Visible = True
        TextBox36.Visible = True
        TextBox37.Visible = True
        TextBox38.Visible = True
        TextBox39.Visible = True
        TextBox40.Visible = True
    End Sub

    Private Sub Count_text_box_disview()
        TextBox31.Visible = False
        TextBox32.Visible = False
        TextBox33.Visible = False
        TextBox34.Visible = False
        TextBox35.Visible = False
        TextBox36.Visible = False
        TextBox37.Visible = False
        TextBox38.Visible = False
        TextBox39.Visible = False
        TextBox40.Visible = False
    End Sub

    Private Sub Form2_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        MyComPort.Close()
    End Sub


End Class


