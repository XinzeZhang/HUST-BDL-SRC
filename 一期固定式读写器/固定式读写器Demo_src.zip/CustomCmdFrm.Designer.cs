﻿namespace ModuleReaderManager
{
    partial class CustomCmdFrm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnResetReadProtect = new System.Windows.Forms.Button();
            this.btnSetReadProtect = new System.Windows.Forms.Button();
            this.labEASAlert = new System.Windows.Forms.Label();
            this.btnEASDetect = new System.Windows.Forms.Button();
            this.tbEASAlarmData = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEASAlarm = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbEASset = new System.Windows.Forms.RadioButton();
            this.rbEASreset = new System.Windows.Forms.RadioButton();
            this.btnChangeEAS = new System.Windows.Forms.Button();
            this.tbaccesspasswd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbant4 = new System.Windows.Forms.RadioButton();
            this.rbant3 = new System.Windows.Forms.RadioButton();
            this.rbant2 = new System.Windows.Forms.RadioButton();
            this.rbant1 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cb8 = new System.Windows.Forms.CheckBox();
            this.cb7 = new System.Windows.Forms.CheckBox();
            this.cb6 = new System.Windows.Forms.CheckBox();
            this.cb5 = new System.Windows.Forms.CheckBox();
            this.cb4 = new System.Windows.Forms.CheckBox();
            this.cb3 = new System.Windows.Forms.CheckBox();
            this.cb2 = new System.Windows.Forms.CheckBox();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.btnbrl = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnsetimpinjqt = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.rbimpinjqtfarfield = new System.Windows.Forms.RadioButton();
            this.rbimpinjqtnearfiled = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rbimpinjqtmemprivate = new System.Windows.Forms.RadioButton();
            this.rbimpinjqtmempublic = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.rbimpinjqttemp = new System.Windows.Forms.RadioButton();
            this.rbimpinjqtperm = new System.Windows.Forms.RadioButton();
            this.groupbox7 = new System.Windows.Forms.GroupBox();
            this.rbimpinjwrite = new System.Windows.Forms.RadioButton();
            this.rbimpinjqtread = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.cbbfilterrule = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbfilteraddr = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbbfilterbank = new System.Windows.Forms.ComboBox();
            this.cbisfilter = new System.Windows.Forms.CheckBox();
            this.tbfldata = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbbnxpchiptype = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupbox7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cbbnxpchiptype);
            this.groupBox1.Controls.Add(this.btnResetReadProtect);
            this.groupBox1.Controls.Add(this.btnSetReadProtect);
            this.groupBox1.Controls.Add(this.labEASAlert);
            this.groupBox1.Controls.Add(this.btnEASDetect);
            this.groupBox1.Controls.Add(this.tbEASAlarmData);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnEASAlarm);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.btnChangeEAS);
            this.groupBox1.Location = new System.Drawing.Point(44, 191);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(452, 167);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "NXP";
            // 
            // btnResetReadProtect
            // 
            this.btnResetReadProtect.Location = new System.Drawing.Point(308, 120);
            this.btnResetReadProtect.Name = "btnResetReadProtect";
            this.btnResetReadProtect.Size = new System.Drawing.Size(126, 23);
            this.btnResetReadProtect.TabIndex = 12;
            this.btnResetReadProtect.Text = "ResetReadProtect";
            this.btnResetReadProtect.UseVisualStyleBackColor = true;
            this.btnResetReadProtect.Click += new System.EventHandler(this.btnResetReadProtect_Click);
            // 
            // btnSetReadProtect
            // 
            this.btnSetReadProtect.Location = new System.Drawing.Point(6, 120);
            this.btnSetReadProtect.Name = "btnSetReadProtect";
            this.btnSetReadProtect.Size = new System.Drawing.Size(126, 23);
            this.btnSetReadProtect.TabIndex = 11;
            this.btnSetReadProtect.Text = "SetReadProtect";
            this.btnSetReadProtect.UseVisualStyleBackColor = true;
            this.btnSetReadProtect.Click += new System.EventHandler(this.btnSetReadProtect_Click);
            // 
            // labEASAlert
            // 
            this.labEASAlert.AutoSize = true;
            this.labEASAlert.Location = new System.Drawing.Point(387, 39);
            this.labEASAlert.Name = "labEASAlert";
            this.labEASAlert.Size = new System.Drawing.Size(23, 12);
            this.labEASAlert.TabIndex = 10;
            this.labEASAlert.Text = "EAS";
            // 
            // btnEASDetect
            // 
            this.btnEASDetect.Location = new System.Drawing.Point(354, 77);
            this.btnEASDetect.Name = "btnEASDetect";
            this.btnEASDetect.Size = new System.Drawing.Size(80, 23);
            this.btnEASDetect.TabIndex = 9;
            this.btnEASDetect.Text = "EAS探测";
            this.btnEASDetect.UseVisualStyleBackColor = true;
            this.btnEASDetect.Click += new System.EventHandler(this.btnEASDetect_Click);
            // 
            // tbEASAlarmData
            // 
            this.tbEASAlarmData.Location = new System.Drawing.Point(187, 79);
            this.tbEASAlarmData.Name = "tbEASAlarmData";
            this.tbEASAlarmData.Size = new System.Drawing.Size(140, 21);
            this.tbEASAlarmData.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(113, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "EAS\r\nAlarmData";
            // 
            // btnEASAlarm
            // 
            this.btnEASAlarm.Location = new System.Drawing.Point(6, 79);
            this.btnEASAlarm.Name = "btnEASAlarm";
            this.btnEASAlarm.Size = new System.Drawing.Size(80, 23);
            this.btnEASAlarm.TabIndex = 4;
            this.btnEASAlarm.Text = "EASAlarm";
            this.btnEASAlarm.UseVisualStyleBackColor = true;
            this.btnEASAlarm.Click += new System.EventHandler(this.btnEASAlarm_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbEASset);
            this.groupBox2.Controls.Add(this.rbEASreset);
            this.groupBox2.Location = new System.Drawing.Point(92, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(109, 35);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "EASstate";
            // 
            // rbEASset
            // 
            this.rbEASset.AutoSize = true;
            this.rbEASset.Location = new System.Drawing.Point(10, 13);
            this.rbEASset.Name = "rbEASset";
            this.rbEASset.Size = new System.Drawing.Size(41, 16);
            this.rbEASset.TabIndex = 1;
            this.rbEASset.TabStop = true;
            this.rbEASset.Text = "set";
            this.rbEASset.UseVisualStyleBackColor = true;
            // 
            // rbEASreset
            // 
            this.rbEASreset.AutoSize = true;
            this.rbEASreset.Location = new System.Drawing.Point(51, 13);
            this.rbEASreset.Name = "rbEASreset";
            this.rbEASreset.Size = new System.Drawing.Size(53, 16);
            this.rbEASreset.TabIndex = 2;
            this.rbEASreset.TabStop = true;
            this.rbEASreset.Text = "reset";
            this.rbEASreset.UseVisualStyleBackColor = true;
            // 
            // btnChangeEAS
            // 
            this.btnChangeEAS.Location = new System.Drawing.Point(6, 37);
            this.btnChangeEAS.Name = "btnChangeEAS";
            this.btnChangeEAS.Size = new System.Drawing.Size(80, 23);
            this.btnChangeEAS.TabIndex = 0;
            this.btnChangeEAS.Text = "ChangeEAS";
            this.btnChangeEAS.UseVisualStyleBackColor = true;
            this.btnChangeEAS.Click += new System.EventHandler(this.btnChangeEAS_Click);
            // 
            // tbaccesspasswd
            // 
            this.tbaccesspasswd.Location = new System.Drawing.Point(157, 14);
            this.tbaccesspasswd.Name = "tbaccesspasswd";
            this.tbaccesspasswd.Size = new System.Drawing.Size(100, 21);
            this.tbaccesspasswd.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "访问密码";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbant4);
            this.groupBox3.Controls.Add(this.rbant3);
            this.groupBox3.Controls.Add(this.rbant2);
            this.groupBox3.Controls.Add(this.rbant1);
            this.groupBox3.Location = new System.Drawing.Point(44, 89);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(452, 48);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "天线选择";
            // 
            // rbant4
            // 
            this.rbant4.AutoSize = true;
            this.rbant4.Location = new System.Drawing.Point(373, 20);
            this.rbant4.Name = "rbant4";
            this.rbant4.Size = new System.Drawing.Size(53, 16);
            this.rbant4.TabIndex = 3;
            this.rbant4.TabStop = true;
            this.rbant4.Text = "天线4";
            this.rbant4.UseVisualStyleBackColor = true;
            // 
            // rbant3
            // 
            this.rbant3.AutoSize = true;
            this.rbant3.Location = new System.Drawing.Point(256, 20);
            this.rbant3.Name = "rbant3";
            this.rbant3.Size = new System.Drawing.Size(53, 16);
            this.rbant3.TabIndex = 2;
            this.rbant3.TabStop = true;
            this.rbant3.Text = "天线3";
            this.rbant3.UseVisualStyleBackColor = true;
            // 
            // rbant2
            // 
            this.rbant2.AutoSize = true;
            this.rbant2.Location = new System.Drawing.Point(142, 20);
            this.rbant2.Name = "rbant2";
            this.rbant2.Size = new System.Drawing.Size(53, 16);
            this.rbant2.TabIndex = 1;
            this.rbant2.TabStop = true;
            this.rbant2.Text = "天线2";
            this.rbant2.UseVisualStyleBackColor = true;
            // 
            // rbant1
            // 
            this.rbant1.AutoSize = true;
            this.rbant1.Location = new System.Drawing.Point(30, 20);
            this.rbant1.Name = "rbant1";
            this.rbant1.Size = new System.Drawing.Size(53, 16);
            this.rbant1.TabIndex = 0;
            this.rbant1.TabStop = true;
            this.rbant1.Text = "天线1";
            this.rbant1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.cb8);
            this.groupBox4.Controls.Add(this.cb7);
            this.groupBox4.Controls.Add(this.cb6);
            this.groupBox4.Controls.Add(this.cb5);
            this.groupBox4.Controls.Add(this.cb4);
            this.groupBox4.Controls.Add(this.cb3);
            this.groupBox4.Controls.Add(this.cb2);
            this.groupBox4.Controls.Add(this.cb1);
            this.groupBox4.Controls.Add(this.btnbrl);
            this.groupBox4.Location = new System.Drawing.Point(44, 367);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(452, 67);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "ALIEN Higgs3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(189, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 12);
            this.label4.TabIndex = 18;
            this.label4.Text = "1  2  3  4  5  6  7  8";
            // 
            // cb8
            // 
            this.cb8.AutoSize = true;
            this.cb8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb8.Location = new System.Drawing.Point(315, 23);
            this.cb8.Name = "cb8";
            this.cb8.Size = new System.Drawing.Size(12, 11);
            this.cb8.TabIndex = 17;
            this.cb8.UseVisualStyleBackColor = true;
            // 
            // cb7
            // 
            this.cb7.AutoSize = true;
            this.cb7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb7.Location = new System.Drawing.Point(297, 23);
            this.cb7.Name = "cb7";
            this.cb7.Size = new System.Drawing.Size(12, 11);
            this.cb7.TabIndex = 16;
            this.cb7.UseVisualStyleBackColor = true;
            // 
            // cb6
            // 
            this.cb6.AutoSize = true;
            this.cb6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb6.Location = new System.Drawing.Point(278, 23);
            this.cb6.Name = "cb6";
            this.cb6.Size = new System.Drawing.Size(12, 11);
            this.cb6.TabIndex = 15;
            this.cb6.UseVisualStyleBackColor = true;
            // 
            // cb5
            // 
            this.cb5.AutoSize = true;
            this.cb5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb5.Location = new System.Drawing.Point(261, 23);
            this.cb5.Name = "cb5";
            this.cb5.Size = new System.Drawing.Size(12, 11);
            this.cb5.TabIndex = 14;
            this.cb5.UseVisualStyleBackColor = true;
            // 
            // cb4
            // 
            this.cb4.AutoSize = true;
            this.cb4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb4.Location = new System.Drawing.Point(243, 23);
            this.cb4.Name = "cb4";
            this.cb4.Size = new System.Drawing.Size(12, 11);
            this.cb4.TabIndex = 13;
            this.cb4.UseVisualStyleBackColor = true;
            // 
            // cb3
            // 
            this.cb3.AutoSize = true;
            this.cb3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb3.Location = new System.Drawing.Point(225, 23);
            this.cb3.Name = "cb3";
            this.cb3.Size = new System.Drawing.Size(12, 11);
            this.cb3.TabIndex = 12;
            this.cb3.UseVisualStyleBackColor = true;
            // 
            // cb2
            // 
            this.cb2.AutoSize = true;
            this.cb2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb2.Location = new System.Drawing.Point(207, 23);
            this.cb2.Name = "cb2";
            this.cb2.Size = new System.Drawing.Size(12, 11);
            this.cb2.TabIndex = 11;
            this.cb2.UseVisualStyleBackColor = true;
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb1.Location = new System.Drawing.Point(189, 23);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(12, 11);
            this.cb1.TabIndex = 10;
            this.cb1.UseVisualStyleBackColor = true;
            // 
            // btnbrl
            // 
            this.btnbrl.Location = new System.Drawing.Point(6, 32);
            this.btnbrl.Name = "btnbrl";
            this.btnbrl.Size = new System.Drawing.Size(111, 23);
            this.btnbrl.TabIndex = 0;
            this.btnbrl.Text = "BlockReadLock";
            this.btnbrl.UseVisualStyleBackColor = true;
            this.btnbrl.Click += new System.EventHandler(this.btnbrl_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.tbaccesspasswd);
            this.groupBox5.Location = new System.Drawing.Point(44, 143);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(452, 42);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "标签参数";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnsetimpinjqt);
            this.groupBox6.Controls.Add(this.groupBox10);
            this.groupBox6.Controls.Add(this.groupBox9);
            this.groupBox6.Controls.Add(this.groupBox8);
            this.groupBox6.Controls.Add(this.groupbox7);
            this.groupBox6.Location = new System.Drawing.Point(44, 444);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(452, 125);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "IMPINJ Qt";
            // 
            // btnsetimpinjqt
            // 
            this.btnsetimpinjqt.Location = new System.Drawing.Point(359, 83);
            this.btnsetimpinjqt.Name = "btnsetimpinjqt";
            this.btnsetimpinjqt.Size = new System.Drawing.Size(75, 23);
            this.btnsetimpinjqt.TabIndex = 5;
            this.btnsetimpinjqt.Text = "设置";
            this.btnsetimpinjqt.UseVisualStyleBackColor = true;
            this.btnsetimpinjqt.Click += new System.EventHandler(this.btnsetimpinjqt_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.rbimpinjqtfarfield);
            this.groupBox10.Controls.Add(this.rbimpinjqtnearfiled);
            this.groupBox10.Location = new System.Drawing.Point(308, 20);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(126, 44);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "识别距离";
            // 
            // rbimpinjqtfarfield
            // 
            this.rbimpinjqtfarfield.AutoSize = true;
            this.rbimpinjqtfarfield.Location = new System.Drawing.Point(70, 20);
            this.rbimpinjqtfarfield.Name = "rbimpinjqtfarfield";
            this.rbimpinjqtfarfield.Size = new System.Drawing.Size(47, 16);
            this.rbimpinjqtfarfield.TabIndex = 5;
            this.rbimpinjqtfarfield.TabStop = true;
            this.rbimpinjqtfarfield.Text = "远场";
            this.rbimpinjqtfarfield.UseVisualStyleBackColor = true;
            // 
            // rbimpinjqtnearfiled
            // 
            this.rbimpinjqtnearfiled.AutoSize = true;
            this.rbimpinjqtnearfiled.Location = new System.Drawing.Point(6, 20);
            this.rbimpinjqtnearfiled.Name = "rbimpinjqtnearfiled";
            this.rbimpinjqtnearfiled.Size = new System.Drawing.Size(47, 16);
            this.rbimpinjqtnearfiled.TabIndex = 0;
            this.rbimpinjqtnearfiled.TabStop = true;
            this.rbimpinjqtnearfiled.Text = "近场";
            this.rbimpinjqtnearfiled.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rbimpinjqtmemprivate);
            this.groupBox9.Controls.Add(this.rbimpinjqtmempublic);
            this.groupBox9.Location = new System.Drawing.Point(146, 20);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(144, 44);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "内存视图";
            // 
            // rbimpinjqtmemprivate
            // 
            this.rbimpinjqtmemprivate.AutoSize = true;
            this.rbimpinjqtmemprivate.Location = new System.Drawing.Point(85, 20);
            this.rbimpinjqtmemprivate.Name = "rbimpinjqtmemprivate";
            this.rbimpinjqtmemprivate.Size = new System.Drawing.Size(47, 16);
            this.rbimpinjqtmemprivate.TabIndex = 5;
            this.rbimpinjqtmemprivate.TabStop = true;
            this.rbimpinjqtmemprivate.Text = "私密";
            this.rbimpinjqtmemprivate.UseVisualStyleBackColor = true;
            // 
            // rbimpinjqtmempublic
            // 
            this.rbimpinjqtmempublic.AutoSize = true;
            this.rbimpinjqtmempublic.Location = new System.Drawing.Point(15, 20);
            this.rbimpinjqtmempublic.Name = "rbimpinjqtmempublic";
            this.rbimpinjqtmempublic.Size = new System.Drawing.Size(47, 16);
            this.rbimpinjqtmempublic.TabIndex = 0;
            this.rbimpinjqtmempublic.TabStop = true;
            this.rbimpinjqtmempublic.Text = "公共";
            this.rbimpinjqtmempublic.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.rbimpinjqttemp);
            this.groupBox8.Controls.Add(this.rbimpinjqtperm);
            this.groupBox8.Location = new System.Drawing.Point(14, 70);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(133, 44);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "状态类型";
            // 
            // rbimpinjqttemp
            // 
            this.rbimpinjqttemp.AutoSize = true;
            this.rbimpinjqttemp.Location = new System.Drawing.Point(72, 20);
            this.rbimpinjqttemp.Name = "rbimpinjqttemp";
            this.rbimpinjqttemp.Size = new System.Drawing.Size(47, 16);
            this.rbimpinjqttemp.TabIndex = 1;
            this.rbimpinjqttemp.TabStop = true;
            this.rbimpinjqttemp.Text = "临时";
            this.rbimpinjqttemp.UseVisualStyleBackColor = true;
            // 
            // rbimpinjqtperm
            // 
            this.rbimpinjqtperm.AutoSize = true;
            this.rbimpinjqtperm.Location = new System.Drawing.Point(7, 20);
            this.rbimpinjqtperm.Name = "rbimpinjqtperm";
            this.rbimpinjqtperm.Size = new System.Drawing.Size(47, 16);
            this.rbimpinjqtperm.TabIndex = 0;
            this.rbimpinjqtperm.TabStop = true;
            this.rbimpinjqtperm.Text = "永久";
            this.rbimpinjqtperm.UseVisualStyleBackColor = true;
            // 
            // groupbox7
            // 
            this.groupbox7.Controls.Add(this.rbimpinjwrite);
            this.groupbox7.Controls.Add(this.rbimpinjqtread);
            this.groupbox7.Location = new System.Drawing.Point(14, 20);
            this.groupbox7.Name = "groupbox7";
            this.groupbox7.Size = new System.Drawing.Size(118, 44);
            this.groupbox7.TabIndex = 2;
            this.groupbox7.TabStop = false;
            this.groupbox7.Text = "命令类型";
            // 
            // rbimpinjwrite
            // 
            this.rbimpinjwrite.AutoSize = true;
            this.rbimpinjwrite.Location = new System.Drawing.Point(72, 20);
            this.rbimpinjwrite.Name = "rbimpinjwrite";
            this.rbimpinjwrite.Size = new System.Drawing.Size(35, 16);
            this.rbimpinjwrite.TabIndex = 1;
            this.rbimpinjwrite.TabStop = true;
            this.rbimpinjwrite.Text = "写";
            this.rbimpinjwrite.UseVisualStyleBackColor = true;
            // 
            // rbimpinjqtread
            // 
            this.rbimpinjqtread.AutoSize = true;
            this.rbimpinjqtread.Location = new System.Drawing.Point(15, 20);
            this.rbimpinjqtread.Name = "rbimpinjqtread";
            this.rbimpinjqtread.Size = new System.Drawing.Size(35, 16);
            this.rbimpinjqtread.TabIndex = 0;
            this.rbimpinjqtread.TabStop = true;
            this.rbimpinjqtread.Text = "读";
            this.rbimpinjqtread.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.cbbfilterrule);
            this.groupBox11.Controls.Add(this.label12);
            this.groupBox11.Controls.Add(this.tbfilteraddr);
            this.groupBox11.Controls.Add(this.label3);
            this.groupBox11.Controls.Add(this.label5);
            this.groupBox11.Controls.Add(this.cbbfilterbank);
            this.groupBox11.Controls.Add(this.cbisfilter);
            this.groupBox11.Controls.Add(this.tbfldata);
            this.groupBox11.Controls.Add(this.label6);
            this.groupBox11.Location = new System.Drawing.Point(44, 7);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(452, 76);
            this.groupBox11.TabIndex = 5;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "操作参数配置";
            // 
            // cbbfilterrule
            // 
            this.cbbfilterrule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbfilterrule.FormattingEnabled = true;
            this.cbbfilterrule.Items.AddRange(new object[] {
            "匹配",
            "不匹配"});
            this.cbbfilterrule.Location = new System.Drawing.Point(215, 18);
            this.cbbfilterrule.Name = "cbbfilterrule";
            this.cbbfilterrule.Size = new System.Drawing.Size(79, 20);
            this.cbbfilterrule.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(160, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "匹配规则";
            // 
            // tbfilteraddr
            // 
            this.tbfilteraddr.Location = new System.Drawing.Point(71, 18);
            this.tbfilteraddr.Name = "tbfilteraddr";
            this.tbfilteraddr.Size = new System.Drawing.Size(79, 21);
            this.tbfilteraddr.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 23;
            this.label3.Text = "起始地址";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(300, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 22;
            this.label5.Text = "过滤bank";
            // 
            // cbbfilterbank
            // 
            this.cbbfilterbank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbfilterbank.FormattingEnabled = true;
            this.cbbfilterbank.Items.AddRange(new object[] {
            "EPCbank",
            "TIDbank",
            "USERbank"});
            this.cbbfilterbank.Location = new System.Drawing.Point(359, 18);
            this.cbbfilterbank.Name = "cbbfilterbank";
            this.cbbfilterbank.Size = new System.Drawing.Size(79, 20);
            this.cbbfilterbank.TabIndex = 21;
            // 
            // cbisfilter
            // 
            this.cbisfilter.AutoSize = true;
            this.cbisfilter.Location = new System.Drawing.Point(342, 49);
            this.cbisfilter.Name = "cbisfilter";
            this.cbisfilter.Size = new System.Drawing.Size(96, 16);
            this.cbisfilter.TabIndex = 15;
            this.cbisfilter.Text = "启用数据过滤";
            this.cbisfilter.UseVisualStyleBackColor = true;
            // 
            // tbfldata
            // 
            this.tbfldata.Location = new System.Drawing.Point(71, 46);
            this.tbfldata.Name = "tbfldata";
            this.tbfldata.Size = new System.Drawing.Size(223, 21);
            this.tbfldata.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 6;
            this.label6.Text = "过滤数据";
            // 
            // cbbnxpchiptype
            // 
            this.cbbnxpchiptype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbnxpchiptype.FormattingEnabled = true;
            this.cbbnxpchiptype.Items.AddRange(new object[] {
            "G2X*",
            "G2i*"});
            this.cbbnxpchiptype.Location = new System.Drawing.Point(264, 34);
            this.cbbnxpchiptype.Name = "cbbnxpchiptype";
            this.cbbnxpchiptype.Size = new System.Drawing.Size(63, 20);
            this.cbbnxpchiptype.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(205, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "芯片类型";
            // 
            // CustomCmdFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 584);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomCmdFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "标签私有指令";
            this.Load += new System.EventHandler(this.CustomCmdFrm_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomCmdFrm_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupbox7.ResumeLayout(false);
            this.groupbox7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnChangeEAS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEASAlarm;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbEASset;
        private System.Windows.Forms.RadioButton rbEASreset;
        private System.Windows.Forms.TextBox tbEASAlarmData;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbant4;
        private System.Windows.Forms.RadioButton rbant3;
        private System.Windows.Forms.RadioButton rbant2;
        private System.Windows.Forms.RadioButton rbant1;
        private System.Windows.Forms.TextBox tbaccesspasswd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnbrl;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.CheckBox cb8;
        private System.Windows.Forms.CheckBox cb7;
        private System.Windows.Forms.CheckBox cb6;
        private System.Windows.Forms.CheckBox cb5;
        private System.Windows.Forms.CheckBox cb4;
        private System.Windows.Forms.CheckBox cb3;
        private System.Windows.Forms.CheckBox cb2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnEASDetect;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labEASAlert;
        private System.Windows.Forms.Button btnSetReadProtect;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnResetReadProtect;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton rbimpinjwrite;
        private System.Windows.Forms.RadioButton rbimpinjqtread;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton rbimpinjqtmemprivate;
        private System.Windows.Forms.RadioButton rbimpinjqtmempublic;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton rbimpinjqttemp;
        private System.Windows.Forms.RadioButton rbimpinjqtperm;
        private System.Windows.Forms.GroupBox groupbox7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton rbimpinjqtfarfield;
        private System.Windows.Forms.RadioButton rbimpinjqtnearfiled;
        private System.Windows.Forms.Button btnsetimpinjqt;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ComboBox cbbfilterrule;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbfilteraddr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbbfilterbank;
        private System.Windows.Forms.CheckBox cbisfilter;
        private System.Windows.Forms.TextBox tbfldata;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbbnxpchiptype;

    }
}