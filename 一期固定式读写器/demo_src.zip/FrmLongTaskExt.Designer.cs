﻿namespace ModuleReaderManager
{
    partial class FrmLongTaskExt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gb6btagop = new System.Windows.Forms.GroupBox();
            this.tb6btagopblkcnt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb6btagopaddr = new System.Windows.Forms.TextBox();
            this.tb6btagopweight = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cbis6btagopreadmem = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gbpotlweight = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tbgen2tagopweight = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tbmaxepclen = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cbisgen2tagopreadbank = new System.Windows.Forms.CheckBox();
            this.cbistagopgen2 = new System.Windows.Forms.CheckBox();
            this.gbgen2tagop = new System.Windows.Forms.GroupBox();
            this.cbbgen2tagopbankreadmode = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbgen2tagoppwd = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbgen2tagopblkcnt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbgen2tagopaddr = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbbgen2tagopbank = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbistagop6b = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cbisrevertants = new System.Windows.Forms.CheckBox();
            this.tbsleepdur = new System.Windows.Forms.TextBox();
            this.cbisant4 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbisant3 = new System.Windows.Forms.CheckBox();
            this.tbreaddur = new System.Windows.Forms.TextBox();
            this.cbisant2 = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbisant1 = new System.Windows.Forms.CheckBox();
            this.gbantjudge = new System.Windows.Forms.GroupBox();
            this.gbantjudaft = new System.Windows.Forms.GroupBox();
            this.tbantjudafttimeout = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbantdugaftwaitdur = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.gbantjuddur = new System.Windows.Forms.GroupBox();
            this.tbantjudcycle = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rbantjudalgafttaglv = new System.Windows.Forms.RadioButton();
            this.rbantjudalgbydur = new System.Windows.Forms.RadioButton();
            this.cbisantjudge = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tboluploadport = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.tboluploadip = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbmaxtagbuffercnt = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cbisackbysid = new System.Windows.Forms.CheckBox();
            this.cbbuploadmode = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cbbtcpmode = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tbrtuploadport = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbrtuploadip = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnexecrn = new System.Windows.Forms.Button();
            this.btnexecpn = new System.Windows.Forms.Button();
            this.btnstoptask = new System.Windows.Forms.Button();
            this.btnstopdeltask = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.btnDataRecv = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tbreadername = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.btnsetname = new System.Windows.Forms.Button();
            this.btngetname = new System.Windows.Forms.Button();
            this.btngetlongtask = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.gbjaml1 = new System.Windows.Forms.GroupBox();
            this.tbjaml1crtime = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.gbl16bpwr = new System.Windows.Forms.GroupBox();
            this.tbl16bant4pwr = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.tbl16bant3pwr = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.tbl16bant2pwr = new System.Windows.Forms.TextBox();
            this.tbl16bant1pwr = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.cbisjaml1 = new System.Windows.Forms.CheckBox();
            this.gbl1gen2pwr = new System.Windows.Forms.GroupBox();
            this.tbl1gen2ant4pwr = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.tbl1gen2ant3pwr = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.tbl1gen2ant2pwr = new System.Windows.Forms.TextBox();
            this.tbl1gen2ant1pwr = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.gbjaml0 = new System.Windows.Forms.GroupBox();
            this.tbjaml0crtime = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.gbl0gen2pwr = new System.Windows.Forms.GroupBox();
            this.tbl0gen2ant4pwr = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tbl0gen2ant3pwr = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tbl0gen2ant2pwr = new System.Windows.Forms.TextBox();
            this.tbl0gen2ant1pwr = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cbisjaml0 = new System.Windows.Forms.CheckBox();
            this.gbl06bpwr = new System.Windows.Forms.GroupBox();
            this.tbl06bant4pwr = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tbl06bant3pwr = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tbl06bant2pwr = new System.Windows.Forms.TextBox();
            this.tbl06bant1pwr = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.gb6btagop.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbpotlweight.SuspendLayout();
            this.gbgen2tagop.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gbantjudge.SuspendLayout();
            this.gbantjudaft.SuspendLayout();
            this.gbantjuddur.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.gbjaml1.SuspendLayout();
            this.gbl16bpwr.SuspendLayout();
            this.gbl1gen2pwr.SuspendLayout();
            this.gbjaml0.SuspendLayout();
            this.gbl0gen2pwr.SuspendLayout();
            this.gbl06bpwr.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb6btagop
            // 
            this.gb6btagop.Controls.Add(this.tb6btagopblkcnt);
            this.gb6btagop.Controls.Add(this.label2);
            this.gb6btagop.Controls.Add(this.label1);
            this.gb6btagop.Controls.Add(this.tb6btagopaddr);
            this.gb6btagop.Location = new System.Drawing.Point(340, 37);
            this.gb6btagop.Name = "gb6btagop";
            this.gb6btagop.Size = new System.Drawing.Size(154, 70);
            this.gb6btagop.TabIndex = 0;
            this.gb6btagop.TabStop = false;
            this.gb6btagop.Text = "180006b";
            // 
            // tb6btagopblkcnt
            // 
            this.tb6btagopblkcnt.Location = new System.Drawing.Point(62, 39);
            this.tb6btagopblkcnt.Name = "tb6btagopblkcnt";
            this.tb6btagopblkcnt.Size = new System.Drawing.Size(68, 21);
            this.tb6btagopblkcnt.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "读块数";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "起始地址";
            // 
            // tb6btagopaddr
            // 
            this.tb6btagopaddr.Location = new System.Drawing.Point(62, 13);
            this.tb6btagopaddr.Name = "tb6btagopaddr";
            this.tb6btagopaddr.Size = new System.Drawing.Size(68, 21);
            this.tb6btagopaddr.TabIndex = 1;
            // 
            // tb6btagopweight
            // 
            this.tb6btagopweight.Location = new System.Drawing.Point(240, 14);
            this.tb6btagopweight.Name = "tb6btagopweight";
            this.tb6btagopweight.Size = new System.Drawing.Size(63, 21);
            this.tb6btagopweight.TabIndex = 14;
            this.tb6btagopweight.Text = "30";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(163, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 12);
            this.label22.TabIndex = 13;
            this.label22.Text = "180006b权重";
            // 
            // cbis6btagopreadmem
            // 
            this.cbis6btagopreadmem.AutoSize = true;
            this.cbis6btagopreadmem.Location = new System.Drawing.Point(340, 141);
            this.cbis6btagopreadmem.Name = "cbis6btagopreadmem";
            this.cbis6btagopreadmem.Size = new System.Drawing.Size(150, 16);
            this.cbis6btagopreadmem.TabIndex = 0;
            this.cbis6btagopreadmem.Text = "读180006b标签内存数据";
            this.cbis6btagopreadmem.UseVisualStyleBackColor = true;
            this.cbis6btagopreadmem.CheckedChanged += new System.EventHandler(this.cbis6btagopreadmem_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gbpotlweight);
            this.groupBox2.Controls.Add(this.cbis6btagopreadmem);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.tbmaxepclen);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.cbisgen2tagopreadbank);
            this.groupBox2.Controls.Add(this.cbistagopgen2);
            this.groupBox2.Controls.Add(this.gbgen2tagop);
            this.groupBox2.Controls.Add(this.cbistagop6b);
            this.groupBox2.Controls.Add(this.gb6btagop);
            this.groupBox2.Location = new System.Drawing.Point(14, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(505, 168);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "协议设置";
            // 
            // gbpotlweight
            // 
            this.gbpotlweight.Controls.Add(this.tb6btagopweight);
            this.gbpotlweight.Controls.Add(this.label21);
            this.gbpotlweight.Controls.Add(this.label22);
            this.gbpotlweight.Controls.Add(this.tbgen2tagopweight);
            this.gbpotlweight.Location = new System.Drawing.Point(16, 115);
            this.gbpotlweight.Name = "gbpotlweight";
            this.gbpotlweight.Size = new System.Drawing.Size(313, 42);
            this.gbpotlweight.TabIndex = 5;
            this.gbpotlweight.TabStop = false;
            this.gbpotlweight.Text = "协议权重";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 18);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 12;
            this.label21.Text = "gen2权重";
            // 
            // tbgen2tagopweight
            // 
            this.tbgen2tagopweight.Location = new System.Drawing.Point(63, 14);
            this.tbgen2tagopweight.Name = "tbgen2tagopweight";
            this.tbgen2tagopweight.Size = new System.Drawing.Size(65, 21);
            this.tbgen2tagopweight.TabIndex = 13;
            this.tbgen2tagopweight.Text = "70";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(393, 18);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 12);
            this.label18.TabIndex = 4;
            this.label18.Text = "（以字节为单位）";
            // 
            // tbmaxepclen
            // 
            this.tbmaxepclen.Location = new System.Drawing.Point(329, 12);
            this.tbmaxepclen.Name = "tbmaxepclen";
            this.tbmaxepclen.Size = new System.Drawing.Size(62, 21);
            this.tbmaxepclen.TabIndex = 3;
            this.tbmaxepclen.Text = "12";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(252, 17);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 12);
            this.label17.TabIndex = 2;
            this.label17.Text = "最大epc长度";
            // 
            // cbisgen2tagopreadbank
            // 
            this.cbisgen2tagopreadbank.AutoSize = true;
            this.cbisgen2tagopreadbank.Location = new System.Drawing.Point(340, 119);
            this.cbisgen2tagopreadbank.Name = "cbisgen2tagopreadbank";
            this.cbisgen2tagopreadbank.Size = new System.Drawing.Size(132, 16);
            this.cbisgen2tagopreadbank.TabIndex = 1;
            this.cbisgen2tagopreadbank.Text = "读gen2标签bank数据";
            this.cbisgen2tagopreadbank.UseVisualStyleBackColor = true;
            this.cbisgen2tagopreadbank.CheckedChanged += new System.EventHandler(this.cbisgen2tagopreadbank_CheckedChanged);
            // 
            // cbistagopgen2
            // 
            this.cbistagopgen2.AutoSize = true;
            this.cbistagopgen2.Location = new System.Drawing.Point(113, 15);
            this.cbistagopgen2.Name = "cbistagopgen2";
            this.cbistagopgen2.Size = new System.Drawing.Size(48, 16);
            this.cbistagopgen2.TabIndex = 1;
            this.cbistagopgen2.Text = "gen2";
            this.cbistagopgen2.UseVisualStyleBackColor = true;
            this.cbistagopgen2.CheckedChanged += new System.EventHandler(this.cbistagopgen2_CheckedChanged);
            // 
            // gbgen2tagop
            // 
            this.gbgen2tagop.Controls.Add(this.cbbgen2tagopbankreadmode);
            this.gbgen2tagop.Controls.Add(this.label14);
            this.gbgen2tagop.Controls.Add(this.tbgen2tagoppwd);
            this.gbgen2tagop.Controls.Add(this.label13);
            this.gbgen2tagop.Controls.Add(this.tbgen2tagopblkcnt);
            this.gbgen2tagop.Controls.Add(this.label5);
            this.gbgen2tagop.Controls.Add(this.tbgen2tagopaddr);
            this.gbgen2tagop.Controls.Add(this.label4);
            this.gbgen2tagop.Controls.Add(this.cbbgen2tagopbank);
            this.gbgen2tagop.Controls.Add(this.label3);
            this.gbgen2tagop.Location = new System.Drawing.Point(16, 37);
            this.gbgen2tagop.Name = "gbgen2tagop";
            this.gbgen2tagop.Size = new System.Drawing.Size(313, 70);
            this.gbgen2tagop.TabIndex = 1;
            this.gbgen2tagop.TabStop = false;
            this.gbgen2tagop.Text = "gen2";
            // 
            // cbbgen2tagopbankreadmode
            // 
            this.cbbgen2tagopbankreadmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbgen2tagopbankreadmode.FormattingEnabled = true;
            this.cbbgen2tagopbankreadmode.Items.AddRange(new object[] {
            "默认方式",
            "安全附加数据_固定密码",
            "安全附加数据_推算密码",
            "PSAM方式"});
            this.cbbgen2tagopbankreadmode.Location = new System.Drawing.Point(189, 39);
            this.cbbgen2tagopbankreadmode.Name = "cbbgen2tagopbankreadmode";
            this.cbbgen2tagopbankreadmode.Size = new System.Drawing.Size(118, 20);
            this.cbbgen2tagopbankreadmode.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(135, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 10;
            this.label14.Text = "读取方式";
            // 
            // tbgen2tagoppwd
            // 
            this.tbgen2tagoppwd.Location = new System.Drawing.Point(63, 39);
            this.tbgen2tagoppwd.Name = "tbgen2tagoppwd";
            this.tbgen2tagoppwd.Size = new System.Drawing.Size(65, 21);
            this.tbgen2tagoppwd.TabIndex = 9;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 8;
            this.label13.Text = "访问密码";
            // 
            // tbgen2tagopblkcnt
            // 
            this.tbgen2tagopblkcnt.Location = new System.Drawing.Point(269, 14);
            this.tbgen2tagopblkcnt.Name = "tbgen2tagopblkcnt";
            this.tbgen2tagopblkcnt.Size = new System.Drawing.Size(38, 21);
            this.tbgen2tagopblkcnt.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(226, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "读块数";
            // 
            // tbgen2tagopaddr
            // 
            this.tbgen2tagopaddr.Location = new System.Drawing.Point(189, 14);
            this.tbgen2tagopaddr.Name = "tbgen2tagopaddr";
            this.tbgen2tagopaddr.Size = new System.Drawing.Size(35, 21);
            this.tbgen2tagopaddr.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(131, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "起始地址";
            // 
            // cbbgen2tagopbank
            // 
            this.cbbgen2tagopbank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbgen2tagopbank.FormattingEnabled = true;
            this.cbbgen2tagopbank.Items.AddRange(new object[] {
            "EPC",
            "TID",
            "USER"});
            this.cbbgen2tagopbank.Location = new System.Drawing.Point(63, 15);
            this.cbbgen2tagopbank.Name = "cbbgen2tagopbank";
            this.cbbgen2tagopbank.Size = new System.Drawing.Size(65, 20);
            this.cbbgen2tagopbank.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "bank";
            // 
            // cbistagop6b
            // 
            this.cbistagop6b.AutoSize = true;
            this.cbistagop6b.Location = new System.Drawing.Point(17, 15);
            this.cbistagop6b.Name = "cbistagop6b";
            this.cbistagop6b.Size = new System.Drawing.Size(66, 16);
            this.cbistagop6b.TabIndex = 0;
            this.cbistagop6b.Text = "180006b";
            this.cbistagop6b.UseVisualStyleBackColor = true;
            this.cbistagop6b.CheckedChanged += new System.EventHandler(this.cbistagop6b_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cbisrevertants);
            this.groupBox5.Controls.Add(this.tbsleepdur);
            this.groupBox5.Controls.Add(this.cbisant4);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.cbisant3);
            this.groupBox5.Controls.Add(this.tbreaddur);
            this.groupBox5.Controls.Add(this.cbisant2);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.cbisant1);
            this.groupBox5.Location = new System.Drawing.Point(14, 179);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(505, 48);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "盘存参数设置";
            // 
            // cbisrevertants
            // 
            this.cbisrevertants.AutoSize = true;
            this.cbisrevertants.Location = new System.Drawing.Point(422, 19);
            this.cbisrevertants.Name = "cbisrevertants";
            this.cbisrevertants.Size = new System.Drawing.Size(72, 16);
            this.cbisrevertants.TabIndex = 8;
            this.cbisrevertants.Text = "逆序天线";
            this.cbisrevertants.UseVisualStyleBackColor = true;
            // 
            // tbsleepdur
            // 
            this.tbsleepdur.Location = new System.Drawing.Point(373, 17);
            this.tbsleepdur.Name = "tbsleepdur";
            this.tbsleepdur.Size = new System.Drawing.Size(42, 21);
            this.tbsleepdur.TabIndex = 3;
            this.tbsleepdur.Text = "60";
            // 
            // cbisant4
            // 
            this.cbisant4.AutoSize = true;
            this.cbisant4.Location = new System.Drawing.Point(180, 19);
            this.cbisant4.Name = "cbisant4";
            this.cbisant4.Size = new System.Drawing.Size(54, 16);
            this.cbisant4.TabIndex = 7;
            this.cbisant4.Text = "天线4";
            this.cbisant4.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(329, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "读间隔";
            // 
            // cbisant3
            // 
            this.cbisant3.AutoSize = true;
            this.cbisant3.Location = new System.Drawing.Point(129, 19);
            this.cbisant3.Name = "cbisant3";
            this.cbisant3.Size = new System.Drawing.Size(54, 16);
            this.cbisant3.TabIndex = 6;
            this.cbisant3.Text = "天线3";
            this.cbisant3.UseVisualStyleBackColor = true;
            // 
            // tbreaddur
            // 
            this.tbreaddur.Location = new System.Drawing.Point(279, 17);
            this.tbreaddur.Name = "tbreaddur";
            this.tbreaddur.Size = new System.Drawing.Size(44, 21);
            this.tbreaddur.TabIndex = 1;
            this.tbreaddur.Text = "320";
            // 
            // cbisant2
            // 
            this.cbisant2.AutoSize = true;
            this.cbisant2.Location = new System.Drawing.Point(79, 20);
            this.cbisant2.Name = "cbisant2";
            this.cbisant2.Size = new System.Drawing.Size(54, 16);
            this.cbisant2.TabIndex = 5;
            this.cbisant2.Text = "天线2";
            this.cbisant2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(240, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "读时长";
            // 
            // cbisant1
            // 
            this.cbisant1.AutoSize = true;
            this.cbisant1.Location = new System.Drawing.Point(26, 20);
            this.cbisant1.Name = "cbisant1";
            this.cbisant1.Size = new System.Drawing.Size(54, 16);
            this.cbisant1.TabIndex = 4;
            this.cbisant1.Text = "天线1";
            this.cbisant1.UseVisualStyleBackColor = true;
            // 
            // gbantjudge
            // 
            this.gbantjudge.Controls.Add(this.gbantjudaft);
            this.gbantjudge.Controls.Add(this.gbantjuddur);
            this.gbantjudge.Controls.Add(this.rbantjudalgafttaglv);
            this.gbantjudge.Controls.Add(this.rbantjudalgbydur);
            this.gbantjudge.Location = new System.Drawing.Point(16, 270);
            this.gbantjudge.Name = "gbantjudge";
            this.gbantjudge.Size = new System.Drawing.Size(504, 58);
            this.gbantjudge.TabIndex = 3;
            this.gbantjudge.TabStop = false;
            this.gbantjudge.Text = "天线智能判决设置";
            // 
            // gbantjudaft
            // 
            this.gbantjudaft.Controls.Add(this.tbantjudafttimeout);
            this.gbantjudaft.Controls.Add(this.label10);
            this.gbantjudaft.Controls.Add(this.tbantdugaftwaitdur);
            this.gbantjudaft.Controls.Add(this.label9);
            this.gbantjudaft.Location = new System.Drawing.Point(159, 11);
            this.gbantjudaft.Name = "gbantjudaft";
            this.gbantjudaft.Size = new System.Drawing.Size(203, 41);
            this.gbantjudaft.TabIndex = 3;
            this.gbantjudaft.TabStop = false;
            this.gbantjudaft.Text = "后判决";
            // 
            // tbantjudafttimeout
            // 
            this.tbantjudafttimeout.Location = new System.Drawing.Point(155, 13);
            this.tbantjudafttimeout.Name = "tbantjudafttimeout";
            this.tbantjudafttimeout.Size = new System.Drawing.Size(38, 21);
            this.tbantjudafttimeout.TabIndex = 5;
            this.tbantjudafttimeout.Text = "3000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(101, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "超时时间";
            // 
            // tbantdugaftwaitdur
            // 
            this.tbantdugaftwaitdur.Location = new System.Drawing.Point(61, 13);
            this.tbantdugaftwaitdur.Name = "tbantdugaftwaitdur";
            this.tbantdugaftwaitdur.Size = new System.Drawing.Size(33, 21);
            this.tbantdugaftwaitdur.TabIndex = 3;
            this.tbantdugaftwaitdur.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "等待时间";
            // 
            // gbantjuddur
            // 
            this.gbantjuddur.Controls.Add(this.tbantjudcycle);
            this.gbantjuddur.Controls.Add(this.label8);
            this.gbantjuddur.Location = new System.Drawing.Point(371, 12);
            this.gbantjuddur.Name = "gbantjuddur";
            this.gbantjuddur.Size = new System.Drawing.Size(123, 40);
            this.gbantjuddur.TabIndex = 2;
            this.gbantjuddur.TabStop = false;
            this.gbantjuddur.Text = "时段判决";
            // 
            // tbantjudcycle
            // 
            this.tbantjudcycle.Location = new System.Drawing.Point(77, 14);
            this.tbantjudcycle.Name = "tbantjudcycle";
            this.tbantjudcycle.Size = new System.Drawing.Size(34, 21);
            this.tbantjudcycle.TabIndex = 2;
            this.tbantjudcycle.Text = "2000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "判决周期";
            // 
            // rbantjudalgafttaglv
            // 
            this.rbantjudalgafttaglv.AutoSize = true;
            this.rbantjudalgafttaglv.Location = new System.Drawing.Point(22, 26);
            this.rbantjudalgafttaglv.Name = "rbantjudalgafttaglv";
            this.rbantjudalgafttaglv.Size = new System.Drawing.Size(59, 16);
            this.rbantjudalgafttaglv.TabIndex = 1;
            this.rbantjudalgafttaglv.TabStop = true;
            this.rbantjudalgafttaglv.Text = "后判决";
            this.rbantjudalgafttaglv.UseVisualStyleBackColor = true;
            this.rbantjudalgafttaglv.CheckedChanged += new System.EventHandler(this.rbantjudalgafttaglv_CheckedChanged);
            // 
            // rbantjudalgbydur
            // 
            this.rbantjudalgbydur.AutoSize = true;
            this.rbantjudalgbydur.Location = new System.Drawing.Point(83, 26);
            this.rbantjudalgbydur.Name = "rbantjudalgbydur";
            this.rbantjudalgbydur.Size = new System.Drawing.Size(71, 16);
            this.rbantjudalgbydur.TabIndex = 0;
            this.rbantjudalgbydur.TabStop = true;
            this.rbantjudalgbydur.Text = "时段判决";
            this.rbantjudalgbydur.UseVisualStyleBackColor = true;
            this.rbantjudalgbydur.CheckedChanged += new System.EventHandler(this.rbantjudalgbydur_CheckedChanged);
            // 
            // cbisantjudge
            // 
            this.cbisantjudge.AutoSize = true;
            this.cbisantjudge.Location = new System.Drawing.Point(24, 16);
            this.cbisantjudge.Name = "cbisantjudge";
            this.cbisantjudge.Size = new System.Drawing.Size(120, 16);
            this.cbisantjudge.TabIndex = 4;
            this.cbisantjudge.Text = "启用天线智能判决";
            this.cbisantjudge.UseVisualStyleBackColor = true;
            this.cbisantjudge.CheckedChanged += new System.EventHandler(this.cbisantjudge_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tboluploadport);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.tboluploadip);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.tbmaxtagbuffercnt);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.cbisackbysid);
            this.groupBox4.Controls.Add(this.cbbuploadmode);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.cbbtcpmode);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.tbrtuploadport);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.tbrtuploadip);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Location = new System.Drawing.Point(536, 278);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(505, 97);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "数据上传设置";
            // 
            // tboluploadport
            // 
            this.tboluploadport.Location = new System.Drawing.Point(446, 17);
            this.tboluploadport.Name = "tboluploadport";
            this.tboluploadport.Size = new System.Drawing.Size(46, 21);
            this.tboluploadport.TabIndex = 14;
            this.tboluploadport.Text = "12346";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(342, 23);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(101, 12);
            this.label24.TabIndex = 13;
            this.label24.Text = "离线数据上传端口";
            // 
            // tboluploadip
            // 
            this.tboluploadip.Location = new System.Drawing.Point(102, 44);
            this.tboluploadip.Name = "tboluploadip";
            this.tboluploadip.Size = new System.Drawing.Size(79, 21);
            this.tboluploadip.TabIndex = 12;
            this.tboluploadip.Text = "10.10.1.110";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 48);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(89, 12);
            this.label23.TabIndex = 11;
            this.label23.Text = "离线数据上传ip";
            // 
            // tbmaxtagbuffercnt
            // 
            this.tbmaxtagbuffercnt.Location = new System.Drawing.Point(288, 44);
            this.tbmaxtagbuffercnt.Name = "tbmaxtagbuffercnt";
            this.tbmaxtagbuffercnt.Size = new System.Drawing.Size(48, 21);
            this.tbmaxtagbuffercnt.TabIndex = 10;
            this.tbmaxtagbuffercnt.Text = "100000";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(187, 47);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 12);
            this.label19.TabIndex = 9;
            this.label19.Text = "最大缓存数据量";
            // 
            // cbisackbysid
            // 
            this.cbisackbysid.AutoSize = true;
            this.cbisackbysid.Enabled = false;
            this.cbisackbysid.Location = new System.Drawing.Point(384, 71);
            this.cbisackbysid.Name = "cbisackbysid";
            this.cbisackbysid.Size = new System.Drawing.Size(108, 16);
            this.cbisackbysid.TabIndex = 8;
            this.cbisackbysid.Text = "启用序列号确认";
            this.cbisackbysid.UseVisualStyleBackColor = true;
            // 
            // cbbuploadmode
            // 
            this.cbbuploadmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbuploadmode.FormattingEnabled = true;
            this.cbbuploadmode.Items.AddRange(new object[] {
            "单条上传",
            "批量上传"});
            this.cbbuploadmode.Location = new System.Drawing.Point(428, 44);
            this.cbbuploadmode.Name = "cbbuploadmode";
            this.cbbuploadmode.Size = new System.Drawing.Size(64, 20);
            this.cbbuploadmode.TabIndex = 7;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(345, 48);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 6;
            this.label16.Text = "数据上传模式";
            // 
            // cbbtcpmode
            // 
            this.cbbtcpmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbtcpmode.FormattingEnabled = true;
            this.cbbtcpmode.Items.AddRange(new object[] {
            "短连接",
            "长连接"});
            this.cbbtcpmode.Location = new System.Drawing.Point(115, 71);
            this.cbbtcpmode.Name = "cbbtcpmode";
            this.cbbtcpmode.Size = new System.Drawing.Size(67, 20);
            this.cbbtcpmode.TabIndex = 5;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 4;
            this.label15.Text = "TCP连接模式";
            // 
            // tbrtuploadport
            // 
            this.tbrtuploadport.Location = new System.Drawing.Point(288, 17);
            this.tbrtuploadport.Name = "tbrtuploadport";
            this.tbrtuploadport.Size = new System.Drawing.Size(48, 21);
            this.tbrtuploadport.TabIndex = 3;
            this.tbrtuploadport.Text = "12345";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(186, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "实时数据上传端口";
            // 
            // tbrtuploadip
            // 
            this.tbrtuploadip.Location = new System.Drawing.Point(102, 17);
            this.tbrtuploadip.Name = "tbrtuploadip";
            this.tbrtuploadip.Size = new System.Drawing.Size(79, 21);
            this.tbrtuploadip.TabIndex = 1;
            this.tbrtuploadip.Text = "10.10.1.110";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "实时数据上传ip";
            // 
            // btnexecrn
            // 
            this.btnexecrn.Location = new System.Drawing.Point(72, 391);
            this.btnexecrn.Name = "btnexecrn";
            this.btnexecrn.Size = new System.Drawing.Size(75, 23);
            this.btnexecrn.TabIndex = 5;
            this.btnexecrn.Text = "立即执行";
            this.btnexecrn.UseVisualStyleBackColor = true;
            this.btnexecrn.Click += new System.EventHandler(this.btnexecrn_Click);
            // 
            // btnexecpn
            // 
            this.btnexecpn.Location = new System.Drawing.Point(236, 391);
            this.btnexecpn.Name = "btnexecpn";
            this.btnexecpn.Size = new System.Drawing.Size(75, 23);
            this.btnexecpn.TabIndex = 6;
            this.btnexecpn.Text = "上电执行";
            this.btnexecpn.UseVisualStyleBackColor = true;
            this.btnexecpn.Click += new System.EventHandler(this.btnexecpn_Click);
            // 
            // btnstoptask
            // 
            this.btnstoptask.Location = new System.Drawing.Point(407, 391);
            this.btnstoptask.Name = "btnstoptask";
            this.btnstoptask.Size = new System.Drawing.Size(75, 23);
            this.btnstoptask.TabIndex = 7;
            this.btnstoptask.Text = "停止任务";
            this.btnstoptask.UseVisualStyleBackColor = true;
            this.btnstoptask.Click += new System.EventHandler(this.btnstoptask_Click);
            // 
            // btnstopdeltask
            // 
            this.btnstopdeltask.Location = new System.Drawing.Point(561, 391);
            this.btnstopdeltask.Name = "btnstopdeltask";
            this.btnstopdeltask.Size = new System.Drawing.Size(108, 23);
            this.btnstopdeltask.TabIndex = 8;
            this.btnstopdeltask.Text = "停止并删除任务";
            this.btnstopdeltask.UseVisualStyleBackColor = true;
            this.btnstopdeltask.Click += new System.EventHandler(this.btnstopdeltask_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.cbisantjudge);
            this.groupBox1.Location = new System.Drawing.Point(14, 229);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(505, 40);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "杂项";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(356, 16);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(138, 16);
            this.checkBox2.TabIndex = 6;
            this.checkBox2.Text = "启用操作成功触发GPO";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(194, 16);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(114, 16);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "启用GPI触发工作";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox7);
            this.groupBox8.Controls.Add(this.groupBox6);
            this.groupBox8.Controls.Add(this.textBox1);
            this.groupBox8.Controls.Add(this.label20);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Controls.Add(this.groupBox10);
            this.groupBox8.Enabled = false;
            this.groupBox8.Location = new System.Drawing.Point(534, 159);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(507, 117);
            this.groupBox8.TabIndex = 34;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "GPIO触发";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.checkBox7);
            this.groupBox7.Controls.Add(this.checkBox8);
            this.groupBox7.Controls.Add(this.checkBox9);
            this.groupBox7.Controls.Add(this.checkBox10);
            this.groupBox7.Location = new System.Drawing.Point(263, 15);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(231, 36);
            this.groupBox7.TabIndex = 39;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "触发停止工作状态";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(178, 14);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(48, 16);
            this.checkBox7.TabIndex = 4;
            this.checkBox7.Text = "GPI4";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(71, 14);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(48, 16);
            this.checkBox8.TabIndex = 3;
            this.checkBox8.Text = "GPI2";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(14, 14);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(48, 16);
            this.checkBox9.TabIndex = 2;
            this.checkBox9.Text = "GPI1";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(125, 14);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(48, 16);
            this.checkBox10.TabIndex = 1;
            this.checkBox10.Text = "GPI3";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.checkBox6);
            this.groupBox6.Controls.Add(this.checkBox5);
            this.groupBox6.Controls.Add(this.checkBox4);
            this.groupBox6.Controls.Add(this.checkBox3);
            this.groupBox6.Location = new System.Drawing.Point(12, 15);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(231, 36);
            this.groupBox6.TabIndex = 38;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "触发工作状态";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(178, 15);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(48, 16);
            this.checkBox6.TabIndex = 4;
            this.checkBox6.Text = "GPI4";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(71, 15);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(48, 16);
            this.checkBox5.TabIndex = 3;
            this.checkBox5.Text = "GPI2";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(14, 15);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(48, 16);
            this.checkBox4.TabIndex = 2;
            this.checkBox4.Text = "GPI1";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(125, 15);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(48, 16);
            this.checkBox3.TabIndex = 1;
            this.checkBox3.Text = "GPI3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(104, 91);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 37;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 94);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 12);
            this.label20.TabIndex = 36;
            this.label20.Text = "状态持续时间";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.checkBox11);
            this.groupBox9.Controls.Add(this.checkBox12);
            this.groupBox9.Controls.Add(this.checkBox13);
            this.groupBox9.Controls.Add(this.checkBox14);
            this.groupBox9.Location = new System.Drawing.Point(263, 57);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(231, 31);
            this.groupBox9.TabIndex = 35;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "GPO提示状态";
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(178, 11);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(48, 16);
            this.checkBox11.TabIndex = 4;
            this.checkBox11.Text = "GPO4";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(71, 11);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(48, 16);
            this.checkBox12.TabIndex = 3;
            this.checkBox12.Text = "GPO2";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(14, 11);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(48, 16);
            this.checkBox13.TabIndex = 2;
            this.checkBox13.Text = "GPO1";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(125, 11);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(48, 16);
            this.checkBox14.TabIndex = 1;
            this.checkBox14.Text = "GPO3";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.checkBox15);
            this.groupBox10.Controls.Add(this.checkBox16);
            this.groupBox10.Controls.Add(this.checkBox17);
            this.groupBox10.Controls.Add(this.checkBox18);
            this.groupBox10.Location = new System.Drawing.Point(14, 54);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(231, 34);
            this.groupBox10.TabIndex = 34;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "GPO非提示状态";
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(177, 15);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(48, 16);
            this.checkBox15.TabIndex = 4;
            this.checkBox15.Text = "GPO4";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(70, 15);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(48, 16);
            this.checkBox16.TabIndex = 3;
            this.checkBox16.Text = "GPO2";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(13, 15);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(48, 16);
            this.checkBox17.TabIndex = 2;
            this.checkBox17.Text = "GPO1";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(124, 15);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(48, 16);
            this.checkBox18.TabIndex = 1;
            this.checkBox18.Text = "GPO3";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // btnDataRecv
            // 
            this.btnDataRecv.Location = new System.Drawing.Point(761, 391);
            this.btnDataRecv.Name = "btnDataRecv";
            this.btnDataRecv.Size = new System.Drawing.Size(75, 23);
            this.btnDataRecv.TabIndex = 35;
            this.btnDataRecv.Text = "数据接收";
            this.btnDataRecv.UseVisualStyleBackColor = true;
            this.btnDataRecv.Click += new System.EventHandler(this.btnDataRecv_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.tbreadername);
            this.groupBox11.Controls.Add(this.label25);
            this.groupBox11.Controls.Add(this.btnsetname);
            this.groupBox11.Controls.Add(this.btngetname);
            this.groupBox11.Location = new System.Drawing.Point(15, 334);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(504, 42);
            this.groupBox11.TabIndex = 36;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "读写器名称设置";
            // 
            // tbreadername
            // 
            this.tbreadername.Location = new System.Drawing.Point(95, 13);
            this.tbreadername.Name = "tbreadername";
            this.tbreadername.Size = new System.Drawing.Size(100, 21);
            this.tbreadername.TabIndex = 3;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(12, 18);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 2;
            this.label25.Text = "读写器名称：";
            // 
            // btnsetname
            // 
            this.btnsetname.Location = new System.Drawing.Point(412, 13);
            this.btnsetname.Name = "btnsetname";
            this.btnsetname.Size = new System.Drawing.Size(75, 23);
            this.btnsetname.TabIndex = 1;
            this.btnsetname.Text = "设置";
            this.btnsetname.UseVisualStyleBackColor = true;
            this.btnsetname.Click += new System.EventHandler(this.btnsetname_Click);
            // 
            // btngetname
            // 
            this.btngetname.Location = new System.Drawing.Point(282, 13);
            this.btngetname.Name = "btngetname";
            this.btngetname.Size = new System.Drawing.Size(75, 23);
            this.btngetname.TabIndex = 0;
            this.btngetname.Text = "获取";
            this.btngetname.UseVisualStyleBackColor = true;
            this.btngetname.Click += new System.EventHandler(this.btngetname_Click);
            // 
            // btngetlongtask
            // 
            this.btngetlongtask.Location = new System.Drawing.Point(904, 391);
            this.btngetlongtask.Name = "btngetlongtask";
            this.btngetlongtask.Size = new System.Drawing.Size(75, 23);
            this.btngetlongtask.TabIndex = 38;
            this.btngetlongtask.Text = "获取长任务";
            this.btngetlongtask.UseVisualStyleBackColor = true;
            this.btngetlongtask.Click += new System.EventHandler(this.btngetlongtask_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.gbjaml1);
            this.groupBox12.Controls.Add(this.gbjaml0);
            this.groupBox12.Location = new System.Drawing.Point(534, 14);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(505, 142);
            this.groupBox12.TabIndex = 39;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "车流阻塞功率设置";
            // 
            // gbjaml1
            // 
            this.gbjaml1.Controls.Add(this.tbjaml1crtime);
            this.gbjaml1.Controls.Add(this.label44);
            this.gbjaml1.Controls.Add(this.gbl16bpwr);
            this.gbjaml1.Controls.Add(this.cbisjaml1);
            this.gbjaml1.Controls.Add(this.gbl1gen2pwr);
            this.gbjaml1.Location = new System.Drawing.Point(259, 15);
            this.gbjaml1.Name = "gbjaml1";
            this.gbjaml1.Size = new System.Drawing.Size(235, 116);
            this.gbjaml1.TabIndex = 41;
            this.gbjaml1.TabStop = false;
            this.gbjaml1.Text = "阻塞level1";
            // 
            // tbjaml1crtime
            // 
            this.tbjaml1crtime.Location = new System.Drawing.Point(139, 90);
            this.tbjaml1crtime.Name = "tbjaml1crtime";
            this.tbjaml1crtime.Size = new System.Drawing.Size(32, 21);
            this.tbjaml1crtime.TabIndex = 12;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(7, 96);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(131, 12);
            this.label44.TabIndex = 11;
            this.label44.Text = "阻塞级别1连续读到周期";
            // 
            // gbl16bpwr
            // 
            this.gbl16bpwr.Controls.Add(this.tbl16bant4pwr);
            this.gbl16bpwr.Controls.Add(this.label34);
            this.gbl16bpwr.Controls.Add(this.tbl16bant3pwr);
            this.gbl16bpwr.Controls.Add(this.label35);
            this.gbl16bpwr.Controls.Add(this.tbl16bant2pwr);
            this.gbl16bpwr.Controls.Add(this.tbl16bant1pwr);
            this.gbl16bpwr.Controls.Add(this.label36);
            this.gbl16bpwr.Controls.Add(this.label37);
            this.gbl16bpwr.Location = new System.Drawing.Point(6, 50);
            this.gbl16bpwr.Name = "gbl16bpwr";
            this.gbl16bpwr.Size = new System.Drawing.Size(225, 35);
            this.gbl16bpwr.TabIndex = 5;
            this.gbl16bpwr.TabStop = false;
            this.gbl16bpwr.Text = "6b功率";
            // 
            // tbl16bant4pwr
            // 
            this.tbl16bant4pwr.Location = new System.Drawing.Point(176, 12);
            this.tbl16bant4pwr.Name = "tbl16bant4pwr";
            this.tbl16bant4pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl16bant4pwr.TabIndex = 7;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(162, 16);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(11, 12);
            this.label34.TabIndex = 6;
            this.label34.Text = "4";
            // 
            // tbl16bant3pwr
            // 
            this.tbl16bant3pwr.Location = new System.Drawing.Point(121, 11);
            this.tbl16bant3pwr.Name = "tbl16bant3pwr";
            this.tbl16bant3pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl16bant3pwr.TabIndex = 5;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(108, 16);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(11, 12);
            this.label35.TabIndex = 4;
            this.label35.Text = "3";
            // 
            // tbl16bant2pwr
            // 
            this.tbl16bant2pwr.Location = new System.Drawing.Point(66, 12);
            this.tbl16bant2pwr.Name = "tbl16bant2pwr";
            this.tbl16bant2pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl16bant2pwr.TabIndex = 3;
            // 
            // tbl16bant1pwr
            // 
            this.tbl16bant1pwr.Location = new System.Drawing.Point(12, 12);
            this.tbl16bant1pwr.Name = "tbl16bant1pwr";
            this.tbl16bant1pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl16bant1pwr.TabIndex = 2;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(54, 16);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(11, 12);
            this.label36.TabIndex = 1;
            this.label36.Text = "2";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(1, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(11, 12);
            this.label37.TabIndex = 0;
            this.label37.Text = "1";
            // 
            // cbisjaml1
            // 
            this.cbisjaml1.AutoSize = true;
            this.cbisjaml1.Location = new System.Drawing.Point(182, 92);
            this.cbisjaml1.Name = "cbisjaml1";
            this.cbisjaml1.Size = new System.Drawing.Size(48, 16);
            this.cbisjaml1.TabIndex = 3;
            this.cbisjaml1.Text = "使能";
            this.cbisjaml1.UseVisualStyleBackColor = true;
            this.cbisjaml1.CheckedChanged += new System.EventHandler(this.cbisjaml1_CheckedChanged);
            // 
            // gbl1gen2pwr
            // 
            this.gbl1gen2pwr.Controls.Add(this.tbl1gen2ant4pwr);
            this.gbl1gen2pwr.Controls.Add(this.label38);
            this.gbl1gen2pwr.Controls.Add(this.tbl1gen2ant3pwr);
            this.gbl1gen2pwr.Controls.Add(this.label39);
            this.gbl1gen2pwr.Controls.Add(this.tbl1gen2ant2pwr);
            this.gbl1gen2pwr.Controls.Add(this.tbl1gen2ant1pwr);
            this.gbl1gen2pwr.Controls.Add(this.label40);
            this.gbl1gen2pwr.Controls.Add(this.label41);
            this.gbl1gen2pwr.Location = new System.Drawing.Point(4, 14);
            this.gbl1gen2pwr.Name = "gbl1gen2pwr";
            this.gbl1gen2pwr.Size = new System.Drawing.Size(225, 35);
            this.gbl1gen2pwr.TabIndex = 10;
            this.gbl1gen2pwr.TabStop = false;
            this.gbl1gen2pwr.Text = "gen2功率";
            // 
            // tbl1gen2ant4pwr
            // 
            this.tbl1gen2ant4pwr.Location = new System.Drawing.Point(176, 12);
            this.tbl1gen2ant4pwr.Name = "tbl1gen2ant4pwr";
            this.tbl1gen2ant4pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl1gen2ant4pwr.TabIndex = 7;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(162, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(11, 12);
            this.label38.TabIndex = 6;
            this.label38.Text = "4";
            // 
            // tbl1gen2ant3pwr
            // 
            this.tbl1gen2ant3pwr.Location = new System.Drawing.Point(121, 11);
            this.tbl1gen2ant3pwr.Name = "tbl1gen2ant3pwr";
            this.tbl1gen2ant3pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl1gen2ant3pwr.TabIndex = 5;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(108, 16);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(11, 12);
            this.label39.TabIndex = 4;
            this.label39.Text = "3";
            // 
            // tbl1gen2ant2pwr
            // 
            this.tbl1gen2ant2pwr.Location = new System.Drawing.Point(66, 12);
            this.tbl1gen2ant2pwr.Name = "tbl1gen2ant2pwr";
            this.tbl1gen2ant2pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl1gen2ant2pwr.TabIndex = 3;
            // 
            // tbl1gen2ant1pwr
            // 
            this.tbl1gen2ant1pwr.Location = new System.Drawing.Point(12, 12);
            this.tbl1gen2ant1pwr.Name = "tbl1gen2ant1pwr";
            this.tbl1gen2ant1pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl1gen2ant1pwr.TabIndex = 2;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(54, 16);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(11, 12);
            this.label40.TabIndex = 1;
            this.label40.Text = "2";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(1, 16);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(11, 12);
            this.label41.TabIndex = 0;
            this.label41.Text = "1";
            // 
            // gbjaml0
            // 
            this.gbjaml0.Controls.Add(this.tbjaml0crtime);
            this.gbjaml0.Controls.Add(this.label42);
            this.gbjaml0.Controls.Add(this.gbl0gen2pwr);
            this.gbjaml0.Controls.Add(this.cbisjaml0);
            this.gbjaml0.Controls.Add(this.gbl06bpwr);
            this.gbjaml0.Location = new System.Drawing.Point(10, 15);
            this.gbjaml0.Name = "gbjaml0";
            this.gbjaml0.Size = new System.Drawing.Size(235, 116);
            this.gbjaml0.TabIndex = 40;
            this.gbjaml0.TabStop = false;
            this.gbjaml0.Text = "阻塞level0";
            // 
            // tbjaml0crtime
            // 
            this.tbjaml0crtime.Location = new System.Drawing.Point(139, 90);
            this.tbjaml0crtime.Name = "tbjaml0crtime";
            this.tbjaml0crtime.Size = new System.Drawing.Size(32, 21);
            this.tbjaml0crtime.TabIndex = 12;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(7, 96);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(131, 12);
            this.label42.TabIndex = 11;
            this.label42.Text = "阻塞级别0连续读到周期";
            // 
            // gbl0gen2pwr
            // 
            this.gbl0gen2pwr.Controls.Add(this.tbl0gen2ant4pwr);
            this.gbl0gen2pwr.Controls.Add(this.label29);
            this.gbl0gen2pwr.Controls.Add(this.tbl0gen2ant3pwr);
            this.gbl0gen2pwr.Controls.Add(this.label28);
            this.gbl0gen2pwr.Controls.Add(this.tbl0gen2ant2pwr);
            this.gbl0gen2pwr.Controls.Add(this.tbl0gen2ant1pwr);
            this.gbl0gen2pwr.Controls.Add(this.label27);
            this.gbl0gen2pwr.Controls.Add(this.label26);
            this.gbl0gen2pwr.Location = new System.Drawing.Point(5, 12);
            this.gbl0gen2pwr.Name = "gbl0gen2pwr";
            this.gbl0gen2pwr.Size = new System.Drawing.Size(225, 35);
            this.gbl0gen2pwr.TabIndex = 9;
            this.gbl0gen2pwr.TabStop = false;
            this.gbl0gen2pwr.Text = "gen2功率";
            // 
            // tbl0gen2ant4pwr
            // 
            this.tbl0gen2ant4pwr.Location = new System.Drawing.Point(176, 12);
            this.tbl0gen2ant4pwr.Name = "tbl0gen2ant4pwr";
            this.tbl0gen2ant4pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl0gen2ant4pwr.TabIndex = 7;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(162, 16);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(11, 12);
            this.label29.TabIndex = 6;
            this.label29.Text = "4";
            // 
            // tbl0gen2ant3pwr
            // 
            this.tbl0gen2ant3pwr.Location = new System.Drawing.Point(121, 11);
            this.tbl0gen2ant3pwr.Name = "tbl0gen2ant3pwr";
            this.tbl0gen2ant3pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl0gen2ant3pwr.TabIndex = 5;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(108, 16);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(11, 12);
            this.label28.TabIndex = 4;
            this.label28.Text = "3";
            // 
            // tbl0gen2ant2pwr
            // 
            this.tbl0gen2ant2pwr.Location = new System.Drawing.Point(66, 12);
            this.tbl0gen2ant2pwr.Name = "tbl0gen2ant2pwr";
            this.tbl0gen2ant2pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl0gen2ant2pwr.TabIndex = 3;
            // 
            // tbl0gen2ant1pwr
            // 
            this.tbl0gen2ant1pwr.Location = new System.Drawing.Point(12, 12);
            this.tbl0gen2ant1pwr.Name = "tbl0gen2ant1pwr";
            this.tbl0gen2ant1pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl0gen2ant1pwr.TabIndex = 2;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(54, 16);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(11, 12);
            this.label27.TabIndex = 1;
            this.label27.Text = "2";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1, 16);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(11, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "1";
            // 
            // cbisjaml0
            // 
            this.cbisjaml0.AutoSize = true;
            this.cbisjaml0.Location = new System.Drawing.Point(181, 93);
            this.cbisjaml0.Name = "cbisjaml0";
            this.cbisjaml0.Size = new System.Drawing.Size(48, 16);
            this.cbisjaml0.TabIndex = 8;
            this.cbisjaml0.Text = "使能";
            this.cbisjaml0.UseVisualStyleBackColor = true;
            this.cbisjaml0.CheckedChanged += new System.EventHandler(this.cbisjaml0_CheckedChanged_1);
            // 
            // gbl06bpwr
            // 
            this.gbl06bpwr.Controls.Add(this.tbl06bant4pwr);
            this.gbl06bpwr.Controls.Add(this.label30);
            this.gbl06bpwr.Controls.Add(this.tbl06bant3pwr);
            this.gbl06bpwr.Controls.Add(this.label31);
            this.gbl06bpwr.Controls.Add(this.tbl06bant2pwr);
            this.gbl06bpwr.Controls.Add(this.tbl06bant1pwr);
            this.gbl06bpwr.Controls.Add(this.label32);
            this.gbl06bpwr.Controls.Add(this.label33);
            this.gbl06bpwr.Location = new System.Drawing.Point(5, 50);
            this.gbl06bpwr.Name = "gbl06bpwr";
            this.gbl06bpwr.Size = new System.Drawing.Size(225, 35);
            this.gbl06bpwr.TabIndex = 2;
            this.gbl06bpwr.TabStop = false;
            this.gbl06bpwr.Text = "6b功率";
            // 
            // tbl06bant4pwr
            // 
            this.tbl06bant4pwr.Location = new System.Drawing.Point(176, 12);
            this.tbl06bant4pwr.Name = "tbl06bant4pwr";
            this.tbl06bant4pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl06bant4pwr.TabIndex = 7;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(162, 16);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(11, 12);
            this.label30.TabIndex = 6;
            this.label30.Text = "4";
            // 
            // tbl06bant3pwr
            // 
            this.tbl06bant3pwr.Location = new System.Drawing.Point(121, 11);
            this.tbl06bant3pwr.Name = "tbl06bant3pwr";
            this.tbl06bant3pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl06bant3pwr.TabIndex = 5;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(108, 16);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(11, 12);
            this.label31.TabIndex = 4;
            this.label31.Text = "3";
            // 
            // tbl06bant2pwr
            // 
            this.tbl06bant2pwr.Location = new System.Drawing.Point(66, 12);
            this.tbl06bant2pwr.Name = "tbl06bant2pwr";
            this.tbl06bant2pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl06bant2pwr.TabIndex = 3;
            // 
            // tbl06bant1pwr
            // 
            this.tbl06bant1pwr.Location = new System.Drawing.Point(12, 12);
            this.tbl06bant1pwr.Name = "tbl06bant1pwr";
            this.tbl06bant1pwr.Size = new System.Drawing.Size(39, 21);
            this.tbl06bant1pwr.TabIndex = 2;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(54, 16);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(11, 12);
            this.label32.TabIndex = 1;
            this.label32.Text = "2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(1, 16);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(11, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "1";
            // 
            // FrmLongTaskExt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1055, 426);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.btngetlongtask);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.btnDataRecv);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnstopdeltask);
            this.Controls.Add(this.btnstoptask);
            this.Controls.Add(this.btnexecpn);
            this.Controls.Add(this.btnexecrn);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.gbantjudge);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmLongTaskExt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "扩展长任务";
            this.Load += new System.EventHandler(this.FrmLongTaskExt_Load);
            this.gb6btagop.ResumeLayout(false);
            this.gb6btagop.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbpotlweight.ResumeLayout(false);
            this.gbpotlweight.PerformLayout();
            this.gbgen2tagop.ResumeLayout(false);
            this.gbgen2tagop.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.gbantjudge.ResumeLayout(false);
            this.gbantjudge.PerformLayout();
            this.gbantjudaft.ResumeLayout(false);
            this.gbantjudaft.PerformLayout();
            this.gbantjuddur.ResumeLayout(false);
            this.gbantjuddur.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.gbjaml1.ResumeLayout(false);
            this.gbjaml1.PerformLayout();
            this.gbl16bpwr.ResumeLayout(false);
            this.gbl16bpwr.PerformLayout();
            this.gbl1gen2pwr.ResumeLayout(false);
            this.gbl1gen2pwr.PerformLayout();
            this.gbjaml0.ResumeLayout(false);
            this.gbjaml0.PerformLayout();
            this.gbl0gen2pwr.ResumeLayout(false);
            this.gbl0gen2pwr.PerformLayout();
            this.gbl06bpwr.ResumeLayout(false);
            this.gbl06bpwr.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb6btagop;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cbistagop6b;
        private System.Windows.Forms.GroupBox gbgen2tagop;
        private System.Windows.Forms.CheckBox cbistagopgen2;
        private System.Windows.Forms.TextBox tb6btagopblkcnt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb6btagopaddr;
        private System.Windows.Forms.CheckBox cbis6btagopreadmem;
        private System.Windows.Forms.CheckBox cbisgen2tagopreadbank;
        private System.Windows.Forms.TextBox tbgen2tagopblkcnt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbgen2tagopaddr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbbgen2tagopbank;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox tbsleepdur;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbreaddur;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gbantjudge;
        private System.Windows.Forms.RadioButton rbantjudalgafttaglv;
        private System.Windows.Forms.RadioButton rbantjudalgbydur;
        private System.Windows.Forms.GroupBox gbantjudaft;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox gbantjuddur;
        private System.Windows.Forms.TextBox tbantjudcycle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbantjudafttimeout;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbantdugaftwaitdur;
        private System.Windows.Forms.CheckBox cbisantjudge;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbrtuploadport;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbrtuploadip;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbgen2tagoppwd;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbbgen2tagopbankreadmode;
        private System.Windows.Forms.ComboBox cbbuploadmode;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cbbtcpmode;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbmaxepclen;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbmaxtagbuffercnt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox cbisackbysid;
        private System.Windows.Forms.CheckBox cbisrevertants;
        private System.Windows.Forms.CheckBox cbisant4;
        private System.Windows.Forms.CheckBox cbisant3;
        private System.Windows.Forms.CheckBox cbisant2;
        private System.Windows.Forms.CheckBox cbisant1;
        private System.Windows.Forms.Button btnexecrn;
        private System.Windows.Forms.Button btnexecpn;
        private System.Windows.Forms.Button btnstoptask;
        private System.Windows.Forms.Button btnstopdeltask;
        private System.Windows.Forms.TextBox tbgen2tagopweight;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tb6btagopweight;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tboluploadport;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tboluploadip;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox gbpotlweight;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnDataRecv;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnsetname;
        private System.Windows.Forms.Button btngetname;
        private System.Windows.Forms.TextBox tbreadername;
        private System.Windows.Forms.Button btngetlongtask;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.GroupBox gbl16bpwr;
        private System.Windows.Forms.TextBox tbl16bant4pwr;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox tbl16bant3pwr;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox tbl16bant2pwr;
        private System.Windows.Forms.TextBox tbl16bant1pwr;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.CheckBox cbisjaml1;
        private System.Windows.Forms.GroupBox gbl06bpwr;
        private System.Windows.Forms.TextBox tbl06bant4pwr;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tbl06bant3pwr;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox tbl06bant2pwr;
        private System.Windows.Forms.TextBox tbl06bant1pwr;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox gbjaml0;
        private System.Windows.Forms.TextBox tbjaml0crtime;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox gbl0gen2pwr;
        private System.Windows.Forms.TextBox tbl0gen2ant4pwr;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox tbl0gen2ant3pwr;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox tbl0gen2ant2pwr;
        private System.Windows.Forms.TextBox tbl0gen2ant1pwr;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.CheckBox cbisjaml0;
        private System.Windows.Forms.GroupBox gbl1gen2pwr;
        private System.Windows.Forms.TextBox tbl1gen2ant4pwr;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox tbl1gen2ant3pwr;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox tbl1gen2ant2pwr;
        private System.Windows.Forms.TextBox tbl1gen2ant1pwr;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.GroupBox gbjaml1;
        private System.Windows.Forms.TextBox tbjaml1crtime;
        private System.Windows.Forms.Label label44;
    }
}