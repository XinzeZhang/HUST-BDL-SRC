﻿namespace ModuleReaderManager
{
    partial class InventoryParasform
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbbfilterrule = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbbfilterbank = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbfilteraddr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbisfilter = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbfilterdata = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbebstartaddr = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbbebbank = new System.Windows.Forms.ComboBox();
            this.gbemddata = new System.Windows.Forms.GroupBox();
            this.tbebbytescnt = new System.Windows.Forms.TextBox();
            this.cbispwd = new System.Windows.Forms.CheckBox();
            this.tbacspwd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbisaddiondata = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.gbsecureread = new System.Windows.Forms.GroupBox();
            this.cbissecureread = new System.Windows.Forms.CheckBox();
            this.cbbsrtagtype = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cbbsrpwdtype = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbindexbitsnum = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tbsrindexstartbit = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tbsracspwd = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cbbsrbank = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbsrblks = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbsraddress = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.gbpotlweight = new System.Windows.Forms.GroupBox();
            this.tbwtipx256 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbwtipx64 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tbwt180006b = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbwtgen2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbisOneReadOneTime = new System.Windows.Forms.CheckBox();
            this.cbisReadFixCount = new System.Windows.Forms.CheckBox();
            this.tbReadCount = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.cbisrevertants = new System.Windows.Forms.CheckBox();
            this.tbreaddur = new System.Windows.Forms.TextBox();
            this.tbsleepdur = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbisunibyant = new System.Windows.Forms.CheckBox();
            this.cbischgcolor = new System.Windows.Forms.CheckBox();
            this.cbisunibynullemd = new System.Windows.Forms.CheckBox();
            this.gbidentifyants = new System.Windows.Forms.GroupBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.rbidtantafter = new System.Windows.Forms.RadioButton();
            this.rbidtantbydur = new System.Windows.Forms.RadioButton();
            this.tbafttime = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tbidtdur = new System.Windows.Forms.TextBox();
            this.cbisidtant = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cbbreadresult = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cbbantcnt = new System.Windows.Forms.ComboBox();
            this.cbbtagcnt = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnSetCase = new System.Windows.Forms.Button();
            this.cbishighspeed = new System.Windows.Forms.CheckBox();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.gbemddata.SuspendLayout();
            this.gbsecureread.SuspendLayout();
            this.gbpotlweight.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbidentifyants.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbbfilterrule);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cbbfilterbank);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbfilteraddr);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbisfilter);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbfilterdata);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(14, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 108);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "过滤参数";
            // 
            // cbbfilterrule
            // 
            this.cbbfilterrule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbfilterrule.FormattingEnabled = true;
            this.cbbfilterrule.Items.AddRange(new object[] {
            "匹配",
            "不匹配"});
            this.cbbfilterrule.Location = new System.Drawing.Point(254, 49);
            this.cbbfilterrule.Name = "cbbfilterrule";
            this.cbbfilterrule.Size = new System.Drawing.Size(48, 20);
            this.cbbfilterrule.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(185, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "过滤规则";
            // 
            // cbbfilterbank
            // 
            this.cbbfilterbank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbfilterbank.FormattingEnabled = true;
            this.cbbfilterbank.Items.AddRange(new object[] {
            "EPCbank",
            "TIDbank",
            "USERbank"});
            this.cbbfilterbank.Location = new System.Drawing.Point(75, 49);
            this.cbbfilterbank.Name = "cbbfilterbank";
            this.cbbfilterbank.Size = new System.Drawing.Size(104, 20);
            this.cbbfilterbank.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(6, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 14);
            this.label6.TabIndex = 14;
            this.label6.Text = "过滤bank";
            // 
            // tbfilteraddr
            // 
            this.tbfilteraddr.Location = new System.Drawing.Point(254, 20);
            this.tbfilteraddr.Name = "tbfilteraddr";
            this.tbfilteraddr.Size = new System.Drawing.Size(50, 21);
            this.tbfilteraddr.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(185, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 14);
            this.label5.TabIndex = 14;
            this.label5.Text = "起始地址";
            // 
            // cbisfilter
            // 
            this.cbisfilter.AutoSize = true;
            this.cbisfilter.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbisfilter.Location = new System.Drawing.Point(9, 81);
            this.cbisfilter.Name = "cbisfilter";
            this.cbisfilter.Size = new System.Drawing.Size(82, 18);
            this.cbisfilter.TabIndex = 13;
            this.cbisfilter.Text = "启用过滤";
            this.cbisfilter.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(6, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 14);
            this.label2.TabIndex = 13;
            this.label2.Text = "过滤码";
            // 
            // tbfilterdata
            // 
            this.tbfilterdata.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbfilterdata.Location = new System.Drawing.Point(75, 20);
            this.tbfilterdata.Name = "tbfilterdata";
            this.tbfilterdata.Size = new System.Drawing.Size(104, 23);
            this.tbfilterdata.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "起始地址";
            // 
            // tbebstartaddr
            // 
            this.tbebstartaddr.Location = new System.Drawing.Point(75, 20);
            this.tbebstartaddr.Name = "tbebstartaddr";
            this.tbebstartaddr.Size = new System.Drawing.Size(72, 21);
            this.tbebstartaddr.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(156, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 17;
            this.label3.Text = "字节数";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(6, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 14);
            this.label4.TabIndex = 18;
            this.label4.Text = "bank";
            // 
            // cbbebbank
            // 
            this.cbbebbank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbebbank.FormattingEnabled = true;
            this.cbbebbank.Items.AddRange(new object[] {
            "Reservebank",
            "EPCbank",
            "TIDbank",
            "USERbank"});
            this.cbbebbank.Location = new System.Drawing.Point(75, 56);
            this.cbbebbank.Name = "cbbebbank";
            this.cbbebbank.Size = new System.Drawing.Size(72, 20);
            this.cbbebbank.TabIndex = 19;
            // 
            // gbemddata
            // 
            this.gbemddata.Controls.Add(this.tbebbytescnt);
            this.gbemddata.Controls.Add(this.cbispwd);
            this.gbemddata.Controls.Add(this.tbacspwd);
            this.gbemddata.Controls.Add(this.label8);
            this.gbemddata.Controls.Add(this.cbisaddiondata);
            this.gbemddata.Controls.Add(this.cbbebbank);
            this.gbemddata.Controls.Add(this.label3);
            this.gbemddata.Controls.Add(this.label4);
            this.gbemddata.Controls.Add(this.label1);
            this.gbemddata.Controls.Add(this.tbebstartaddr);
            this.gbemddata.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbemddata.Location = new System.Drawing.Point(14, 123);
            this.gbemddata.Name = "gbemddata";
            this.gbemddata.Size = new System.Drawing.Size(310, 118);
            this.gbemddata.TabIndex = 20;
            this.gbemddata.TabStop = false;
            this.gbemddata.Text = "附加数据";
            // 
            // tbebbytescnt
            // 
            this.tbebbytescnt.Location = new System.Drawing.Point(223, 20);
            this.tbebbytescnt.Name = "tbebbytescnt";
            this.tbebbytescnt.Size = new System.Drawing.Size(81, 21);
            this.tbebbytescnt.TabIndex = 25;
            // 
            // cbispwd
            // 
            this.cbispwd.AutoSize = true;
            this.cbispwd.Location = new System.Drawing.Point(159, 94);
            this.cbispwd.Name = "cbispwd";
            this.cbispwd.Size = new System.Drawing.Size(96, 16);
            this.cbispwd.TabIndex = 24;
            this.cbispwd.Text = "启用访问密码";
            this.cbispwd.UseVisualStyleBackColor = true;
            // 
            // tbacspwd
            // 
            this.tbacspwd.Location = new System.Drawing.Point(223, 56);
            this.tbacspwd.Name = "tbacspwd";
            this.tbacspwd.Size = new System.Drawing.Size(81, 21);
            this.tbacspwd.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(156, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 22;
            this.label8.Text = "访问密码";
            // 
            // cbisaddiondata
            // 
            this.cbisaddiondata.AutoSize = true;
            this.cbisaddiondata.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbisaddiondata.Location = new System.Drawing.Point(9, 94);
            this.cbisaddiondata.Name = "cbisaddiondata";
            this.cbisaddiondata.Size = new System.Drawing.Size(110, 18);
            this.cbisaddiondata.TabIndex = 20;
            this.cbisaddiondata.Text = "启用附加数据";
            this.cbisaddiondata.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("楷体_GB2312", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(297, 421);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 39);
            this.button1.TabIndex = 21;
            this.button1.Text = "确认";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // gbsecureread
            // 
            this.gbsecureread.Controls.Add(this.cbissecureread);
            this.gbsecureread.Controls.Add(this.cbbsrtagtype);
            this.gbsecureread.Controls.Add(this.label18);
            this.gbsecureread.Controls.Add(this.cbbsrpwdtype);
            this.gbsecureread.Controls.Add(this.label17);
            this.gbsecureread.Controls.Add(this.tbindexbitsnum);
            this.gbsecureread.Controls.Add(this.label16);
            this.gbsecureread.Controls.Add(this.tbsrindexstartbit);
            this.gbsecureread.Controls.Add(this.label15);
            this.gbsecureread.Controls.Add(this.tbsracspwd);
            this.gbsecureread.Controls.Add(this.label14);
            this.gbsecureread.Controls.Add(this.cbbsrbank);
            this.gbsecureread.Controls.Add(this.label13);
            this.gbsecureread.Controls.Add(this.tbsrblks);
            this.gbsecureread.Controls.Add(this.label12);
            this.gbsecureread.Controls.Add(this.tbsraddress);
            this.gbsecureread.Controls.Add(this.label11);
            this.gbsecureread.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbsecureread.Location = new System.Drawing.Point(14, 244);
            this.gbsecureread.Name = "gbsecureread";
            this.gbsecureread.Size = new System.Drawing.Size(310, 160);
            this.gbsecureread.TabIndex = 23;
            this.gbsecureread.TabStop = false;
            this.gbsecureread.Text = "安全附加数据";
            // 
            // cbissecureread
            // 
            this.cbissecureread.AutoSize = true;
            this.cbissecureread.Location = new System.Drawing.Point(10, 134);
            this.cbissecureread.Name = "cbissecureread";
            this.cbissecureread.Size = new System.Drawing.Size(120, 16);
            this.cbissecureread.TabIndex = 34;
            this.cbissecureread.Text = "启用安全附加数据";
            this.cbissecureread.UseVisualStyleBackColor = true;
            // 
            // cbbsrtagtype
            // 
            this.cbbsrtagtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbsrtagtype.FormattingEnabled = true;
            this.cbbsrtagtype.Items.AddRange(new object[] {
            "H3",
            "M4"});
            this.cbbsrtagtype.Location = new System.Drawing.Point(223, 100);
            this.cbbsrtagtype.Name = "cbbsrtagtype";
            this.cbbsrtagtype.Size = new System.Drawing.Size(72, 20);
            this.cbbsrtagtype.TabIndex = 33;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(153, 106);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 32;
            this.label18.Text = "标签类型";
            // 
            // cbbsrpwdtype
            // 
            this.cbbsrpwdtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbsrpwdtype.FormattingEnabled = true;
            this.cbbsrpwdtype.Items.AddRange(new object[] {
            "固定密码",
            "推算密码"});
            this.cbbsrpwdtype.Location = new System.Drawing.Point(75, 100);
            this.cbbsrpwdtype.Name = "cbbsrpwdtype";
            this.cbbsrpwdtype.Size = new System.Drawing.Size(72, 20);
            this.cbbsrpwdtype.TabIndex = 31;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 106);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 30;
            this.label17.Text = "密码类型";
            // 
            // tbindexbitsnum
            // 
            this.tbindexbitsnum.Location = new System.Drawing.Point(223, 73);
            this.tbindexbitsnum.Name = "tbindexbitsnum";
            this.tbindexbitsnum.Size = new System.Drawing.Size(72, 21);
            this.tbindexbitsnum.TabIndex = 29;
            this.tbindexbitsnum.Text = "8";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(153, 77);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 12);
            this.label16.TabIndex = 28;
            this.label16.Text = "索引bit数";
            // 
            // tbsrindexstartbit
            // 
            this.tbsrindexstartbit.Location = new System.Drawing.Point(75, 73);
            this.tbsrindexstartbit.Name = "tbsrindexstartbit";
            this.tbsrindexstartbit.Size = new System.Drawing.Size(72, 21);
            this.tbsrindexstartbit.TabIndex = 27;
            this.tbsrindexstartbit.Text = "96";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 77);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 26;
            this.label15.Text = "索引起始";
            // 
            // tbsracspwd
            // 
            this.tbsracspwd.Location = new System.Drawing.Point(223, 46);
            this.tbsracspwd.Name = "tbsracspwd";
            this.tbsracspwd.Size = new System.Drawing.Size(72, 21);
            this.tbsracspwd.TabIndex = 25;
            this.tbsracspwd.Text = "00000000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(153, 50);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 24;
            this.label14.Text = "访问密码";
            // 
            // cbbsrbank
            // 
            this.cbbsrbank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbsrbank.FormattingEnabled = true;
            this.cbbsrbank.Items.AddRange(new object[] {
            "Reservebank",
            "EPCbank",
            "TIDbank",
            "USERbank"});
            this.cbbsrbank.Location = new System.Drawing.Point(75, 47);
            this.cbbsrbank.Name = "cbbsrbank";
            this.cbbsrbank.Size = new System.Drawing.Size(72, 20);
            this.cbbsrbank.TabIndex = 20;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 50);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 4;
            this.label13.Text = "bank";
            // 
            // tbsrblks
            // 
            this.tbsrblks.Location = new System.Drawing.Point(223, 18);
            this.tbsrblks.Name = "tbsrblks";
            this.tbsrblks.Size = new System.Drawing.Size(72, 21);
            this.tbsrblks.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(153, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "读块数";
            // 
            // tbsraddress
            // 
            this.tbsraddress.Location = new System.Drawing.Point(75, 18);
            this.tbsraddress.Name = "tbsraddress";
            this.tbsraddress.Size = new System.Drawing.Size(72, 21);
            this.tbsraddress.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "起始地址";
            // 
            // gbpotlweight
            // 
            this.gbpotlweight.Controls.Add(this.tbwtipx256);
            this.gbpotlweight.Controls.Add(this.label22);
            this.gbpotlweight.Controls.Add(this.tbwtipx64);
            this.gbpotlweight.Controls.Add(this.label21);
            this.gbpotlweight.Controls.Add(this.tbwt180006b);
            this.gbpotlweight.Controls.Add(this.label20);
            this.gbpotlweight.Controls.Add(this.tbwtgen2);
            this.gbpotlweight.Controls.Add(this.label19);
            this.gbpotlweight.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbpotlweight.Location = new System.Drawing.Point(349, 98);
            this.gbpotlweight.Name = "gbpotlweight";
            this.gbpotlweight.Size = new System.Drawing.Size(310, 49);
            this.gbpotlweight.TabIndex = 27;
            this.gbpotlweight.TabStop = false;
            this.gbpotlweight.Text = "协议权重";
            // 
            // tbwtipx256
            // 
            this.tbwtipx256.Location = new System.Drawing.Point(269, 17);
            this.tbwtipx256.Name = "tbwtipx256";
            this.tbwtipx256.Size = new System.Drawing.Size(33, 21);
            this.tbwtipx256.TabIndex = 7;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(228, 21);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 12);
            this.label22.TabIndex = 6;
            this.label22.Text = "ipx256";
            // 
            // tbwtipx64
            // 
            this.tbwtipx64.Location = new System.Drawing.Point(193, 17);
            this.tbwtipx64.Name = "tbwtipx64";
            this.tbwtipx64.Size = new System.Drawing.Size(33, 21);
            this.tbwtipx64.TabIndex = 5;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(156, 21);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 12);
            this.label21.TabIndex = 4;
            this.label21.Text = "ipx64";
            // 
            // tbwt180006b
            // 
            this.tbwt180006b.Location = new System.Drawing.Point(122, 18);
            this.tbwt180006b.Name = "tbwt180006b";
            this.tbwt180006b.Size = new System.Drawing.Size(33, 21);
            this.tbwt180006b.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(74, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 12);
            this.label20.TabIndex = 2;
            this.label20.Text = "180006b";
            // 
            // tbwtgen2
            // 
            this.tbwtgen2.Location = new System.Drawing.Point(39, 18);
            this.tbwtgen2.Name = "tbwtgen2";
            this.tbwtgen2.Size = new System.Drawing.Size(33, 21);
            this.tbwtgen2.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(9, 21);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "gen2";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbisOneReadOneTime);
            this.groupBox3.Controls.Add(this.cbisReadFixCount);
            this.groupBox3.Controls.Add(this.tbReadCount);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.cbisrevertants);
            this.groupBox3.Controls.Add(this.tbreaddur);
            this.groupBox3.Controls.Add(this.tbsleepdur);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.Location = new System.Drawing.Point(349, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(309, 78);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Inventory周期";
            // 
            // cbisOneReadOneTime
            // 
            this.cbisOneReadOneTime.AutoSize = true;
            this.cbisOneReadOneTime.Location = new System.Drawing.Point(112, 52);
            this.cbisOneReadOneTime.Name = "cbisOneReadOneTime";
            this.cbisOneReadOneTime.Size = new System.Drawing.Size(72, 16);
            this.cbisOneReadOneTime.TabIndex = 21;
            this.cbisOneReadOneTime.Text = "单次计数";
            this.cbisOneReadOneTime.UseVisualStyleBackColor = true;
            // 
            // cbisReadFixCount
            // 
            this.cbisReadFixCount.AutoSize = true;
            this.cbisReadFixCount.Location = new System.Drawing.Point(196, 52);
            this.cbisReadFixCount.Name = "cbisReadFixCount";
            this.cbisReadFixCount.Size = new System.Drawing.Size(108, 16);
            this.cbisReadFixCount.TabIndex = 20;
            this.cbisReadFixCount.Text = "完成读次数停止";
            this.cbisReadFixCount.UseVisualStyleBackColor = true;
            this.cbisReadFixCount.CheckedChanged += new System.EventHandler(this.cbisReadFixCount_CheckedChanged);
            // 
            // tbReadCount
            // 
            this.tbReadCount.Location = new System.Drawing.Point(256, 21);
            this.tbReadCount.Name = "tbReadCount";
            this.tbReadCount.Size = new System.Drawing.Size(46, 21);
            this.tbReadCount.TabIndex = 19;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(212, 25);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 12);
            this.label39.TabIndex = 18;
            this.label39.Text = "读次数";
            // 
            // cbisrevertants
            // 
            this.cbisrevertants.AutoSize = true;
            this.cbisrevertants.Location = new System.Drawing.Point(10, 52);
            this.cbisrevertants.Name = "cbisrevertants";
            this.cbisrevertants.Size = new System.Drawing.Size(72, 16);
            this.cbisrevertants.TabIndex = 17;
            this.cbisrevertants.Text = "逆序天线";
            this.cbisrevertants.UseVisualStyleBackColor = true;
            // 
            // tbreaddur
            // 
            this.tbreaddur.Location = new System.Drawing.Point(54, 20);
            this.tbreaddur.Name = "tbreaddur";
            this.tbreaddur.Size = new System.Drawing.Size(46, 21);
            this.tbreaddur.TabIndex = 16;
            // 
            // tbsleepdur
            // 
            this.tbsleepdur.Location = new System.Drawing.Point(156, 20);
            this.tbsleepdur.Name = "tbsleepdur";
            this.tbsleepdur.Size = new System.Drawing.Size(46, 21);
            this.tbsleepdur.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(110, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 15;
            this.label10.Text = "读间隔";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 15;
            this.label9.Text = "读时长";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbisunibyant);
            this.groupBox2.Controls.Add(this.cbischgcolor);
            this.groupBox2.Controls.Add(this.cbisunibynullemd);
            this.groupBox2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(349, 360);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(309, 44);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "数据显示";
            // 
            // cbisunibyant
            // 
            this.cbisunibyant.AutoSize = true;
            this.cbisunibyant.Location = new System.Drawing.Point(225, 20);
            this.cbisunibyant.Name = "cbisunibyant";
            this.cbisunibyant.Size = new System.Drawing.Size(72, 16);
            this.cbisunibyant.TabIndex = 2;
            this.cbisunibyant.Text = "天线唯一";
            this.cbisunibyant.UseVisualStyleBackColor = true;
            // 
            // cbischgcolor
            // 
            this.cbischgcolor.AutoSize = true;
            this.cbischgcolor.Location = new System.Drawing.Point(134, 20);
            this.cbischgcolor.Name = "cbischgcolor";
            this.cbischgcolor.Size = new System.Drawing.Size(72, 16);
            this.cbischgcolor.TabIndex = 1;
            this.cbischgcolor.Text = "颜色变化";
            this.cbischgcolor.UseVisualStyleBackColor = true;
            // 
            // cbisunibynullemd
            // 
            this.cbisunibynullemd.AutoSize = true;
            this.cbisunibynullemd.Location = new System.Drawing.Point(19, 21);
            this.cbisunibynullemd.Name = "cbisunibynullemd";
            this.cbisunibynullemd.Size = new System.Drawing.Size(96, 16);
            this.cbisunibynullemd.TabIndex = 0;
            this.cbisunibynullemd.Text = "附加数据唯一";
            this.cbisunibynullemd.UseVisualStyleBackColor = true;
            // 
            // gbidentifyants
            // 
            this.gbidentifyants.Controls.Add(this.label38);
            this.gbidentifyants.Controls.Add(this.label37);
            this.gbidentifyants.Controls.Add(this.rbidtantafter);
            this.gbidentifyants.Controls.Add(this.rbidtantbydur);
            this.gbidentifyants.Controls.Add(this.tbafttime);
            this.gbidentifyants.Controls.Add(this.label36);
            this.gbidentifyants.Controls.Add(this.label35);
            this.gbidentifyants.Controls.Add(this.tbidtdur);
            this.gbidentifyants.Controls.Add(this.cbisidtant);
            this.gbidentifyants.Location = new System.Drawing.Point(349, 250);
            this.gbidentifyants.Name = "gbidentifyants";
            this.gbidentifyants.Size = new System.Drawing.Size(309, 104);
            this.gbidentifyants.TabIndex = 31;
            this.gbidentifyants.TabStop = false;
            this.gbidentifyants.Text = "智能识别";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(257, 55);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 12);
            this.label38.TabIndex = 33;
            this.label38.Text = "(秒)";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(257, 26);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(41, 12);
            this.label37.TabIndex = 32;
            this.label37.Text = "(毫秒)";
            // 
            // rbidtantafter
            // 
            this.rbidtantafter.AutoSize = true;
            this.rbidtantafter.Location = new System.Drawing.Point(19, 51);
            this.rbidtantafter.Name = "rbidtantafter";
            this.rbidtantafter.Size = new System.Drawing.Size(59, 16);
            this.rbidtantafter.TabIndex = 31;
            this.rbidtantafter.TabStop = true;
            this.rbidtantafter.Text = "后判决";
            this.rbidtantafter.UseVisualStyleBackColor = true;
            this.rbidtantafter.CheckedChanged += new System.EventHandler(this.rbidtantafter_CheckedChanged);
            // 
            // rbidtantbydur
            // 
            this.rbidtantbydur.AutoSize = true;
            this.rbidtantbydur.Location = new System.Drawing.Point(19, 24);
            this.rbidtantbydur.Name = "rbidtantbydur";
            this.rbidtantbydur.Size = new System.Drawing.Size(71, 16);
            this.rbidtantbydur.TabIndex = 8;
            this.rbidtantbydur.TabStop = true;
            this.rbidtantbydur.Text = "时段判决";
            this.rbidtantbydur.UseVisualStyleBackColor = true;
            this.rbidtantbydur.CheckedChanged += new System.EventHandler(this.rbidtantbydur_CheckedChanged);
            // 
            // tbafttime
            // 
            this.tbafttime.Location = new System.Drawing.Point(175, 51);
            this.tbafttime.Name = "tbafttime";
            this.tbafttime.Size = new System.Drawing.Size(75, 21);
            this.tbafttime.TabIndex = 7;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(120, 55);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(53, 12);
            this.label36.TabIndex = 6;
            this.label36.Text = "等待时间";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(120, 26);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 12);
            this.label35.TabIndex = 5;
            this.label35.Text = "判决时间";
            // 
            // tbidtdur
            // 
            this.tbidtdur.Location = new System.Drawing.Point(175, 21);
            this.tbidtdur.Name = "tbidtdur";
            this.tbidtdur.Size = new System.Drawing.Size(74, 21);
            this.tbidtdur.TabIndex = 4;
            // 
            // cbisidtant
            // 
            this.cbisidtant.AutoSize = true;
            this.cbisidtant.Location = new System.Drawing.Point(19, 78);
            this.cbisidtant.Name = "cbisidtant";
            this.cbisidtant.Size = new System.Drawing.Size(96, 16);
            this.cbisidtant.TabIndex = 0;
            this.cbisidtant.Text = "启用天线识别";
            this.cbisidtant.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cbbreadresult);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.cbbantcnt);
            this.groupBox4.Controls.Add(this.cbbtagcnt);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.btnSetCase);
            this.groupBox4.Controls.Add(this.cbishighspeed);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Location = new System.Drawing.Point(349, 158);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(309, 81);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "应用场景";
            // 
            // cbbreadresult
            // 
            this.cbbreadresult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbreadresult.FormattingEnabled = true;
            this.cbbreadresult.Items.AddRange(new object[] {
            "较高读取次数_防冲突下降",
            "最低读取次数_防冲突优先",
            "最高读取次数_牺牲防冲突"});
            this.cbbreadresult.Location = new System.Drawing.Point(146, 18);
            this.cbbreadresult.Name = "cbbreadresult";
            this.cbbreadresult.Size = new System.Drawing.Size(156, 20);
            this.cbbreadresult.TabIndex = 13;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(94, 23);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 12;
            this.label24.Text = "读取效果";
            // 
            // cbbantcnt
            // 
            this.cbbantcnt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbantcnt.FormattingEnabled = true;
            this.cbbantcnt.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cbbantcnt.Location = new System.Drawing.Point(86, 46);
            this.cbbantcnt.Name = "cbbantcnt";
            this.cbbantcnt.Size = new System.Drawing.Size(35, 20);
            this.cbbantcnt.TabIndex = 11;
            // 
            // cbbtagcnt
            // 
            this.cbbtagcnt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbtagcnt.FormattingEnabled = true;
            this.cbbtagcnt.Items.AddRange(new object[] {
            "小于10",
            "10-40",
            "40-100",
            "100-200",
            "大于200"});
            this.cbbtagcnt.Location = new System.Drawing.Point(179, 46);
            this.cbbtagcnt.Name = "cbbtagcnt";
            this.cbbtagcnt.Size = new System.Drawing.Size(70, 20);
            this.cbbtagcnt.TabIndex = 10;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(125, 51);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 9;
            this.label23.Text = "标签个数";
            // 
            // btnSetCase
            // 
            this.btnSetCase.Location = new System.Drawing.Point(255, 46);
            this.btnSetCase.Name = "btnSetCase";
            this.btnSetCase.Size = new System.Drawing.Size(47, 23);
            this.btnSetCase.TabIndex = 8;
            this.btnSetCase.Text = "确定";
            this.btnSetCase.UseVisualStyleBackColor = true;
            this.btnSetCase.Click += new System.EventHandler(this.btnSetCase_Click);
            // 
            // cbishighspeed
            // 
            this.cbishighspeed.AutoSize = true;
            this.cbishighspeed.Location = new System.Drawing.Point(10, 22);
            this.cbishighspeed.Name = "cbishighspeed";
            this.cbishighspeed.Size = new System.Drawing.Size(84, 16);
            this.cbishighspeed.TabIndex = 5;
            this.cbishighspeed.Text = "高链路速率";
            this.cbishighspeed.UseVisualStyleBackColor = true;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(9, 51);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(77, 12);
            this.label40.TabIndex = 0;
            this.label40.Text = "使用天线个数";
            // 
            // InventoryParasform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 468);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.gbidentifyants);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbpotlweight);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gbsecureread);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gbemddata);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "InventoryParasform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "盘存参数";
            this.Load += new System.EventHandler(this.InventoryParasform_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbemddata.ResumeLayout(false);
            this.gbemddata.PerformLayout();
            this.gbsecureread.ResumeLayout(false);
            this.gbsecureread.PerformLayout();
            this.gbpotlweight.ResumeLayout(false);
            this.gbpotlweight.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbidentifyants.ResumeLayout(false);
            this.gbidentifyants.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbbfilterrule;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbbfilterbank;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbfilteraddr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox cbisfilter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbfilterdata;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbebstartaddr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbbebbank;
        private System.Windows.Forms.GroupBox gbemddata;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox cbisaddiondata;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbacspwd;
        private System.Windows.Forms.CheckBox cbispwd;
        private System.Windows.Forms.TextBox tbebbytescnt;
        private System.Windows.Forms.GroupBox gbsecureread;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbsracspwd;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbbsrbank;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbsrblks;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbsraddress;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbbsrtagtype;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cbbsrpwdtype;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbindexbitsnum;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbsrindexstartbit;
        private System.Windows.Forms.CheckBox cbissecureread;
        private System.Windows.Forms.GroupBox gbpotlweight;
        private System.Windows.Forms.TextBox tbwtipx256;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbwtipx64;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbwt180006b;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbwtgen2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cbisrevertants;
        private System.Windows.Forms.TextBox tbreaddur;
        private System.Windows.Forms.TextBox tbsleepdur;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cbisunibynullemd;
        private System.Windows.Forms.CheckBox cbischgcolor;
        private System.Windows.Forms.CheckBox cbisunibyant;
        private System.Windows.Forms.GroupBox gbidentifyants;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.RadioButton rbidtantafter;
        private System.Windows.Forms.RadioButton rbidtantbydur;
        private System.Windows.Forms.TextBox tbafttime;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox tbidtdur;
        private System.Windows.Forms.CheckBox cbisidtant;
        private System.Windows.Forms.TextBox tbReadCount;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.CheckBox cbisReadFixCount;
        private System.Windows.Forms.CheckBox cbisOneReadOneTime;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button btnSetCase;
        private System.Windows.Forms.CheckBox cbishighspeed;
        private System.Windows.Forms.ComboBox cbbtagcnt;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cbbantcnt;
        private System.Windows.Forms.ComboBox cbbreadresult;
        private System.Windows.Forms.Label label24;
    }
}