﻿namespace CarManager
{
    partial class Ffare
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Breset = new System.Windows.Forms.Button();
            this.Bsubmit = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.Tfare3 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.Tfare2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Tfare1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.Ct32 = new System.Windows.Forms.ComboBox();
            this.Ct31 = new System.Windows.Forms.ComboBox();
            this.Ct22 = new System.Windows.Forms.ComboBox();
            this.Ct21 = new System.Windows.Forms.ComboBox();
            this.Ct12 = new System.Windows.Forms.ComboBox();
            this.Ct11 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Ccarclass = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Breset);
            this.groupBox2.Controls.Add(this.Bsubmit);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.Tfare3);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.Tfare2);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.Tfare1);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.Ct32);
            this.groupBox2.Controls.Add(this.Ct31);
            this.groupBox2.Controls.Add(this.Ct22);
            this.groupBox2.Controls.Add(this.Ct21);
            this.groupBox2.Controls.Add(this.Ct12);
            this.groupBox2.Controls.Add(this.Ct11);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.Ccarclass);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(353, 198);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            // 
            // Breset
            // 
            this.Breset.Location = new System.Drawing.Point(179, 158);
            this.Breset.Name = "Breset";
            this.Breset.Size = new System.Drawing.Size(75, 23);
            this.Breset.TabIndex = 29;
            this.Breset.Text = "重置";
            this.Breset.UseVisualStyleBackColor = true;
            this.Breset.Click += new System.EventHandler(this.Breset_Click);
            // 
            // Bsubmit
            // 
            this.Bsubmit.Location = new System.Drawing.Point(56, 158);
            this.Bsubmit.Name = "Bsubmit";
            this.Bsubmit.Size = new System.Drawing.Size(75, 23);
            this.Bsubmit.TabIndex = 29;
            this.Bsubmit.Text = "提交";
            this.Bsubmit.UseVisualStyleBackColor = true;
            this.Bsubmit.Click += new System.EventHandler(this.Bsubmit_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(270, 122);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 12);
            this.label24.TabIndex = 28;
            this.label24.Text = "元/小时";
            // 
            // Tfare3
            // 
            this.Tfare3.Location = new System.Drawing.Point(238, 119);
            this.Tfare3.Name = "Tfare3";
            this.Tfare3.Size = new System.Drawing.Size(26, 21);
            this.Tfare3.TabIndex = 27;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(270, 96);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 12);
            this.label23.TabIndex = 26;
            this.label23.Text = "元/小时";
            // 
            // Tfare2
            // 
            this.Tfare2.Location = new System.Drawing.Point(238, 93);
            this.Tfare2.Name = "Tfare2";
            this.Tfare2.Size = new System.Drawing.Size(26, 21);
            this.Tfare2.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(270, 69);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 12);
            this.label12.TabIndex = 24;
            this.label12.Text = "元/小时";
            // 
            // Tfare1
            // 
            this.Tfare1.Location = new System.Drawing.Point(238, 66);
            this.Tfare1.Name = "Tfare1";
            this.Tfare1.Size = new System.Drawing.Size(26, 21);
            this.Tfare1.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(156, 96);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 12);
            this.label13.TabIndex = 22;
            this.label13.Text = "到";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(156, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 12);
            this.label14.TabIndex = 22;
            this.label14.Text = "到";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(156, 70);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(17, 12);
            this.label15.TabIndex = 21;
            this.label15.Text = "到";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(90, 122);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(17, 12);
            this.label16.TabIndex = 20;
            this.label16.Text = "从";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(90, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(17, 12);
            this.label17.TabIndex = 19;
            this.label17.Text = "从";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(92, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(17, 12);
            this.label18.TabIndex = 18;
            this.label18.Text = "从";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(20, 122);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 12);
            this.label19.TabIndex = 17;
            this.label19.Text = "时间段三：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 96);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 12);
            this.label20.TabIndex = 16;
            this.label20.Text = "时间段二：";
            // 
            // Ct32
            // 
            this.Ct32.FormattingEnabled = true;
            this.Ct32.Location = new System.Drawing.Point(179, 119);
            this.Ct32.Name = "Ct32";
            this.Ct32.Size = new System.Drawing.Size(37, 20);
            this.Ct32.TabIndex = 15;
            // 
            // Ct31
            // 
            this.Ct31.FormattingEnabled = true;
            this.Ct31.Location = new System.Drawing.Point(113, 119);
            this.Ct31.Name = "Ct31";
            this.Ct31.Size = new System.Drawing.Size(37, 20);
            this.Ct31.TabIndex = 14;
            // 
            // Ct22
            // 
            this.Ct22.FormattingEnabled = true;
            this.Ct22.Location = new System.Drawing.Point(179, 93);
            this.Ct22.Name = "Ct22";
            this.Ct22.Size = new System.Drawing.Size(37, 20);
            this.Ct22.TabIndex = 13;
            this.Ct22.SelectedValueChanged += new System.EventHandler(this.Ct22_SelectedValueChanged);
            // 
            // Ct21
            // 
            this.Ct21.FormattingEnabled = true;
            this.Ct21.Location = new System.Drawing.Point(113, 93);
            this.Ct21.Name = "Ct21";
            this.Ct21.Size = new System.Drawing.Size(37, 20);
            this.Ct21.TabIndex = 12;
            // 
            // Ct12
            // 
            this.Ct12.FormattingEnabled = true;
            this.Ct12.Location = new System.Drawing.Point(179, 67);
            this.Ct12.Name = "Ct12";
            this.Ct12.Size = new System.Drawing.Size(37, 20);
            this.Ct12.TabIndex = 11;
            this.Ct12.SelectedValueChanged += new System.EventHandler(this.Ct12_SelectedValueChanged);
            // 
            // Ct11
            // 
            this.Ct11.FormattingEnabled = true;
            this.Ct11.Location = new System.Drawing.Point(113, 67);
            this.Ct11.Name = "Ct11";
            this.Ct11.Size = new System.Drawing.Size(37, 20);
            this.Ct11.TabIndex = 10;
            this.Ct11.SelectedValueChanged += new System.EventHandler(this.Ct11_SelectedValueChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(20, 70);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 12);
            this.label21.TabIndex = 9;
            this.label21.Text = "时间段一：";
            // 
            // Ccarclass
            // 
            this.Ccarclass.FormattingEnabled = true;
            this.Ccarclass.Location = new System.Drawing.Point(113, 27);
            this.Ccarclass.Name = "Ccarclass";
            this.Ccarclass.Size = new System.Drawing.Size(75, 20);
            this.Ccarclass.TabIndex = 8;
            this.Ccarclass.SelectedValueChanged += new System.EventHandler(this.Ccarclass_SelectedValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(20, 30);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 7;
            this.label22.Text = "车辆型号：";
            // 
            // Ffare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 214);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(394, 250);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(394, 250);
            this.Name = "Ffare";
            this.Text = "费率调整";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Bsubmit;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox Tfare3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox Tfare2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Tfare1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox Ct32;
        private System.Windows.Forms.ComboBox Ct31;
        private System.Windows.Forms.ComboBox Ct22;
        private System.Windows.Forms.ComboBox Ct21;
        private System.Windows.Forms.ComboBox Ct12;
        private System.Windows.Forms.ComboBox Ct11;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox Ccarclass;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button Breset;



    }
}