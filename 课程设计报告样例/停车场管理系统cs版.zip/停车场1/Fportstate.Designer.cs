﻿namespace CarManager
{
    partial class Fportstate
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        public  void InitializeComponent()
        {
            this.Pdrawdetail = new System.Windows.Forms.Panel();
            this.Pdrawstate = new System.Windows.Forms.Panel();
            this.PportB = new System.Windows.Forms.Panel();
            this.PportA = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.管理员添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.管理员查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车主信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车主信息添加ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车主信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.费率管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.费率管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.容量管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车辆入库ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车辆入库ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.数据管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车辆管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出入日志ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.应用程序ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.重置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清零ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.退出button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Pdrawdetail
            // 
            this.Pdrawdetail.BackColor = System.Drawing.Color.LightGray;
            this.Pdrawdetail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Pdrawdetail.Location = new System.Drawing.Point(630, 105);
            this.Pdrawdetail.Name = "Pdrawdetail";
            this.Pdrawdetail.Size = new System.Drawing.Size(342, 334);
            this.Pdrawdetail.TabIndex = 12;
            // 
            // Pdrawstate
            // 
            this.Pdrawstate.BackColor = System.Drawing.Color.LightGray;
            this.Pdrawstate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Pdrawstate.Location = new System.Drawing.Point(630, 13);
            this.Pdrawstate.Name = "Pdrawstate";
            this.Pdrawstate.Size = new System.Drawing.Size(342, 85);
            this.Pdrawstate.TabIndex = 11;
            // 
            // PportB
            // 
            this.PportB.BackColor = System.Drawing.Color.LightSalmon;
            this.PportB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PportB.Location = new System.Drawing.Point(415, 14);
            this.PportB.Name = "PportB";
            this.PportB.Size = new System.Drawing.Size(200, 425);
            this.PportB.TabIndex = 9;
            // 
            // PportA
            // 
            this.PportA.BackColor = System.Drawing.Color.LightSteelBlue;
            this.PportA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PportA.Location = new System.Drawing.Point(199, 14);
            this.PportA.Name = "PportA";
            this.PportA.Size = new System.Drawing.Size(200, 425);
            this.PportA.TabIndex = 8;
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.LightGray;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 0, 0, 2);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.车主信息管理ToolStripMenuItem,
            this.费率管理ToolStripMenuItem,
            this.车辆入库ToolStripMenuItem,
            this.数据管理ToolStripMenuItem,
            this.应用程序ToolStripMenuItem,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(13, 169);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(6, 60, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(150, 340);
            this.menuStrip1.Stretch = false;
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.管理员添加ToolStripMenuItem,
            this.管理员查询ToolStripMenuItem,
            this.修改信息ToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(143, 25);
            this.toolStripMenuItem1.Text = "系统管理员";
            // 
            // 管理员添加ToolStripMenuItem
            // 
            this.管理员添加ToolStripMenuItem.Name = "管理员添加ToolStripMenuItem";
            this.管理员添加ToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.管理员添加ToolStripMenuItem.Text = "管理员添加";
            this.管理员添加ToolStripMenuItem.Click += new System.EventHandler(this.管理员添加ToolStripMenuItem_Click);
            // 
            // 管理员查询ToolStripMenuItem
            // 
            this.管理员查询ToolStripMenuItem.Name = "管理员查询ToolStripMenuItem";
            this.管理员查询ToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.管理员查询ToolStripMenuItem.Text = "管理员查询";
            this.管理员查询ToolStripMenuItem.Click += new System.EventHandler(this.管理员查询ToolStripMenuItem_Click);
            // 
            // 修改信息ToolStripMenuItem
            // 
            this.修改信息ToolStripMenuItem.Name = "修改信息ToolStripMenuItem";
            this.修改信息ToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.修改信息ToolStripMenuItem.Text = "修改信息";
            this.修改信息ToolStripMenuItem.Click += new System.EventHandler(this.修改信息ToolStripMenuItem_Click);
            // 
            // 车主信息管理ToolStripMenuItem
            // 
            this.车主信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.车主信息添加ToolStripMenuItem,
            this.车主信息查询ToolStripMenuItem});
            this.车主信息管理ToolStripMenuItem.Name = "车主信息管理ToolStripMenuItem";
            this.车主信息管理ToolStripMenuItem.Size = new System.Drawing.Size(143, 25);
            this.车主信息管理ToolStripMenuItem.Text = "车主信息管理";
            // 
            // 车主信息添加ToolStripMenuItem
            // 
            this.车主信息添加ToolStripMenuItem.Name = "车主信息添加ToolStripMenuItem";
            this.车主信息添加ToolStripMenuItem.Size = new System.Drawing.Size(176, 26);
            this.车主信息添加ToolStripMenuItem.Text = "车主信息添加";
            this.车主信息添加ToolStripMenuItem.Click += new System.EventHandler(this.车主信息添加ToolStripMenuItem_Click);
            // 
            // 车主信息查询ToolStripMenuItem
            // 
            this.车主信息查询ToolStripMenuItem.Name = "车主信息查询ToolStripMenuItem";
            this.车主信息查询ToolStripMenuItem.Size = new System.Drawing.Size(176, 26);
            this.车主信息查询ToolStripMenuItem.Text = "车主信息查询";
            this.车主信息查询ToolStripMenuItem.Click += new System.EventHandler(this.车主信息查询ToolStripMenuItem_Click);
            // 
            // 费率管理ToolStripMenuItem
            // 
            this.费率管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.费率管理ToolStripMenuItem1,
            this.容量管理ToolStripMenuItem});
            this.费率管理ToolStripMenuItem.Name = "费率管理ToolStripMenuItem";
            this.费率管理ToolStripMenuItem.Size = new System.Drawing.Size(143, 25);
            this.费率管理ToolStripMenuItem.Text = "车库管理";
            // 
            // 费率管理ToolStripMenuItem1
            // 
            this.费率管理ToolStripMenuItem1.Name = "费率管理ToolStripMenuItem1";
            this.费率管理ToolStripMenuItem1.Size = new System.Drawing.Size(144, 26);
            this.费率管理ToolStripMenuItem1.Text = "费率管理";
            this.费率管理ToolStripMenuItem1.Click += new System.EventHandler(this.费率管理ToolStripMenuItem1_Click);
            // 
            // 容量管理ToolStripMenuItem
            // 
            this.容量管理ToolStripMenuItem.Name = "容量管理ToolStripMenuItem";
            this.容量管理ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.容量管理ToolStripMenuItem.Text = "容量管理";
            this.容量管理ToolStripMenuItem.Click += new System.EventHandler(this.容量管理ToolStripMenuItem_Click);
            // 
            // 车辆入库ToolStripMenuItem
            // 
            this.车辆入库ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.车辆入库ToolStripMenuItem1});
            this.车辆入库ToolStripMenuItem.Name = "车辆入库ToolStripMenuItem";
            this.车辆入库ToolStripMenuItem.Size = new System.Drawing.Size(143, 25);
            this.车辆入库ToolStripMenuItem.Text = "车辆入库";
            // 
            // 车辆入库ToolStripMenuItem1
            // 
            this.车辆入库ToolStripMenuItem1.Name = "车辆入库ToolStripMenuItem1";
            this.车辆入库ToolStripMenuItem1.Size = new System.Drawing.Size(144, 26);
            this.车辆入库ToolStripMenuItem1.Text = "车辆入库";
            this.车辆入库ToolStripMenuItem1.Click += new System.EventHandler(this.车辆入库ToolStripMenuItem1_Click);
            // 
            // 数据管理ToolStripMenuItem
            // 
            this.数据管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.车辆管理ToolStripMenuItem,
            this.出入日志ToolStripMenuItem});
            this.数据管理ToolStripMenuItem.Name = "数据管理ToolStripMenuItem";
            this.数据管理ToolStripMenuItem.Size = new System.Drawing.Size(143, 25);
            this.数据管理ToolStripMenuItem.Text = "数据管理";
            // 
            // 车辆管理ToolStripMenuItem
            // 
            this.车辆管理ToolStripMenuItem.Name = "车辆管理ToolStripMenuItem";
            this.车辆管理ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.车辆管理ToolStripMenuItem.Text = "车辆管理";
            this.车辆管理ToolStripMenuItem.Click += new System.EventHandler(this.车辆管理ToolStripMenuItem_Click);
            // 
            // 出入日志ToolStripMenuItem
            // 
            this.出入日志ToolStripMenuItem.Name = "出入日志ToolStripMenuItem";
            this.出入日志ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.出入日志ToolStripMenuItem.Text = "出入日志";
            this.出入日志ToolStripMenuItem.Click += new System.EventHandler(this.出入日志ToolStripMenuItem_Click);
            // 
            // 应用程序ToolStripMenuItem
            // 
            this.应用程序ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.重置ToolStripMenuItem,
            this.清零ToolStripMenuItem});
            this.应用程序ToolStripMenuItem.Name = "应用程序ToolStripMenuItem";
            this.应用程序ToolStripMenuItem.Size = new System.Drawing.Size(143, 25);
            this.应用程序ToolStripMenuItem.Text = "应用程序";
            // 
            // 重置ToolStripMenuItem
            // 
            this.重置ToolStripMenuItem.Name = "重置ToolStripMenuItem";
            this.重置ToolStripMenuItem.Size = new System.Drawing.Size(112, 26);
            this.重置ToolStripMenuItem.Text = "重置";
            this.重置ToolStripMenuItem.Click += new System.EventHandler(this.重置ToolStripMenuItem_Click);
            // 
            // 清零ToolStripMenuItem
            // 
            this.清零ToolStripMenuItem.Name = "清零ToolStripMenuItem";
            this.清零ToolStripMenuItem.Size = new System.Drawing.Size(112, 26);
            this.清零ToolStripMenuItem.Text = "清零";
            this.清零ToolStripMenuItem.Click += new System.EventHandler(this.清零ToolStripMenuItem_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.帮助ToolStripMenuItem1,
            this.关于ToolStripMenuItem});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(143, 25);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 帮助ToolStripMenuItem1
            // 
            this.帮助ToolStripMenuItem1.Name = "帮助ToolStripMenuItem1";
            this.帮助ToolStripMenuItem1.Size = new System.Drawing.Size(112, 26);
            this.帮助ToolStripMenuItem1.Text = "帮助";
            this.帮助ToolStripMenuItem1.Click += new System.EventHandler(this.帮助ToolStripMenuItem1_Click);
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(112, 26);
            this.关于ToolStripMenuItem.Text = "关于";
            this.关于ToolStripMenuItem.Click += new System.EventHandler(this.关于ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(199, 449);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(773, 60);
            this.panel1.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(13, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 27);
            this.label1.TabIndex = 15;
            this.label1.Text = "功能栏";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 27);
            this.label2.TabIndex = 16;
            this.label2.Text = "管理员";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.Controls.Add(this.退出button1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 14);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(150, 152);
            this.panel2.TabIndex = 17;
            // 
            // 退出button1
            // 
            this.退出button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.退出button1.Location = new System.Drawing.Point(35, 110);
            this.退出button1.Name = "退出button1";
            this.退出button1.Size = new System.Drawing.Size(75, 23);
            this.退出button1.TabIndex = 22;
            this.退出button1.Text = "退出登录";
            this.退出button1.UseVisualStyleBackColor = true;
            this.退出button1.Click += new System.EventHandler(this.退出button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(72, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 17);
            this.label7.TabIndex = 21;
            this.label7.Text = "在线";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(72, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 17);
            this.label6.TabIndex = 20;
            this.label6.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(20, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 17);
            this.label5.TabIndex = 19;
            this.label5.Text = "状态：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(71, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 17);
            this.label4.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(20, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 17;
            this.label3.Text = "名称：";
            // 
            // Fportstate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 511);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Pdrawdetail);
            this.Controls.Add(this.Pdrawstate);
            this.Controls.Add(this.PportB);
            this.Controls.Add(this.PportA);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1000, 550);
            this.MinimumSize = new System.Drawing.Size(1000, 550);
            this.Name = "Fportstate";
            this.Text = "车库状态";
            this.Shown += new System.EventHandler(this.Fportstate_Shown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Pdrawdetail;
        private System.Windows.Forms.Panel Pdrawstate;
        private System.Windows.Forms.Panel PportB;
        private System.Windows.Forms.Panel PportA;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 车辆入库ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车辆入库ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车辆管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出入日志ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 应用程序ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清零ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem 费率管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 费率管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 容量管理ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 管理员添加ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 管理员查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车主信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车主信息添加ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车主信息查询ToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button 退出button1;
    }
}