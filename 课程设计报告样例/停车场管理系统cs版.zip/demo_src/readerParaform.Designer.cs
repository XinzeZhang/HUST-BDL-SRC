﻿namespace ModuleReaderManager
{
    partial class readerParaform
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.labfirmware = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labMoudevir = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbipaddr = new System.Windows.Forms.TextBox();
            this.tbsubnet = new System.Windows.Forms.TextBox();
            this.tbgateway = new System.Windows.Forms.TextBox();
            this.gpipinfo = new System.Windows.Forms.GroupBox();
            this.btnipset = new System.Windows.Forms.Button();
            this.gpwificonf = new System.Windows.Forms.GroupBox();
            this.cbbkeytype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbwifikey = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.tbwifissid = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.cbbwifiauth = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.btnipget = new System.Windows.Forms.Button();
            this.rbnettypewifi = new System.Windows.Forms.RadioButton();
            this.rbnettypeeth = new System.Windows.Forms.RadioButton();
            this.cbmacset = new System.Windows.Forms.CheckBox();
            this.tbMacAddr = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tbant4rpwr = new System.Windows.Forms.TextBox();
            this.tbant3rpwr = new System.Windows.Forms.TextBox();
            this.tbant1rpwr = new System.Windows.Forms.TextBox();
            this.tbant2rpwr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tbant4wpwr = new System.Windows.Forms.TextBox();
            this.btnpwrset = new System.Windows.Forms.Button();
            this.btnpwrget = new System.Windows.Forms.Button();
            this.tbant3wpwr = new System.Windows.Forms.TextBox();
            this.tbant2wpwr = new System.Windows.Forms.TextBox();
            this.tbant1wpwr = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lvhoptb = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.label9 = new System.Windows.Forms.Label();
            this.cbbregion = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.allcheckBox = new System.Windows.Forms.CheckBox();
            this.btnsetrg = new System.Windows.Forms.Button();
            this.btngetrg = new System.Windows.Forms.Button();
            this.btnsethtb = new System.Windows.Forms.Button();
            this.btngethtb = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btngetgpi = new System.Windows.Forms.Button();
            this.cbgpi4 = new System.Windows.Forms.CheckBox();
            this.btnsetgpo = new System.Windows.Forms.Button();
            this.cbgpi1 = new System.Windows.Forms.CheckBox();
            this.cbgpi2 = new System.Windows.Forms.CheckBox();
            this.cbgpo4 = new System.Windows.Forms.CheckBox();
            this.cbgpi3 = new System.Windows.Forms.CheckBox();
            this.cbgpo3 = new System.Windows.Forms.CheckBox();
            this.cbgpo2 = new System.Windows.Forms.CheckBox();
            this.cbgpo1 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.labmainboard = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.labmodule = new System.Windows.Forms.Label();
            this.cbbgen2encode = new System.Windows.Forms.ComboBox();
            this.btngetgen2encode = new System.Windows.Forms.Button();
            this.btnsetgen2encode = new System.Windows.Forms.Button();
            this.cbbgen2blf = new System.Windows.Forms.ComboBox();
            this.btngetgen2blf = new System.Windows.Forms.Button();
            this.btnsetgen2blf = new System.Windows.Forms.Button();
            this.btnpermsave = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btnerasesave = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btngetntp = new System.Windows.Forms.Button();
            this.btnSetNtp = new System.Windows.Forms.Button();
            this.tbNtpServerip = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.rbisntpfalse = new System.Windows.Forms.RadioButton();
            this.rbntptrue = new System.Windows.Forms.RadioButton();
            this.btniso183kblfset = new System.Windows.Forms.Button();
            this.btniso183kblfget = new System.Windows.Forms.Button();
            this.tbIso183kblf = new System.Windows.Forms.TextBox();
            this.cbbwritemode = new System.Windows.Forms.ComboBox();
            this.btnGetWriteMode = new System.Windows.Forms.Button();
            this.btnSetWriteMode = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnsetdataantunique = new System.Windows.Forms.Button();
            this.btngetdataantunique = new System.Windows.Forms.Button();
            this.rbtagdataisnoant = new System.Windows.Forms.RadioButton();
            this.rbtagdataisant = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btnsetdataemdunique = new System.Windows.Forms.Button();
            this.btngetdataemdunique = new System.Windows.Forms.Button();
            this.rbtagdataisnoemd = new System.Windows.Forms.RadioButton();
            this.rbtagdataisemd = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btnsetdatarechrssi = new System.Windows.Forms.Button();
            this.btngetdatarechrssi = new System.Windows.Forms.Button();
            this.rbtagdataisnorecrssi = new System.Windows.Forms.RadioButton();
            this.rbtagdataisrecrssi = new System.Windows.Forms.RadioButton();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btnsetgen2tari = new System.Windows.Forms.Button();
            this.btngetgen2tari = new System.Windows.Forms.Button();
            this.cbbgen2tari = new System.Windows.Forms.ComboBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.tbbytesreadflash = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.btnreadflash = new System.Windows.Forms.Button();
            this.btnflashwrtie = new System.Windows.Forms.Button();
            this.tbfwaddress = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tbfwdata = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.btngetgen2target = new System.Windows.Forms.Button();
            this.btnsetgen2target = new System.Windows.Forms.Button();
            this.cbbgen2target = new System.Windows.Forms.ComboBox();
            this.cbbGen2Q = new System.Windows.Forms.ComboBox();
            this.cbbsession = new System.Windows.Forms.ComboBox();
            this.btngettemperature = new System.Windows.Forms.Button();
            this.labtemperature = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.btngen2sessset = new System.Windows.Forms.Button();
            this.btnge2sessget = new System.Windows.Forms.Button();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.btngen2qset = new System.Windows.Forms.Button();
            this.btngen2qget = new System.Windows.Forms.Button();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.btndetantsset = new System.Windows.Forms.Button();
            this.btndetantsget = new System.Windows.Forms.Button();
            this.cbbdetectants = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnsetmel = new System.Windows.Forms.Button();
            this.btngetmel = new System.Windows.Forms.Button();
            this.cbbMaxEPCLength = new System.Windows.Forms.ComboBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.gbantvswr = new System.Windows.Forms.GroupBox();
            this.btnvswrdetect = new System.Windows.Forms.Button();
            this.tbant4vswr = new System.Windows.Forms.TextBox();
            this.tbant3vswr = new System.Windows.Forms.TextBox();
            this.tbant2vswr = new System.Windows.Forms.TextBox();
            this.tbant1vswr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.cbbinvmode = new System.Windows.Forms.ComboBox();
            this.btngetinvmode = new System.Windows.Forms.Button();
            this.btnsetinvmode = new System.Windows.Forms.Button();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.cbb6bmoddepth = new System.Windows.Forms.ComboBox();
            this.btnget6bmoddepth = new System.Windows.Forms.Button();
            this.btnset6bmoddepth = new System.Windows.Forms.Button();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.cbb6bdelimiter = new System.Windows.Forms.ComboBox();
            this.btnget6bdelimiter = new System.Windows.Forms.Button();
            this.btnset6bdelimiter = new System.Windows.Forms.Button();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.tbreaderlogname = new System.Windows.Forms.TextBox();
            this.btngetrdrlogname = new System.Windows.Forms.Button();
            this.btnsetrdrlogname = new System.Windows.Forms.Button();
            this.gpipinfo.SuspendLayout();
            this.gpwificonf.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.gbantvswr.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.SuspendLayout();
            // 
            // labfirmware
            // 
            this.labfirmware.AutoSize = true;
            this.labfirmware.Location = new System.Drawing.Point(714, 16);
            this.labfirmware.Name = "labfirmware";
            this.labfirmware.Size = new System.Drawing.Size(41, 12);
            this.labfirmware.TabIndex = 7;
            this.labfirmware.Text = "label9";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(649, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "软件版本：";
            // 
            // labMoudevir
            // 
            this.labMoudevir.AutoSize = true;
            this.labMoudevir.Location = new System.Drawing.Point(512, 16);
            this.labMoudevir.Name = "labMoudevir";
            this.labMoudevir.Size = new System.Drawing.Size(41, 12);
            this.labMoudevir.TabIndex = 1;
            this.labMoudevir.Text = "label3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(447, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "硬件版本：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "IP地址";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(149, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "子网掩码";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 10;
            this.label8.Text = "网关";
            // 
            // tbipaddr
            // 
            this.tbipaddr.Location = new System.Drawing.Point(49, 15);
            this.tbipaddr.Name = "tbipaddr";
            this.tbipaddr.Size = new System.Drawing.Size(97, 21);
            this.tbipaddr.TabIndex = 12;
            // 
            // tbsubnet
            // 
            this.tbsubnet.Location = new System.Drawing.Point(209, 15);
            this.tbsubnet.Name = "tbsubnet";
            this.tbsubnet.Size = new System.Drawing.Size(97, 21);
            this.tbsubnet.TabIndex = 13;
            // 
            // tbgateway
            // 
            this.tbgateway.Location = new System.Drawing.Point(49, 43);
            this.tbgateway.Name = "tbgateway";
            this.tbgateway.Size = new System.Drawing.Size(97, 21);
            this.tbgateway.TabIndex = 14;
            // 
            // gpipinfo
            // 
            this.gpipinfo.Controls.Add(this.btnipset);
            this.gpipinfo.Controls.Add(this.gpwificonf);
            this.gpipinfo.Controls.Add(this.btnipget);
            this.gpipinfo.Controls.Add(this.rbnettypewifi);
            this.gpipinfo.Controls.Add(this.rbnettypeeth);
            this.gpipinfo.Controls.Add(this.cbmacset);
            this.gpipinfo.Controls.Add(this.tbMacAddr);
            this.gpipinfo.Controls.Add(this.label21);
            this.gpipinfo.Controls.Add(this.tbipaddr);
            this.gpipinfo.Controls.Add(this.label5);
            this.gpipinfo.Controls.Add(this.tbgateway);
            this.gpipinfo.Controls.Add(this.label7);
            this.gpipinfo.Controls.Add(this.tbsubnet);
            this.gpipinfo.Controls.Add(this.label8);
            this.gpipinfo.Location = new System.Drawing.Point(19, 39);
            this.gpipinfo.Name = "gpipinfo";
            this.gpipinfo.Size = new System.Drawing.Size(406, 130);
            this.gpipinfo.TabIndex = 15;
            this.gpipinfo.TabStop = false;
            this.gpipinfo.Text = "IP信息";
            // 
            // btnipset
            // 
            this.btnipset.Location = new System.Drawing.Point(331, 101);
            this.btnipset.Name = "btnipset";
            this.btnipset.Size = new System.Drawing.Size(62, 23);
            this.btnipset.TabIndex = 7;
            this.btnipset.Text = "设置";
            this.btnipset.UseVisualStyleBackColor = true;
            this.btnipset.Click += new System.EventHandler(this.btnipset_Click);
            // 
            // gpwificonf
            // 
            this.gpwificonf.Controls.Add(this.cbbkeytype);
            this.gpwificonf.Controls.Add(this.label1);
            this.gpwificonf.Controls.Add(this.tbwifikey);
            this.gpwificonf.Controls.Add(this.label35);
            this.gpwificonf.Controls.Add(this.tbwifissid);
            this.gpwificonf.Controls.Add(this.label34);
            this.gpwificonf.Controls.Add(this.cbbwifiauth);
            this.gpwificonf.Controls.Add(this.label33);
            this.gpwificonf.Location = new System.Drawing.Point(3, 65);
            this.gpwificonf.Name = "gpwificonf";
            this.gpwificonf.Size = new System.Drawing.Size(309, 59);
            this.gpwificonf.TabIndex = 20;
            this.gpwificonf.TabStop = false;
            this.gpwificonf.Text = "Wifi设置";
            // 
            // cbbkeytype
            // 
            this.cbbkeytype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbkeytype.FormattingEnabled = true;
            this.cbbkeytype.Items.AddRange(new object[] {
            "ASC2码",
            "16进制"});
            this.cbbkeytype.Location = new System.Drawing.Point(53, 36);
            this.cbbkeytype.Name = "cbbkeytype";
            this.cbbkeytype.Size = new System.Drawing.Size(88, 20);
            this.cbbkeytype.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "密钥类型";
            // 
            // tbwifikey
            // 
            this.tbwifikey.Location = new System.Drawing.Point(179, 36);
            this.tbwifikey.Name = "tbwifikey";
            this.tbwifikey.Size = new System.Drawing.Size(111, 21);
            this.tbwifikey.TabIndex = 5;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(147, 39);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(23, 12);
            this.label35.TabIndex = 4;
            this.label35.Text = "key";
            // 
            // tbwifissid
            // 
            this.tbwifissid.Location = new System.Drawing.Point(179, 14);
            this.tbwifissid.Name = "tbwifissid";
            this.tbwifissid.Size = new System.Drawing.Size(111, 21);
            this.tbwifissid.TabIndex = 3;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(147, 18);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 12);
            this.label34.TabIndex = 2;
            this.label34.Text = "ssid";
            // 
            // cbbwifiauth
            // 
            this.cbbwifiauth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbwifiauth.FormattingEnabled = true;
            this.cbbwifiauth.Items.AddRange(new object[] {
            "OPEN",
            "OPEN WEP",
            "SHARED WEP",
            "WPA-PSK",
            "WPA2-PSK"});
            this.cbbwifiauth.Location = new System.Drawing.Point(53, 15);
            this.cbbwifiauth.Name = "cbbwifiauth";
            this.cbbwifiauth.Size = new System.Drawing.Size(88, 20);
            this.cbbwifiauth.TabIndex = 1;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(2, 18);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(53, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "加密模式";
            // 
            // btnipget
            // 
            this.btnipget.Location = new System.Drawing.Point(331, 74);
            this.btnipget.Name = "btnipget";
            this.btnipget.Size = new System.Drawing.Size(63, 23);
            this.btnipget.TabIndex = 6;
            this.btnipget.Text = "获取";
            this.btnipget.UseVisualStyleBackColor = true;
            this.btnipget.Click += new System.EventHandler(this.btnipget_Click);
            // 
            // rbnettypewifi
            // 
            this.rbnettypewifi.AutoSize = true;
            this.rbnettypewifi.Location = new System.Drawing.Point(357, 14);
            this.rbnettypewifi.Name = "rbnettypewifi";
            this.rbnettypewifi.Size = new System.Drawing.Size(47, 16);
            this.rbnettypewifi.TabIndex = 19;
            this.rbnettypewifi.TabStop = true;
            this.rbnettypewifi.Text = "Wifi";
            this.rbnettypewifi.UseVisualStyleBackColor = true;
            this.rbnettypewifi.CheckedChanged += new System.EventHandler(this.rbnettypewifi_CheckedChanged);
            // 
            // rbnettypeeth
            // 
            this.rbnettypeeth.AutoSize = true;
            this.rbnettypeeth.Location = new System.Drawing.Point(312, 14);
            this.rbnettypeeth.Name = "rbnettypeeth";
            this.rbnettypeeth.Size = new System.Drawing.Size(47, 16);
            this.rbnettypeeth.TabIndex = 18;
            this.rbnettypeeth.TabStop = true;
            this.rbnettypeeth.Text = "以太";
            this.rbnettypeeth.UseVisualStyleBackColor = true;
            this.rbnettypeeth.CheckedChanged += new System.EventHandler(this.rbnettypeeth_CheckedChanged);
            // 
            // cbmacset
            // 
            this.cbmacset.AutoSize = true;
            this.cbmacset.Location = new System.Drawing.Point(322, 46);
            this.cbmacset.Name = "cbmacset";
            this.cbmacset.Size = new System.Drawing.Size(72, 16);
            this.cbmacset.TabIndex = 17;
            this.cbmacset.Text = "手动指定";
            this.cbmacset.UseVisualStyleBackColor = true;
            this.cbmacset.CheckedChanged += new System.EventHandler(this.cbmacset_CheckedChanged);
            // 
            // tbMacAddr
            // 
            this.tbMacAddr.Location = new System.Drawing.Point(209, 43);
            this.tbMacAddr.Name = "tbMacAddr";
            this.tbMacAddr.Size = new System.Drawing.Size(97, 21);
            this.tbMacAddr.TabIndex = 16;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(149, 46);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 12);
            this.label21.TabIndex = 15;
            this.label21.Text = "MAC地址";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.tbant4rpwr);
            this.groupBox4.Controls.Add(this.tbant3rpwr);
            this.groupBox4.Controls.Add(this.tbant1rpwr);
            this.groupBox4.Controls.Add(this.tbant2rpwr);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.tbant4wpwr);
            this.groupBox4.Controls.Add(this.btnpwrset);
            this.groupBox4.Controls.Add(this.btnpwrget);
            this.groupBox4.Controls.Add(this.tbant3wpwr);
            this.groupBox4.Controls.Add(this.tbant2wpwr);
            this.groupBox4.Controls.Add(this.tbant1wpwr);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Location = new System.Drawing.Point(5, 15);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(398, 65);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "功率设置";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1, 18);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 12);
            this.label25.TabIndex = 77;
            this.label25.Text = "读功率:";
            // 
            // tbant4rpwr
            // 
            this.tbant4rpwr.Location = new System.Drawing.Point(312, 13);
            this.tbant4rpwr.Name = "tbant4rpwr";
            this.tbant4rpwr.Size = new System.Drawing.Size(37, 21);
            this.tbant4rpwr.TabIndex = 92;
            // 
            // tbant3rpwr
            // 
            this.tbant3rpwr.Location = new System.Drawing.Point(236, 13);
            this.tbant3rpwr.Name = "tbant3rpwr";
            this.tbant3rpwr.Size = new System.Drawing.Size(37, 21);
            this.tbant3rpwr.TabIndex = 91;
            // 
            // tbant1rpwr
            // 
            this.tbant1rpwr.Location = new System.Drawing.Point(83, 13);
            this.tbant1rpwr.Name = "tbant1rpwr";
            this.tbant1rpwr.Size = new System.Drawing.Size(37, 21);
            this.tbant1rpwr.TabIndex = 86;
            // 
            // tbant2rpwr
            // 
            this.tbant2rpwr.Location = new System.Drawing.Point(158, 13);
            this.tbant2rpwr.Name = "tbant2rpwr";
            this.tbant2rpwr.Size = new System.Drawing.Size(37, 21);
            this.tbant2rpwr.TabIndex = 90;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(45, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 85;
            this.label11.Text = "天线１";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(120, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 87;
            this.label12.Text = "天线２";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(198, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 88;
            this.label13.Text = "天线３";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(275, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 89;
            this.label14.Text = "天线４";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(1, 43);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 12);
            this.label23.TabIndex = 70;
            this.label23.Text = "写功率:";
            // 
            // tbant4wpwr
            // 
            this.tbant4wpwr.Location = new System.Drawing.Point(312, 39);
            this.tbant4wpwr.Name = "tbant4wpwr";
            this.tbant4wpwr.Size = new System.Drawing.Size(36, 21);
            this.tbant4wpwr.TabIndex = 23;
            // 
            // btnpwrset
            // 
            this.btnpwrset.Location = new System.Drawing.Point(354, 38);
            this.btnpwrset.Name = "btnpwrset";
            this.btnpwrset.Size = new System.Drawing.Size(41, 23);
            this.btnpwrset.TabIndex = 8;
            this.btnpwrset.Text = "设置";
            this.btnpwrset.UseVisualStyleBackColor = true;
            this.btnpwrset.Click += new System.EventHandler(this.btnpwrset_Click);
            // 
            // btnpwrget
            // 
            this.btnpwrget.Location = new System.Drawing.Point(354, 12);
            this.btnpwrget.Name = "btnpwrget";
            this.btnpwrget.Size = new System.Drawing.Size(40, 23);
            this.btnpwrget.TabIndex = 69;
            this.btnpwrget.Text = "获取";
            this.btnpwrget.UseVisualStyleBackColor = true;
            this.btnpwrget.Click += new System.EventHandler(this.btnpwrget_Click);
            // 
            // tbant3wpwr
            // 
            this.tbant3wpwr.Location = new System.Drawing.Point(237, 39);
            this.tbant3wpwr.Name = "tbant3wpwr";
            this.tbant3wpwr.Size = new System.Drawing.Size(37, 21);
            this.tbant3wpwr.TabIndex = 22;
            // 
            // tbant2wpwr
            // 
            this.tbant2wpwr.Location = new System.Drawing.Point(160, 39);
            this.tbant2wpwr.Name = "tbant2wpwr";
            this.tbant2wpwr.Size = new System.Drawing.Size(37, 21);
            this.tbant2wpwr.TabIndex = 21;
            // 
            // tbant1wpwr
            // 
            this.tbant1wpwr.Location = new System.Drawing.Point(83, 39);
            this.tbant1wpwr.Name = "tbant1wpwr";
            this.tbant1wpwr.Size = new System.Drawing.Size(37, 21);
            this.tbant1wpwr.TabIndex = 17;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(274, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 20;
            this.label15.Text = "天线４";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(199, 44);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 19;
            this.label16.Text = "天线３";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(122, 44);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 12);
            this.label17.TabIndex = 18;
            this.label17.Text = "天线２";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(45, 44);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 17;
            this.label18.Text = "天线１";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 21;
            this.label3.Text = "调频表";
            // 
            // lvhoptb
            // 
            this.lvhoptb.CheckBoxes = true;
            this.lvhoptb.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.lvhoptb.GridLines = true;
            this.lvhoptb.LabelEdit = true;
            this.lvhoptb.Location = new System.Drawing.Point(9, 95);
            this.lvhoptb.Name = "lvhoptb";
            this.lvhoptb.Size = new System.Drawing.Size(95, 185);
            this.lvhoptb.TabIndex = 22;
            this.lvhoptb.UseCompatibleStateImageBehavior = false;
            this.lvhoptb.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "条目";
            this.columnHeader1.Width = 69;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 23;
            this.label9.Text = "区域设置";
            // 
            // cbbregion
            // 
            this.cbbregion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbregion.FormattingEnabled = true;
            this.cbbregion.Items.AddRange(new object[] {
            "中国",
            "北美",
            "日本",
            "韩国",
            "欧洲",
            "印度",
            "加拿大",
            "全频段",
            "中国2",
            "840-925"});
            this.cbbregion.Location = new System.Drawing.Point(9, 38);
            this.cbbregion.Name = "cbbregion";
            this.cbbregion.Size = new System.Drawing.Size(94, 20);
            this.cbbregion.TabIndex = 24;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.allcheckBox);
            this.groupBox5.Controls.Add(this.btnsetrg);
            this.groupBox5.Controls.Add(this.btngetrg);
            this.groupBox5.Controls.Add(this.btnsethtb);
            this.groupBox5.Controls.Add(this.btngethtb);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.lvhoptb);
            this.groupBox5.Controls.Add(this.cbbregion);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Location = new System.Drawing.Point(741, 253);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(115, 330);
            this.groupBox5.TabIndex = 25;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "频率管制规则";
            // 
            // allcheckBox
            // 
            this.allcheckBox.AutoSize = true;
            this.allcheckBox.Location = new System.Drawing.Point(28, 286);
            this.allcheckBox.Name = "allcheckBox";
            this.allcheckBox.Size = new System.Drawing.Size(48, 16);
            this.allcheckBox.TabIndex = 32;
            this.allcheckBox.Text = "全选";
            this.allcheckBox.UseVisualStyleBackColor = true;
            this.allcheckBox.CheckedChanged += new System.EventHandler(this.allcheckBox_CheckedChanged);
            // 
            // btnsetrg
            // 
            this.btnsetrg.Location = new System.Drawing.Point(61, 66);
            this.btnsetrg.Name = "btnsetrg";
            this.btnsetrg.Size = new System.Drawing.Size(43, 23);
            this.btnsetrg.TabIndex = 28;
            this.btnsetrg.Text = "设置";
            this.btnsetrg.UseVisualStyleBackColor = true;
            this.btnsetrg.Click += new System.EventHandler(this.btnsetrg_Click);
            // 
            // btngetrg
            // 
            this.btngetrg.Location = new System.Drawing.Point(9, 66);
            this.btngetrg.Name = "btngetrg";
            this.btngetrg.Size = new System.Drawing.Size(44, 23);
            this.btngetrg.TabIndex = 27;
            this.btngetrg.Text = "获取";
            this.btngetrg.UseVisualStyleBackColor = true;
            this.btngetrg.Click += new System.EventHandler(this.btngetrg_Click);
            // 
            // btnsethtb
            // 
            this.btnsethtb.Location = new System.Drawing.Point(62, 302);
            this.btnsethtb.Name = "btnsethtb";
            this.btnsethtb.Size = new System.Drawing.Size(42, 23);
            this.btnsethtb.TabIndex = 26;
            this.btnsethtb.Text = "设置";
            this.btnsethtb.UseVisualStyleBackColor = true;
            this.btnsethtb.Click += new System.EventHandler(this.btnsethtb_Click);
            // 
            // btngethtb
            // 
            this.btngethtb.Location = new System.Drawing.Point(9, 302);
            this.btngethtb.Name = "btngethtb";
            this.btngethtb.Size = new System.Drawing.Size(44, 23);
            this.btngethtb.TabIndex = 25;
            this.btngethtb.Text = "获取";
            this.btngethtb.UseVisualStyleBackColor = true;
            this.btngethtb.Click += new System.EventHandler(this.btngethtb_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btngetgpi);
            this.groupBox6.Controls.Add(this.cbgpi4);
            this.groupBox6.Controls.Add(this.btnsetgpo);
            this.groupBox6.Controls.Add(this.cbgpi1);
            this.groupBox6.Controls.Add(this.cbgpi2);
            this.groupBox6.Controls.Add(this.cbgpo4);
            this.groupBox6.Controls.Add(this.cbgpi3);
            this.groupBox6.Controls.Add(this.cbgpo3);
            this.groupBox6.Controls.Add(this.cbgpo2);
            this.groupBox6.Controls.Add(this.cbgpo1);
            this.groupBox6.Location = new System.Drawing.Point(602, 249);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(111, 174);
            this.groupBox6.TabIndex = 26;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "GPIO";
            // 
            // btngetgpi
            // 
            this.btngetgpi.Location = new System.Drawing.Point(10, 139);
            this.btngetgpi.Name = "btngetgpi";
            this.btngetgpi.Size = new System.Drawing.Size(43, 23);
            this.btngetgpi.TabIndex = 34;
            this.btngetgpi.Text = "获取";
            this.btngetgpi.UseVisualStyleBackColor = true;
            this.btngetgpi.Click += new System.EventHandler(this.btngetgpi_Click);
            // 
            // cbgpi4
            // 
            this.cbgpi4.AutoSize = true;
            this.cbgpi4.Location = new System.Drawing.Point(61, 117);
            this.cbgpi4.Name = "cbgpi4";
            this.cbgpi4.Size = new System.Drawing.Size(48, 16);
            this.cbgpi4.TabIndex = 33;
            this.cbgpi4.Text = "GPI4";
            this.cbgpi4.UseVisualStyleBackColor = true;
            // 
            // btnsetgpo
            // 
            this.btnsetgpo.Location = new System.Drawing.Point(10, 65);
            this.btnsetgpo.Name = "btnsetgpo";
            this.btnsetgpo.Size = new System.Drawing.Size(41, 23);
            this.btnsetgpo.TabIndex = 39;
            this.btnsetgpo.Text = "设置";
            this.btnsetgpo.UseVisualStyleBackColor = true;
            this.btnsetgpo.Click += new System.EventHandler(this.btnsetgpo_Click);
            // 
            // cbgpi1
            // 
            this.cbgpi1.AutoSize = true;
            this.cbgpi1.Location = new System.Drawing.Point(10, 93);
            this.cbgpi1.Name = "cbgpi1";
            this.cbgpi1.Size = new System.Drawing.Size(48, 16);
            this.cbgpi1.TabIndex = 30;
            this.cbgpi1.Text = "GPI1";
            this.cbgpi1.UseVisualStyleBackColor = true;
            // 
            // cbgpi2
            // 
            this.cbgpi2.AutoSize = true;
            this.cbgpi2.Location = new System.Drawing.Point(61, 93);
            this.cbgpi2.Name = "cbgpi2";
            this.cbgpi2.Size = new System.Drawing.Size(48, 16);
            this.cbgpi2.TabIndex = 31;
            this.cbgpi2.Text = "GPI2";
            this.cbgpi2.UseVisualStyleBackColor = true;
            // 
            // cbgpo4
            // 
            this.cbgpo4.AutoSize = true;
            this.cbgpo4.Location = new System.Drawing.Point(60, 43);
            this.cbgpo4.Name = "cbgpo4";
            this.cbgpo4.Size = new System.Drawing.Size(48, 16);
            this.cbgpo4.TabIndex = 38;
            this.cbgpo4.Text = "GPO4";
            this.cbgpo4.UseVisualStyleBackColor = true;
            // 
            // cbgpi3
            // 
            this.cbgpi3.AutoSize = true;
            this.cbgpi3.Location = new System.Drawing.Point(10, 117);
            this.cbgpi3.Name = "cbgpi3";
            this.cbgpi3.Size = new System.Drawing.Size(48, 16);
            this.cbgpi3.TabIndex = 32;
            this.cbgpi3.Text = "GPI3";
            this.cbgpi3.UseVisualStyleBackColor = true;
            // 
            // cbgpo3
            // 
            this.cbgpo3.AutoSize = true;
            this.cbgpo3.Location = new System.Drawing.Point(9, 43);
            this.cbgpo3.Name = "cbgpo3";
            this.cbgpo3.Size = new System.Drawing.Size(48, 16);
            this.cbgpo3.TabIndex = 37;
            this.cbgpo3.Text = "GPO3";
            this.cbgpo3.UseVisualStyleBackColor = true;
            // 
            // cbgpo2
            // 
            this.cbgpo2.AutoSize = true;
            this.cbgpo2.Location = new System.Drawing.Point(60, 19);
            this.cbgpo2.Name = "cbgpo2";
            this.cbgpo2.Size = new System.Drawing.Size(48, 16);
            this.cbgpo2.TabIndex = 36;
            this.cbgpo2.Text = "GPO2";
            this.cbgpo2.UseVisualStyleBackColor = true;
            // 
            // cbgpo1
            // 
            this.cbgpo1.AutoSize = true;
            this.cbgpo1.Location = new System.Drawing.Point(9, 19);
            this.cbgpo1.Name = "cbgpo1";
            this.cbgpo1.Size = new System.Drawing.Size(48, 16);
            this.cbgpo1.TabIndex = 35;
            this.cbgpo1.Text = "GPO1";
            this.cbgpo1.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(23, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 28;
            this.label22.Text = "主板类型：";
            // 
            // labmainboard
            // 
            this.labmainboard.AutoSize = true;
            this.labmainboard.Location = new System.Drawing.Point(88, 16);
            this.labmainboard.Name = "labmainboard";
            this.labmainboard.Size = new System.Drawing.Size(47, 12);
            this.labmainboard.TabIndex = 29;
            this.labmainboard.Text = "label23";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(211, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 30;
            this.label24.Text = "射频类型：";
            // 
            // labmodule
            // 
            this.labmodule.AutoSize = true;
            this.labmodule.Location = new System.Drawing.Point(275, 16);
            this.labmodule.Name = "labmodule";
            this.labmodule.Size = new System.Drawing.Size(47, 12);
            this.labmodule.TabIndex = 31;
            this.labmodule.Text = "label25";
            // 
            // cbbgen2encode
            // 
            this.cbbgen2encode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbgen2encode.FormattingEnabled = true;
            this.cbbgen2encode.Items.AddRange(new object[] {
            "FM0",
            "M2",
            "M4",
            "M8"});
            this.cbbgen2encode.Location = new System.Drawing.Point(11, 18);
            this.cbbgen2encode.Name = "cbbgen2encode";
            this.cbbgen2encode.Size = new System.Drawing.Size(89, 20);
            this.cbbgen2encode.TabIndex = 33;
            // 
            // btngetgen2encode
            // 
            this.btngetgen2encode.Location = new System.Drawing.Point(11, 44);
            this.btngetgen2encode.Name = "btngetgen2encode";
            this.btngetgen2encode.Size = new System.Drawing.Size(41, 23);
            this.btngetgen2encode.TabIndex = 34;
            this.btngetgen2encode.Text = "获取";
            this.btngetgen2encode.UseVisualStyleBackColor = true;
            this.btngetgen2encode.Click += new System.EventHandler(this.btngetgen2encode_Click);
            // 
            // btnsetgen2encode
            // 
            this.btnsetgen2encode.Location = new System.Drawing.Point(65, 44);
            this.btnsetgen2encode.Name = "btnsetgen2encode";
            this.btnsetgen2encode.Size = new System.Drawing.Size(41, 23);
            this.btnsetgen2encode.TabIndex = 35;
            this.btnsetgen2encode.Text = "设置";
            this.btnsetgen2encode.UseVisualStyleBackColor = true;
            this.btnsetgen2encode.Click += new System.EventHandler(this.btnsetgen2encode_Click);
            // 
            // cbbgen2blf
            // 
            this.cbbgen2blf.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbgen2blf.FormattingEnabled = true;
            this.cbbgen2blf.Items.AddRange(new object[] {
            "40",
            "250",
            "400",
            "640"});
            this.cbbgen2blf.Location = new System.Drawing.Point(10, 17);
            this.cbbgen2blf.Name = "cbbgen2blf";
            this.cbbgen2blf.Size = new System.Drawing.Size(89, 20);
            this.cbbgen2blf.TabIndex = 37;
            // 
            // btngetgen2blf
            // 
            this.btngetgen2blf.Location = new System.Drawing.Point(9, 43);
            this.btngetgen2blf.Name = "btngetgen2blf";
            this.btngetgen2blf.Size = new System.Drawing.Size(41, 23);
            this.btngetgen2blf.TabIndex = 38;
            this.btngetgen2blf.Text = "获取";
            this.btngetgen2blf.UseVisualStyleBackColor = true;
            this.btngetgen2blf.Click += new System.EventHandler(this.btngetgen2blf_Click);
            // 
            // btnsetgen2blf
            // 
            this.btnsetgen2blf.Location = new System.Drawing.Point(60, 43);
            this.btnsetgen2blf.Name = "btnsetgen2blf";
            this.btnsetgen2blf.Size = new System.Drawing.Size(41, 23);
            this.btnsetgen2blf.TabIndex = 39;
            this.btnsetgen2blf.Text = "设置";
            this.btnsetgen2blf.UseVisualStyleBackColor = true;
            this.btnsetgen2blf.Click += new System.EventHandler(this.btnsetgen2blf_Click);
            // 
            // btnpermsave
            // 
            this.btnpermsave.Location = new System.Drawing.Point(27, 22);
            this.btnpermsave.Name = "btnpermsave";
            this.btnpermsave.Size = new System.Drawing.Size(64, 23);
            this.btnpermsave.TabIndex = 40;
            this.btnpermsave.Text = "永久保存";
            this.btnpermsave.UseVisualStyleBackColor = true;
            this.btnpermsave.Click += new System.EventHandler(this.btnpermsave_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btnerasesave);
            this.groupBox8.Controls.Add(this.btnpermsave);
            this.groupBox8.Location = new System.Drawing.Point(453, 333);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(122, 81);
            this.groupBox8.TabIndex = 41;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "永久保存设置";
            // 
            // btnerasesave
            // 
            this.btnerasesave.Location = new System.Drawing.Point(27, 52);
            this.btnerasesave.Name = "btnerasesave";
            this.btnerasesave.Size = new System.Drawing.Size(64, 23);
            this.btnerasesave.TabIndex = 42;
            this.btnerasesave.Text = "擦除";
            this.btnerasesave.UseVisualStyleBackColor = true;
            this.btnerasesave.Click += new System.EventHandler(this.btnerasesave_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btngetntp);
            this.groupBox9.Controls.Add(this.btnSetNtp);
            this.groupBox9.Controls.Add(this.tbNtpServerip);
            this.groupBox9.Controls.Add(this.label26);
            this.groupBox9.Controls.Add(this.rbisntpfalse);
            this.groupBox9.Controls.Add(this.rbntptrue);
            this.groupBox9.Location = new System.Drawing.Point(15, 548);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(568, 36);
            this.groupBox9.TabIndex = 42;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "NTP设置";
            // 
            // btngetntp
            // 
            this.btngetntp.Location = new System.Drawing.Point(447, 11);
            this.btngetntp.Name = "btngetntp";
            this.btngetntp.Size = new System.Drawing.Size(43, 23);
            this.btngetntp.TabIndex = 43;
            this.btngetntp.Text = "获取";
            this.btngetntp.UseVisualStyleBackColor = true;
            this.btngetntp.Click += new System.EventHandler(this.btngetntp_Click);
            // 
            // btnSetNtp
            // 
            this.btnSetNtp.Location = new System.Drawing.Point(508, 11);
            this.btnSetNtp.Name = "btnSetNtp";
            this.btnSetNtp.Size = new System.Drawing.Size(43, 23);
            this.btnSetNtp.TabIndex = 4;
            this.btnSetNtp.Text = "设置";
            this.btnSetNtp.UseVisualStyleBackColor = true;
            this.btnSetNtp.Click += new System.EventHandler(this.btnSetNtp_Click);
            // 
            // tbNtpServerip
            // 
            this.tbNtpServerip.Location = new System.Drawing.Point(86, 11);
            this.tbNtpServerip.Name = "tbNtpServerip";
            this.tbNtpServerip.Size = new System.Drawing.Size(177, 21);
            this.tbNtpServerip.TabIndex = 3;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 14);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 12);
            this.label26.TabIndex = 2;
            this.label26.Text = "NTPServerIP：";
            // 
            // rbisntpfalse
            // 
            this.rbisntpfalse.AutoSize = true;
            this.rbisntpfalse.Location = new System.Drawing.Point(311, 14);
            this.rbisntpfalse.Name = "rbisntpfalse";
            this.rbisntpfalse.Size = new System.Drawing.Size(47, 16);
            this.rbisntpfalse.TabIndex = 1;
            this.rbisntpfalse.TabStop = true;
            this.rbisntpfalse.Text = "禁用";
            this.rbisntpfalse.UseVisualStyleBackColor = true;
            // 
            // rbntptrue
            // 
            this.rbntptrue.AutoSize = true;
            this.rbntptrue.Location = new System.Drawing.Point(379, 15);
            this.rbntptrue.Name = "rbntptrue";
            this.rbntptrue.Size = new System.Drawing.Size(47, 16);
            this.rbntptrue.TabIndex = 0;
            this.rbntptrue.TabStop = true;
            this.rbntptrue.Text = "启用";
            this.rbntptrue.UseVisualStyleBackColor = true;
            // 
            // btniso183kblfset
            // 
            this.btniso183kblfset.Location = new System.Drawing.Point(70, 44);
            this.btniso183kblfset.Name = "btniso183kblfset";
            this.btniso183kblfset.Size = new System.Drawing.Size(41, 23);
            this.btniso183kblfset.TabIndex = 46;
            this.btniso183kblfset.Text = "设置";
            this.btniso183kblfset.UseVisualStyleBackColor = true;
            this.btniso183kblfset.Click += new System.EventHandler(this.btniso183kblfset_Click);
            // 
            // btniso183kblfget
            // 
            this.btniso183kblfget.Location = new System.Drawing.Point(12, 44);
            this.btniso183kblfget.Name = "btniso183kblfget";
            this.btniso183kblfget.Size = new System.Drawing.Size(41, 23);
            this.btniso183kblfget.TabIndex = 45;
            this.btniso183kblfget.Text = "获取";
            this.btniso183kblfget.UseVisualStyleBackColor = true;
            this.btniso183kblfget.Click += new System.EventHandler(this.btniso183kblfget_Click);
            // 
            // tbIso183kblf
            // 
            this.tbIso183kblf.Location = new System.Drawing.Point(13, 20);
            this.tbIso183kblf.Name = "tbIso183kblf";
            this.tbIso183kblf.Size = new System.Drawing.Size(98, 21);
            this.tbIso183kblf.TabIndex = 47;
            // 
            // cbbwritemode
            // 
            this.cbbwritemode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbwritemode.FormattingEnabled = true;
            this.cbbwritemode.Items.AddRange(new object[] {
            "字写",
            "块写"});
            this.cbbwritemode.Location = new System.Drawing.Point(20, 17);
            this.cbbwritemode.Name = "cbbwritemode";
            this.cbbwritemode.Size = new System.Drawing.Size(95, 20);
            this.cbbwritemode.TabIndex = 2;
            // 
            // btnGetWriteMode
            // 
            this.btnGetWriteMode.Location = new System.Drawing.Point(16, 43);
            this.btnGetWriteMode.Name = "btnGetWriteMode";
            this.btnGetWriteMode.Size = new System.Drawing.Size(44, 23);
            this.btnGetWriteMode.TabIndex = 28;
            this.btnGetWriteMode.Text = "获取";
            this.btnGetWriteMode.UseVisualStyleBackColor = true;
            this.btnGetWriteMode.Click += new System.EventHandler(this.btnGetWriteMode_Click);
            // 
            // btnSetWriteMode
            // 
            this.btnSetWriteMode.Location = new System.Drawing.Point(74, 43);
            this.btnSetWriteMode.Name = "btnSetWriteMode";
            this.btnSetWriteMode.Size = new System.Drawing.Size(41, 23);
            this.btnSetWriteMode.TabIndex = 29;
            this.btnSetWriteMode.Text = "设置";
            this.btnSetWriteMode.UseVisualStyleBackColor = true;
            this.btnSetWriteMode.Click += new System.EventHandler(this.btnSetWriteMode_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btnsetdataantunique);
            this.groupBox7.Controls.Add(this.btngetdataantunique);
            this.groupBox7.Controls.Add(this.rbtagdataisnoant);
            this.groupBox7.Controls.Add(this.rbtagdataisant);
            this.groupBox7.Location = new System.Drawing.Point(12, 333);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(116, 81);
            this.groupBox7.TabIndex = 52;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "数据-天线唯一性";
            // 
            // btnsetdataantunique
            // 
            this.btnsetdataantunique.Location = new System.Drawing.Point(63, 52);
            this.btnsetdataantunique.Name = "btnsetdataantunique";
            this.btnsetdataantunique.Size = new System.Drawing.Size(40, 23);
            this.btnsetdataantunique.TabIndex = 54;
            this.btnsetdataantunique.Text = "设置";
            this.btnsetdataantunique.UseVisualStyleBackColor = true;
            this.btnsetdataantunique.Click += new System.EventHandler(this.btnsetdataantunique_Click);
            // 
            // btngetdataantunique
            // 
            this.btngetdataantunique.Location = new System.Drawing.Point(14, 52);
            this.btngetdataantunique.Name = "btngetdataantunique";
            this.btngetdataantunique.Size = new System.Drawing.Size(43, 23);
            this.btngetdataantunique.TabIndex = 53;
            this.btngetdataantunique.Text = "获取";
            this.btngetdataantunique.UseVisualStyleBackColor = true;
            this.btngetdataantunique.Click += new System.EventHandler(this.btngetdataantunique_Click);
            // 
            // rbtagdataisnoant
            // 
            this.rbtagdataisnoant.AutoSize = true;
            this.rbtagdataisnoant.Location = new System.Drawing.Point(52, 27);
            this.rbtagdataisnoant.Name = "rbtagdataisnoant";
            this.rbtagdataisnoant.Size = new System.Drawing.Size(59, 16);
            this.rbtagdataisnoant.TabIndex = 1;
            this.rbtagdataisnoant.TabStop = true;
            this.rbtagdataisnoant.Text = "不唯一";
            this.rbtagdataisnoant.UseVisualStyleBackColor = true;
            // 
            // rbtagdataisant
            // 
            this.rbtagdataisant.AutoSize = true;
            this.rbtagdataisant.Location = new System.Drawing.Point(6, 27);
            this.rbtagdataisant.Name = "rbtagdataisant";
            this.rbtagdataisant.Size = new System.Drawing.Size(47, 16);
            this.rbtagdataisant.TabIndex = 0;
            this.rbtagdataisant.TabStop = true;
            this.rbtagdataisant.Text = "唯一";
            this.rbtagdataisant.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btnsetdataemdunique);
            this.groupBox10.Controls.Add(this.btngetdataemdunique);
            this.groupBox10.Controls.Add(this.rbtagdataisnoemd);
            this.groupBox10.Controls.Add(this.rbtagdataisemd);
            this.groupBox10.Location = new System.Drawing.Point(160, 333);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(113, 81);
            this.groupBox10.TabIndex = 53;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "数据-附加数据唯一性";
            // 
            // btnsetdataemdunique
            // 
            this.btnsetdataemdunique.Location = new System.Drawing.Point(68, 52);
            this.btnsetdataemdunique.Name = "btnsetdataemdunique";
            this.btnsetdataemdunique.Size = new System.Drawing.Size(38, 23);
            this.btnsetdataemdunique.TabIndex = 54;
            this.btnsetdataemdunique.Text = "设置";
            this.btnsetdataemdunique.UseVisualStyleBackColor = true;
            this.btnsetdataemdunique.Click += new System.EventHandler(this.btnsetdataemdunique_Click);
            // 
            // btngetdataemdunique
            // 
            this.btngetdataemdunique.Location = new System.Drawing.Point(11, 52);
            this.btngetdataemdunique.Name = "btngetdataemdunique";
            this.btngetdataemdunique.Size = new System.Drawing.Size(42, 23);
            this.btngetdataemdunique.TabIndex = 53;
            this.btngetdataemdunique.Text = "获取";
            this.btngetdataemdunique.UseVisualStyleBackColor = true;
            this.btngetdataemdunique.Click += new System.EventHandler(this.btngetdataemdunique_Click);
            // 
            // rbtagdataisnoemd
            // 
            this.rbtagdataisnoemd.AutoSize = true;
            this.rbtagdataisnoemd.Location = new System.Drawing.Point(50, 27);
            this.rbtagdataisnoemd.Name = "rbtagdataisnoemd";
            this.rbtagdataisnoemd.Size = new System.Drawing.Size(59, 16);
            this.rbtagdataisnoemd.TabIndex = 1;
            this.rbtagdataisnoemd.TabStop = true;
            this.rbtagdataisnoemd.Text = "不唯一";
            this.rbtagdataisnoemd.UseVisualStyleBackColor = true;
            // 
            // rbtagdataisemd
            // 
            this.rbtagdataisemd.AutoSize = true;
            this.rbtagdataisemd.Location = new System.Drawing.Point(6, 27);
            this.rbtagdataisemd.Name = "rbtagdataisemd";
            this.rbtagdataisemd.Size = new System.Drawing.Size(47, 16);
            this.rbtagdataisemd.TabIndex = 0;
            this.rbtagdataisemd.TabStop = true;
            this.rbtagdataisemd.Text = "唯一";
            this.rbtagdataisemd.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btnsetdatarechrssi);
            this.groupBox11.Controls.Add(this.btngetdatarechrssi);
            this.groupBox11.Controls.Add(this.rbtagdataisnorecrssi);
            this.groupBox11.Controls.Add(this.rbtagdataisrecrssi);
            this.groupBox11.Location = new System.Drawing.Point(307, 333);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(113, 81);
            this.groupBox11.TabIndex = 54;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "数据-记录最高RSSI";
            // 
            // btnsetdatarechrssi
            // 
            this.btnsetdatarechrssi.Location = new System.Drawing.Point(65, 52);
            this.btnsetdatarechrssi.Name = "btnsetdatarechrssi";
            this.btnsetdatarechrssi.Size = new System.Drawing.Size(41, 23);
            this.btnsetdatarechrssi.TabIndex = 54;
            this.btnsetdatarechrssi.Text = "设置";
            this.btnsetdatarechrssi.UseVisualStyleBackColor = true;
            this.btnsetdatarechrssi.Click += new System.EventHandler(this.btnsetdatarechrssi_Click);
            // 
            // btngetdatarechrssi
            // 
            this.btngetdatarechrssi.Location = new System.Drawing.Point(6, 52);
            this.btngetdatarechrssi.Name = "btngetdatarechrssi";
            this.btngetdatarechrssi.Size = new System.Drawing.Size(44, 23);
            this.btngetdatarechrssi.TabIndex = 53;
            this.btngetdatarechrssi.Text = "获取";
            this.btngetdatarechrssi.UseVisualStyleBackColor = true;
            this.btngetdatarechrssi.Click += new System.EventHandler(this.btngetdatarechrssi_Click);
            // 
            // rbtagdataisnorecrssi
            // 
            this.rbtagdataisnorecrssi.AutoSize = true;
            this.rbtagdataisnorecrssi.Location = new System.Drawing.Point(50, 27);
            this.rbtagdataisnorecrssi.Name = "rbtagdataisnorecrssi";
            this.rbtagdataisnorecrssi.Size = new System.Drawing.Size(59, 16);
            this.rbtagdataisnorecrssi.TabIndex = 1;
            this.rbtagdataisnorecrssi.TabStop = true;
            this.rbtagdataisnorecrssi.Text = "不记录";
            this.rbtagdataisnorecrssi.UseVisualStyleBackColor = true;
            // 
            // rbtagdataisrecrssi
            // 
            this.rbtagdataisrecrssi.AutoSize = true;
            this.rbtagdataisrecrssi.Location = new System.Drawing.Point(6, 27);
            this.rbtagdataisrecrssi.Name = "rbtagdataisrecrssi";
            this.rbtagdataisrecrssi.Size = new System.Drawing.Size(47, 16);
            this.rbtagdataisrecrssi.TabIndex = 0;
            this.rbtagdataisrecrssi.TabStop = true;
            this.rbtagdataisrecrssi.Text = "记录";
            this.rbtagdataisrecrssi.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btnsetgen2tari);
            this.groupBox12.Controls.Add(this.btngetgen2tari);
            this.groupBox12.Controls.Add(this.cbbgen2tari);
            this.groupBox12.Location = new System.Drawing.Point(307, 249);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(113, 72);
            this.groupBox12.TabIndex = 55;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Gen2Tari";
            // 
            // btnsetgen2tari
            // 
            this.btnsetgen2tari.Location = new System.Drawing.Point(65, 43);
            this.btnsetgen2tari.Name = "btnsetgen2tari";
            this.btnsetgen2tari.Size = new System.Drawing.Size(41, 23);
            this.btnsetgen2tari.TabIndex = 56;
            this.btnsetgen2tari.Text = "设置";
            this.btnsetgen2tari.UseVisualStyleBackColor = true;
            this.btnsetgen2tari.Click += new System.EventHandler(this.btnsetgen2tari_Click);
            // 
            // btngetgen2tari
            // 
            this.btngetgen2tari.Location = new System.Drawing.Point(6, 43);
            this.btngetgen2tari.Name = "btngetgen2tari";
            this.btngetgen2tari.Size = new System.Drawing.Size(44, 23);
            this.btngetgen2tari.TabIndex = 55;
            this.btngetgen2tari.Text = "获取";
            this.btngetgen2tari.UseVisualStyleBackColor = true;
            this.btngetgen2tari.Click += new System.EventHandler(this.btngetgen2tari_Click);
            // 
            // cbbgen2tari
            // 
            this.cbbgen2tari.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbgen2tari.FormattingEnabled = true;
            this.cbbgen2tari.Items.AddRange(new object[] {
            "25微妙",
            "12.5微妙",
            "6.25微妙"});
            this.cbbgen2tari.Location = new System.Drawing.Point(7, 17);
            this.cbbgen2tari.Name = "cbbgen2tari";
            this.cbbgen2tari.Size = new System.Drawing.Size(99, 20);
            this.cbbgen2tari.TabIndex = 0;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.tbbytesreadflash);
            this.groupBox13.Controls.Add(this.label32);
            this.groupBox13.Controls.Add(this.btnreadflash);
            this.groupBox13.Controls.Add(this.btnflashwrtie);
            this.groupBox13.Controls.Add(this.tbfwaddress);
            this.groupBox13.Controls.Add(this.label30);
            this.groupBox13.Controls.Add(this.tbfwdata);
            this.groupBox13.Controls.Add(this.label29);
            this.groupBox13.Location = new System.Drawing.Point(15, 504);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(714, 38);
            this.groupBox13.TabIndex = 56;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "保存私有数据";
            // 
            // tbbytesreadflash
            // 
            this.tbbytesreadflash.Location = new System.Drawing.Point(547, 12);
            this.tbbytesreadflash.Name = "tbbytesreadflash";
            this.tbbytesreadflash.Size = new System.Drawing.Size(55, 21);
            this.tbbytesreadflash.TabIndex = 8;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(503, 17);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 12);
            this.label32.TabIndex = 7;
            this.label32.Text = "字节数";
            // 
            // btnreadflash
            // 
            this.btnreadflash.Location = new System.Drawing.Point(608, 12);
            this.btnreadflash.Name = "btnreadflash";
            this.btnreadflash.Size = new System.Drawing.Size(46, 23);
            this.btnreadflash.TabIndex = 6;
            this.btnreadflash.Text = "读取";
            this.btnreadflash.UseVisualStyleBackColor = true;
            this.btnreadflash.Click += new System.EventHandler(this.btnreadflash_Click);
            // 
            // btnflashwrtie
            // 
            this.btnflashwrtie.Location = new System.Drawing.Point(660, 12);
            this.btnflashwrtie.Name = "btnflashwrtie";
            this.btnflashwrtie.Size = new System.Drawing.Size(46, 23);
            this.btnflashwrtie.TabIndex = 5;
            this.btnflashwrtie.Text = "写入";
            this.btnflashwrtie.UseVisualStyleBackColor = true;
            this.btnflashwrtie.Click += new System.EventHandler(this.btnflashwrtie_Click);
            // 
            // tbfwaddress
            // 
            this.tbfwaddress.Location = new System.Drawing.Point(445, 13);
            this.tbfwaddress.Name = "tbfwaddress";
            this.tbfwaddress.Size = new System.Drawing.Size(55, 21);
            this.tbfwaddress.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(415, 17);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 12);
            this.label30.TabIndex = 2;
            this.label30.Text = "地址";
            // 
            // tbfwdata
            // 
            this.tbfwdata.Location = new System.Drawing.Point(44, 13);
            this.tbfwdata.Name = "tbfwdata";
            this.tbfwdata.Size = new System.Drawing.Size(357, 21);
            this.tbfwdata.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(11, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "数据";
            // 
            // btngetgen2target
            // 
            this.btngetgen2target.Location = new System.Drawing.Point(13, 45);
            this.btngetgen2target.Name = "btngetgen2target";
            this.btngetgen2target.Size = new System.Drawing.Size(44, 23);
            this.btngetgen2target.TabIndex = 48;
            this.btngetgen2target.Text = "获取";
            this.btngetgen2target.UseVisualStyleBackColor = true;
            this.btngetgen2target.Click += new System.EventHandler(this.btngetgen2target_Click);
            // 
            // btnsetgen2target
            // 
            this.btnsetgen2target.Location = new System.Drawing.Point(63, 45);
            this.btnsetgen2target.Name = "btnsetgen2target";
            this.btnsetgen2target.Size = new System.Drawing.Size(41, 23);
            this.btnsetgen2target.TabIndex = 49;
            this.btnsetgen2target.Text = "设置";
            this.btnsetgen2target.UseVisualStyleBackColor = true;
            this.btnsetgen2target.Click += new System.EventHandler(this.btnsetgen2target_Click);
            // 
            // cbbgen2target
            // 
            this.cbbgen2target.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbgen2target.FormattingEnabled = true;
            this.cbbgen2target.Items.AddRange(new object[] {
            "A",
            "B",
            "A-B",
            "B-A"});
            this.cbbgen2target.Location = new System.Drawing.Point(14, 18);
            this.cbbgen2target.Name = "cbbgen2target";
            this.cbbgen2target.Size = new System.Drawing.Size(89, 20);
            this.cbbgen2target.TabIndex = 50;
            // 
            // cbbGen2Q
            // 
            this.cbbGen2Q.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbGen2Q.FormattingEnabled = true;
            this.cbbGen2Q.Items.AddRange(new object[] {
            "自动",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbbGen2Q.Location = new System.Drawing.Point(10, 17);
            this.cbbGen2Q.Name = "cbbGen2Q";
            this.cbbGen2Q.Size = new System.Drawing.Size(91, 20);
            this.cbbGen2Q.TabIndex = 19;
            // 
            // cbbsession
            // 
            this.cbbsession.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbsession.FormattingEnabled = true;
            this.cbbsession.Items.AddRange(new object[] {
            "Session0",
            "Session1",
            "Session2",
            "Session3"});
            this.cbbsession.Location = new System.Drawing.Point(10, 18);
            this.cbbsession.Name = "cbbsession";
            this.cbbsession.Size = new System.Drawing.Size(90, 20);
            this.cbbsession.TabIndex = 7;
            // 
            // btngettemperature
            // 
            this.btngettemperature.Location = new System.Drawing.Point(75, 10);
            this.btngettemperature.Name = "btngettemperature";
            this.btngettemperature.Size = new System.Drawing.Size(44, 23);
            this.btngettemperature.TabIndex = 57;
            this.btngettemperature.Text = "获取";
            this.btngettemperature.UseVisualStyleBackColor = true;
            this.btngettemperature.Click += new System.EventHandler(this.btngettemperature_Click);
            // 
            // labtemperature
            // 
            this.labtemperature.AutoSize = true;
            this.labtemperature.Location = new System.Drawing.Point(11, 18);
            this.labtemperature.Name = "labtemperature";
            this.labtemperature.Size = new System.Drawing.Size(17, 12);
            this.labtemperature.TabIndex = 59;
            this.labtemperature.Text = "--";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.cbbgen2target);
            this.groupBox15.Controls.Add(this.btngetgen2target);
            this.groupBox15.Controls.Add(this.btnsetgen2target);
            this.groupBox15.Location = new System.Drawing.Point(12, 248);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(116, 73);
            this.groupBox15.TabIndex = 60;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Gen2Target";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.btnGetWriteMode);
            this.groupBox16.Controls.Add(this.cbbwritemode);
            this.groupBox16.Controls.Add(this.btnSetWriteMode);
            this.groupBox16.Location = new System.Drawing.Point(449, 173);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(126, 73);
            this.groupBox16.TabIndex = 61;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "gen2写模式";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.btngetgen2encode);
            this.groupBox17.Controls.Add(this.cbbgen2encode);
            this.groupBox17.Controls.Add(this.btnsetgen2encode);
            this.groupBox17.Location = new System.Drawing.Point(160, 248);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(112, 73);
            this.groupBox17.TabIndex = 62;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "gen2编码";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.cbbgen2blf);
            this.groupBox18.Controls.Add(this.btngetgen2blf);
            this.groupBox18.Controls.Add(this.btnsetgen2blf);
            this.groupBox18.Location = new System.Drawing.Point(602, 173);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(111, 73);
            this.groupBox18.TabIndex = 63;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "gen2BLF";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.btngen2sessset);
            this.groupBox19.Controls.Add(this.btnge2sessget);
            this.groupBox19.Controls.Add(this.cbbsession);
            this.groupBox19.ForeColor = System.Drawing.Color.Red;
            this.groupBox19.Location = new System.Drawing.Point(15, 173);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(113, 73);
            this.groupBox19.TabIndex = 64;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "gen2Session";
            // 
            // btngen2sessset
            // 
            this.btngen2sessset.Location = new System.Drawing.Point(60, 45);
            this.btngen2sessset.Name = "btngen2sessset";
            this.btngen2sessset.Size = new System.Drawing.Size(41, 23);
            this.btngen2sessset.TabIndex = 65;
            this.btngen2sessset.Text = "设置";
            this.btngen2sessset.UseVisualStyleBackColor = true;
            this.btngen2sessset.Click += new System.EventHandler(this.btngen2sessset_Click);
            // 
            // btnge2sessget
            // 
            this.btnge2sessget.Location = new System.Drawing.Point(9, 45);
            this.btnge2sessget.Name = "btnge2sessget";
            this.btnge2sessget.Size = new System.Drawing.Size(41, 23);
            this.btnge2sessget.TabIndex = 65;
            this.btnge2sessget.Text = "获取";
            this.btnge2sessget.UseVisualStyleBackColor = true;
            this.btnge2sessget.Click += new System.EventHandler(this.btnge2sessget_Click);
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.btngen2qset);
            this.groupBox20.Controls.Add(this.btngen2qget);
            this.groupBox20.Controls.Add(this.cbbGen2Q);
            this.groupBox20.Location = new System.Drawing.Point(307, 173);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(113, 73);
            this.groupBox20.TabIndex = 65;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "gen2Qval";
            // 
            // btngen2qset
            // 
            this.btngen2qset.Location = new System.Drawing.Point(60, 45);
            this.btngen2qset.Name = "btngen2qset";
            this.btngen2qset.Size = new System.Drawing.Size(41, 23);
            this.btngen2qset.TabIndex = 65;
            this.btngen2qset.Text = "设置";
            this.btngen2qset.UseVisualStyleBackColor = true;
            this.btngen2qset.Click += new System.EventHandler(this.btngen2qset_Click);
            // 
            // btngen2qget
            // 
            this.btngen2qget.Location = new System.Drawing.Point(9, 45);
            this.btngen2qget.Name = "btngen2qget";
            this.btngen2qget.Size = new System.Drawing.Size(41, 23);
            this.btngen2qget.TabIndex = 65;
            this.btngen2qget.Text = "获取";
            this.btngen2qget.UseVisualStyleBackColor = true;
            this.btngen2qget.Click += new System.EventHandler(this.btngen2qget_Click);
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.btndetantsset);
            this.groupBox21.Controls.Add(this.btndetantsget);
            this.groupBox21.Controls.Add(this.cbbdetectants);
            this.groupBox21.ForeColor = System.Drawing.Color.Red;
            this.groupBox21.Location = new System.Drawing.Point(160, 173);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(113, 73);
            this.groupBox21.TabIndex = 66;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "天线检测设置";
            // 
            // btndetantsset
            // 
            this.btndetantsset.Location = new System.Drawing.Point(60, 45);
            this.btndetantsset.Name = "btndetantsset";
            this.btndetantsset.Size = new System.Drawing.Size(41, 23);
            this.btndetantsset.TabIndex = 65;
            this.btndetantsset.Text = "设置";
            this.btndetantsset.UseVisualStyleBackColor = true;
            this.btndetantsset.Click += new System.EventHandler(this.btndetantsset_Click);
            // 
            // btndetantsget
            // 
            this.btndetantsget.Location = new System.Drawing.Point(9, 45);
            this.btndetantsget.Name = "btndetantsget";
            this.btndetantsget.Size = new System.Drawing.Size(41, 23);
            this.btndetantsget.TabIndex = 65;
            this.btndetantsget.Text = "获取";
            this.btndetantsget.UseVisualStyleBackColor = true;
            this.btndetantsget.Click += new System.EventHandler(this.btndetantsget_Click);
            // 
            // cbbdetectants
            // 
            this.cbbdetectants.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbdetectants.FormattingEnabled = true;
            this.cbbdetectants.Items.AddRange(new object[] {
            "检测天线",
            "不检测天线"});
            this.cbbdetectants.Location = new System.Drawing.Point(10, 17);
            this.cbbdetectants.Name = "cbbdetectants";
            this.cbbdetectants.Size = new System.Drawing.Size(91, 20);
            this.cbbdetectants.TabIndex = 19;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnsetmel);
            this.groupBox1.Controls.Add(this.btngetmel);
            this.groupBox1.Controls.Add(this.cbbMaxEPCLength);
            this.groupBox1.Location = new System.Drawing.Point(738, 173);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(113, 73);
            this.groupBox1.TabIndex = 67;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "最大epc长度设置";
            // 
            // btnsetmel
            // 
            this.btnsetmel.Location = new System.Drawing.Point(64, 41);
            this.btnsetmel.Name = "btnsetmel";
            this.btnsetmel.Size = new System.Drawing.Size(38, 23);
            this.btnsetmel.TabIndex = 32;
            this.btnsetmel.Text = "设置";
            this.btnsetmel.UseVisualStyleBackColor = true;
            this.btnsetmel.Click += new System.EventHandler(this.btnsetmel_Click);
            // 
            // btngetmel
            // 
            this.btngetmel.Location = new System.Drawing.Point(7, 41);
            this.btngetmel.Name = "btngetmel";
            this.btngetmel.Size = new System.Drawing.Size(44, 23);
            this.btngetmel.TabIndex = 31;
            this.btngetmel.Text = "获取";
            this.btngetmel.UseVisualStyleBackColor = true;
            this.btngetmel.Click += new System.EventHandler(this.btngetmel_Click);
            // 
            // cbbMaxEPCLength
            // 
            this.cbbMaxEPCLength.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbMaxEPCLength.FormattingEnabled = true;
            this.cbbMaxEPCLength.Items.AddRange(new object[] {
            "96 bits",
            "496bits"});
            this.cbbMaxEPCLength.Location = new System.Drawing.Point(9, 15);
            this.cbbMaxEPCLength.Name = "cbbMaxEPCLength";
            this.cbbMaxEPCLength.Size = new System.Drawing.Size(92, 20);
            this.cbbMaxEPCLength.TabIndex = 30;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.gbantvswr);
            this.groupBox22.Controls.Add(this.groupBox4);
            this.groupBox22.ForeColor = System.Drawing.Color.Red;
            this.groupBox22.Location = new System.Drawing.Point(450, 39);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(406, 130);
            this.groupBox22.TabIndex = 68;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "天线设置";
            // 
            // gbantvswr
            // 
            this.gbantvswr.Controls.Add(this.btnvswrdetect);
            this.gbantvswr.Controls.Add(this.tbant4vswr);
            this.gbantvswr.Controls.Add(this.tbant3vswr);
            this.gbantvswr.Controls.Add(this.tbant2vswr);
            this.gbantvswr.Controls.Add(this.tbant1vswr);
            this.gbantvswr.Controls.Add(this.label2);
            this.gbantvswr.Controls.Add(this.label10);
            this.gbantvswr.Controls.Add(this.label19);
            this.gbantvswr.Controls.Add(this.label20);
            this.gbantvswr.Location = new System.Drawing.Point(6, 86);
            this.gbantvswr.Name = "gbantvswr";
            this.gbantvswr.Size = new System.Drawing.Size(397, 37);
            this.gbantvswr.TabIndex = 70;
            this.gbantvswr.TabStop = false;
            this.gbantvswr.Text = "天线驻波比检测";
            // 
            // btnvswrdetect
            // 
            this.btnvswrdetect.Location = new System.Drawing.Point(353, 11);
            this.btnvswrdetect.Name = "btnvswrdetect";
            this.btnvswrdetect.Size = new System.Drawing.Size(40, 23);
            this.btnvswrdetect.TabIndex = 32;
            this.btnvswrdetect.Text = "检测";
            this.btnvswrdetect.UseVisualStyleBackColor = true;
            this.btnvswrdetect.Click += new System.EventHandler(this.btnvswrdetect_Click);
            // 
            // tbant4vswr
            // 
            this.tbant4vswr.Location = new System.Drawing.Point(299, 12);
            this.tbant4vswr.Name = "tbant4vswr";
            this.tbant4vswr.Size = new System.Drawing.Size(37, 21);
            this.tbant4vswr.TabIndex = 31;
            // 
            // tbant3vswr
            // 
            this.tbant3vswr.Location = new System.Drawing.Point(216, 12);
            this.tbant3vswr.Name = "tbant3vswr";
            this.tbant3vswr.Size = new System.Drawing.Size(37, 21);
            this.tbant3vswr.TabIndex = 30;
            // 
            // tbant2vswr
            // 
            this.tbant2vswr.Location = new System.Drawing.Point(129, 12);
            this.tbant2vswr.Name = "tbant2vswr";
            this.tbant2vswr.Size = new System.Drawing.Size(37, 21);
            this.tbant2vswr.TabIndex = 29;
            // 
            // tbant1vswr
            // 
            this.tbant1vswr.Location = new System.Drawing.Point(45, 12);
            this.tbant1vswr.Name = "tbant1vswr";
            this.tbant1vswr.Size = new System.Drawing.Size(37, 21);
            this.tbant1vswr.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(259, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 28;
            this.label2.Text = "天线４";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(172, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 27;
            this.label10.Text = "天线３";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(87, 18);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 12);
            this.label19.TabIndex = 26;
            this.label19.Text = "天线２";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 18);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 12);
            this.label20.TabIndex = 24;
            this.label20.Text = "天线１";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbIso183kblf);
            this.groupBox2.Controls.Add(this.btniso183kblfget);
            this.groupBox2.Controls.Add(this.btniso183kblfset);
            this.groupBox2.Location = new System.Drawing.Point(453, 249);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(122, 73);
            this.groupBox2.TabIndex = 69;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Iso180006bBLF";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.labtemperature);
            this.groupBox14.Controls.Add(this.btngettemperature);
            this.groupBox14.Location = new System.Drawing.Point(602, 549);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(127, 34);
            this.groupBox14.TabIndex = 70;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "温度";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.cbbinvmode);
            this.groupBox24.Controls.Add(this.btngetinvmode);
            this.groupBox24.Controls.Add(this.btnsetinvmode);
            this.groupBox24.Location = new System.Drawing.Point(12, 430);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(116, 73);
            this.groupBox24.TabIndex = 73;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "盘存模式";
            // 
            // cbbinvmode
            // 
            this.cbbinvmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbinvmode.FormattingEnabled = true;
            this.cbbinvmode.Items.AddRange(new object[] {
            "普通模式",
            "高速模式"});
            this.cbbinvmode.Location = new System.Drawing.Point(14, 18);
            this.cbbinvmode.Name = "cbbinvmode";
            this.cbbinvmode.Size = new System.Drawing.Size(89, 20);
            this.cbbinvmode.TabIndex = 50;
            // 
            // btngetinvmode
            // 
            this.btngetinvmode.Location = new System.Drawing.Point(13, 45);
            this.btngetinvmode.Name = "btngetinvmode";
            this.btngetinvmode.Size = new System.Drawing.Size(44, 23);
            this.btngetinvmode.TabIndex = 48;
            this.btngetinvmode.Text = "获取";
            this.btngetinvmode.UseVisualStyleBackColor = true;
            this.btngetinvmode.Click += new System.EventHandler(this.btngetinvmode_Click);
            // 
            // btnsetinvmode
            // 
            this.btnsetinvmode.Location = new System.Drawing.Point(63, 45);
            this.btnsetinvmode.Name = "btnsetinvmode";
            this.btnsetinvmode.Size = new System.Drawing.Size(41, 23);
            this.btnsetinvmode.TabIndex = 49;
            this.btnsetinvmode.Text = "设置";
            this.btnsetinvmode.UseVisualStyleBackColor = true;
            this.btnsetinvmode.Click += new System.EventHandler(this.btnsetinvmode_Click);
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.cbb6bmoddepth);
            this.groupBox25.Controls.Add(this.btnget6bmoddepth);
            this.groupBox25.Controls.Add(this.btnset6bmoddepth);
            this.groupBox25.Location = new System.Drawing.Point(157, 430);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(130, 73);
            this.groupBox25.TabIndex = 74;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Iso180006b调整深度";
            // 
            // cbb6bmoddepth
            // 
            this.cbb6bmoddepth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb6bmoddepth.FormattingEnabled = true;
            this.cbb6bmoddepth.Items.AddRange(new object[] {
            "99percent",
            "11percent"});
            this.cbb6bmoddepth.Location = new System.Drawing.Point(14, 18);
            this.cbb6bmoddepth.Name = "cbb6bmoddepth";
            this.cbb6bmoddepth.Size = new System.Drawing.Size(105, 20);
            this.cbb6bmoddepth.TabIndex = 50;
            // 
            // btnget6bmoddepth
            // 
            this.btnget6bmoddepth.Location = new System.Drawing.Point(13, 45);
            this.btnget6bmoddepth.Name = "btnget6bmoddepth";
            this.btnget6bmoddepth.Size = new System.Drawing.Size(44, 23);
            this.btnget6bmoddepth.TabIndex = 48;
            this.btnget6bmoddepth.Text = "获取";
            this.btnget6bmoddepth.UseVisualStyleBackColor = true;
            this.btnget6bmoddepth.Click += new System.EventHandler(this.btnget6bmoddepth_Click);
            // 
            // btnset6bmoddepth
            // 
            this.btnset6bmoddepth.Location = new System.Drawing.Point(78, 45);
            this.btnset6bmoddepth.Name = "btnset6bmoddepth";
            this.btnset6bmoddepth.Size = new System.Drawing.Size(41, 23);
            this.btnset6bmoddepth.TabIndex = 49;
            this.btnset6bmoddepth.Text = "设置";
            this.btnset6bmoddepth.UseVisualStyleBackColor = true;
            this.btnset6bmoddepth.Click += new System.EventHandler(this.btnset6bmoddepth_Click);
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.cbb6bdelimiter);
            this.groupBox26.Controls.Add(this.btnget6bdelimiter);
            this.groupBox26.Controls.Add(this.btnset6bdelimiter);
            this.groupBox26.Location = new System.Drawing.Point(316, 430);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(143, 73);
            this.groupBox26.TabIndex = 75;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Iso180006b_Delimiter";
            // 
            // cbb6bdelimiter
            // 
            this.cbb6bdelimiter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb6bdelimiter.FormattingEnabled = true;
            this.cbb6bdelimiter.Items.AddRange(new object[] {
            "Delimiter1",
            "Delimiter4"});
            this.cbb6bdelimiter.Location = new System.Drawing.Point(14, 18);
            this.cbb6bdelimiter.Name = "cbb6bdelimiter";
            this.cbb6bdelimiter.Size = new System.Drawing.Size(111, 20);
            this.cbb6bdelimiter.TabIndex = 50;
            // 
            // btnget6bdelimiter
            // 
            this.btnget6bdelimiter.Location = new System.Drawing.Point(13, 45);
            this.btnget6bdelimiter.Name = "btnget6bdelimiter";
            this.btnget6bdelimiter.Size = new System.Drawing.Size(44, 23);
            this.btnget6bdelimiter.TabIndex = 48;
            this.btnget6bdelimiter.Text = "获取";
            this.btnget6bdelimiter.UseVisualStyleBackColor = true;
            this.btnget6bdelimiter.Click += new System.EventHandler(this.btnget6bdelimiter_Click);
            // 
            // btnset6bdelimiter
            // 
            this.btnset6bdelimiter.Location = new System.Drawing.Point(84, 45);
            this.btnset6bdelimiter.Name = "btnset6bdelimiter";
            this.btnset6bdelimiter.Size = new System.Drawing.Size(41, 23);
            this.btnset6bdelimiter.TabIndex = 49;
            this.btnset6bdelimiter.Text = "设置";
            this.btnset6bdelimiter.UseVisualStyleBackColor = true;
            this.btnset6bdelimiter.Click += new System.EventHandler(this.btnset6bdelimiter_Click);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.tbreaderlogname);
            this.groupBox27.Controls.Add(this.btngetrdrlogname);
            this.groupBox27.Controls.Add(this.btnsetrdrlogname);
            this.groupBox27.Location = new System.Drawing.Point(480, 430);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(231, 73);
            this.groupBox27.TabIndex = 76;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "读写器名称";
            // 
            // tbreaderlogname
            // 
            this.tbreaderlogname.Location = new System.Drawing.Point(13, 18);
            this.tbreaderlogname.Name = "tbreaderlogname";
            this.tbreaderlogname.Size = new System.Drawing.Size(208, 21);
            this.tbreaderlogname.TabIndex = 50;
            // 
            // btngetrdrlogname
            // 
            this.btngetrdrlogname.Location = new System.Drawing.Point(13, 45);
            this.btngetrdrlogname.Name = "btngetrdrlogname";
            this.btngetrdrlogname.Size = new System.Drawing.Size(44, 23);
            this.btngetrdrlogname.TabIndex = 48;
            this.btngetrdrlogname.Text = "获取";
            this.btngetrdrlogname.UseVisualStyleBackColor = true;
            this.btngetrdrlogname.Click += new System.EventHandler(this.btngetrdrlogname_Click);
            // 
            // btnsetrdrlogname
            // 
            this.btnsetrdrlogname.Location = new System.Drawing.Point(180, 45);
            this.btnsetrdrlogname.Name = "btnsetrdrlogname";
            this.btnsetrdrlogname.Size = new System.Drawing.Size(41, 23);
            this.btnsetrdrlogname.TabIndex = 49;
            this.btnsetrdrlogname.Text = "设置";
            this.btnsetrdrlogname.UseVisualStyleBackColor = true;
            this.btnsetrdrlogname.Click += new System.EventHandler(this.btnsetrdrlogname_Click);
            // 
            // readerParaform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 594);
            this.Controls.Add(this.groupBox27);
            this.Controls.Add(this.groupBox26);
            this.Controls.Add(this.groupBox25);
            this.Controls.Add(this.groupBox24);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox22);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox21);
            this.Controls.Add(this.groupBox20);
            this.Controls.Add(this.groupBox19);
            this.Controls.Add(this.groupBox18);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.labmainboard);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.labmodule);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.gpipinfo);
            this.Controls.Add(this.labfirmware);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labMoudevir);
            this.Controls.Add(this.label6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "readerParaform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "参数配置";
            this.Load += new System.EventHandler(this.readerParaform_Load);
            this.gpipinfo.ResumeLayout(false);
            this.gpipinfo.PerformLayout();
            this.gpwificonf.ResumeLayout(false);
            this.gpwificonf.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.gbantvswr.ResumeLayout(false);
            this.gbantvswr.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labfirmware;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labMoudevir;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbgateway;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbsubnet;
        private System.Windows.Forms.TextBox tbipaddr;
        private System.Windows.Forms.GroupBox gpipinfo;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbant4wpwr;
        private System.Windows.Forms.TextBox tbant3wpwr;
        private System.Windows.Forms.TextBox tbant2wpwr;
        private System.Windows.Forms.TextBox tbant1wpwr;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lvhoptb;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbbregion;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnsethtb;
        private System.Windows.Forms.Button btngethtb;
        private System.Windows.Forms.Button btngetrg;
        private System.Windows.Forms.Button btnsetrg;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox cbgpi2;
        private System.Windows.Forms.CheckBox cbgpi1;
        private System.Windows.Forms.CheckBox cbgpo4;
        private System.Windows.Forms.CheckBox cbgpo3;
        private System.Windows.Forms.CheckBox cbgpo2;
        private System.Windows.Forms.CheckBox cbgpo1;
        private System.Windows.Forms.Button btngetgpi;
        private System.Windows.Forms.CheckBox cbgpi4;
        private System.Windows.Forms.CheckBox cbgpi3;
        private System.Windows.Forms.Button btnsetgpo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbMacAddr;
        private System.Windows.Forms.CheckBox cbmacset;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label labmainboard;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label labmodule;
        private System.Windows.Forms.ComboBox cbbgen2encode;
        private System.Windows.Forms.Button btngetgen2encode;
        private System.Windows.Forms.Button btnsetgen2encode;
        private System.Windows.Forms.ComboBox cbbgen2blf;
        private System.Windows.Forms.Button btngetgen2blf;
        private System.Windows.Forms.Button btnsetgen2blf;
        private System.Windows.Forms.Button btnpermsave;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox tbNtpServerip;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.RadioButton rbisntpfalse;
        private System.Windows.Forms.RadioButton rbntptrue;
        private System.Windows.Forms.Button btnSetNtp;
        private System.Windows.Forms.Button btngetntp;
        private System.Windows.Forms.Button btniso183kblfset;
        private System.Windows.Forms.Button btniso183kblfget;
        private System.Windows.Forms.TextBox tbIso183kblf;
        private System.Windows.Forms.ComboBox cbbwritemode;
        private System.Windows.Forms.Button btnGetWriteMode;
        private System.Windows.Forms.Button btnSetWriteMode;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnsetdataantunique;
        private System.Windows.Forms.Button btngetdataantunique;
        private System.Windows.Forms.RadioButton rbtagdataisnoant;
        private System.Windows.Forms.RadioButton rbtagdataisant;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btnsetdataemdunique;
        private System.Windows.Forms.Button btngetdataemdunique;
        private System.Windows.Forms.RadioButton rbtagdataisnoemd;
        private System.Windows.Forms.RadioButton rbtagdataisemd;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btnsetdatarechrssi;
        private System.Windows.Forms.Button btngetdatarechrssi;
        private System.Windows.Forms.RadioButton rbtagdataisnorecrssi;
        private System.Windows.Forms.RadioButton rbtagdataisrecrssi;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button btnsetgen2tari;
        private System.Windows.Forms.Button btngetgen2tari;
        private System.Windows.Forms.ComboBox cbbgen2tari;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnflashwrtie;
        private System.Windows.Forms.TextBox tbfwaddress;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tbfwdata;
        private System.Windows.Forms.Button btngetgen2target;
        private System.Windows.Forms.Button btnsetgen2target;
        private System.Windows.Forms.ComboBox cbbgen2target;
        private System.Windows.Forms.ComboBox cbbGen2Q;
        private System.Windows.Forms.ComboBox cbbsession;
        private System.Windows.Forms.Button btngettemperature;
        private System.Windows.Forms.Label labtemperature;
        private System.Windows.Forms.TextBox tbbytesreadflash;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button btnreadflash;
        private System.Windows.Forms.RadioButton rbnettypewifi;
        private System.Windows.Forms.RadioButton rbnettypeeth;
        private System.Windows.Forms.GroupBox gpwificonf;
        private System.Windows.Forms.TextBox tbwifissid;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox cbbwifiauth;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button btnipset;
        private System.Windows.Forms.Button btnipget;
        private System.Windows.Forms.TextBox tbwifikey;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Button btngen2sessset;
        private System.Windows.Forms.Button btnge2sessget;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Button btngen2qset;
        private System.Windows.Forms.Button btngen2qget;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Button btndetantsset;
        private System.Windows.Forms.Button btndetantsget;
        private System.Windows.Forms.ComboBox cbbdetectants;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnsetmel;
        private System.Windows.Forms.Button btngetmel;
        private System.Windows.Forms.ComboBox cbbMaxEPCLength;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Button btnpwrset;
        private System.Windows.Forms.Button btnpwrget;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbkeytype;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.ComboBox cbbinvmode;
        private System.Windows.Forms.Button btngetinvmode;
        private System.Windows.Forms.Button btnsetinvmode;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.ComboBox cbb6bmoddepth;
        private System.Windows.Forms.Button btnget6bmoddepth;
        private System.Windows.Forms.Button btnset6bmoddepth;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.ComboBox cbb6bdelimiter;
        private System.Windows.Forms.Button btnget6bdelimiter;
        private System.Windows.Forms.Button btnset6bdelimiter;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.TextBox tbreaderlogname;
        private System.Windows.Forms.Button btngetrdrlogname;
        private System.Windows.Forms.Button btnsetrdrlogname;
        private System.Windows.Forms.GroupBox gbantvswr;
        private System.Windows.Forms.TextBox tbant4vswr;
        private System.Windows.Forms.TextBox tbant3vswr;
        private System.Windows.Forms.TextBox tbant2vswr;
        private System.Windows.Forms.TextBox tbant1vswr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbant4rpwr;
        private System.Windows.Forms.TextBox tbant3rpwr;
        private System.Windows.Forms.TextBox tbant1rpwr;
        private System.Windows.Forms.TextBox tbant2rpwr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnvswrdetect;
        private System.Windows.Forms.CheckBox allcheckBox;
        private System.Windows.Forms.Button btnerasesave;
    }
}