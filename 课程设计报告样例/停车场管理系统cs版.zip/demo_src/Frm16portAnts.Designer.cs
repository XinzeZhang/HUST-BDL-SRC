﻿namespace ModuleReaderManager
{
    partial class Frm16portAnts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbant1 = new System.Windows.Forms.CheckBox();
            this.cbant2 = new System.Windows.Forms.CheckBox();
            this.cbant3 = new System.Windows.Forms.CheckBox();
            this.cbant4 = new System.Windows.Forms.CheckBox();
            this.cbant5 = new System.Windows.Forms.CheckBox();
            this.cbant6 = new System.Windows.Forms.CheckBox();
            this.cbant7 = new System.Windows.Forms.CheckBox();
            this.cbant8 = new System.Windows.Forms.CheckBox();
            this.cbant9 = new System.Windows.Forms.CheckBox();
            this.cbant10 = new System.Windows.Forms.CheckBox();
            this.cbant11 = new System.Windows.Forms.CheckBox();
            this.cbant12 = new System.Windows.Forms.CheckBox();
            this.cbant14 = new System.Windows.Forms.CheckBox();
            this.cbant13 = new System.Windows.Forms.CheckBox();
            this.cbant16 = new System.Windows.Forms.CheckBox();
            this.cbant15 = new System.Windows.Forms.CheckBox();
            this.btnsetrp = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbpotlipx256 = new System.Windows.Forms.RadioButton();
            this.rbpotlipx64 = new System.Windows.Forms.RadioButton();
            this.rbpotl6b = new System.Windows.Forms.RadioButton();
            this.rbpotlgen2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.tbreadpwr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbwritepwr = new System.Windows.Forms.TextBox();
            this.btnsetpwr = new System.Windows.Forms.Button();
            this.rbenablerf = new System.Windows.Forms.RadioButton();
            this.rbdisablerf = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnsetrssif = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tbSession0dur = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbant1
            // 
            this.cbant1.AutoSize = true;
            this.cbant1.Location = new System.Drawing.Point(12, 30);
            this.cbant1.Name = "cbant1";
            this.cbant1.Size = new System.Drawing.Size(48, 16);
            this.cbant1.TabIndex = 0;
            this.cbant1.Text = "ant1";
            this.cbant1.UseVisualStyleBackColor = true;
            // 
            // cbant2
            // 
            this.cbant2.AutoSize = true;
            this.cbant2.Location = new System.Drawing.Point(66, 30);
            this.cbant2.Name = "cbant2";
            this.cbant2.Size = new System.Drawing.Size(48, 16);
            this.cbant2.TabIndex = 1;
            this.cbant2.Text = "ant2";
            this.cbant2.UseVisualStyleBackColor = true;
            // 
            // cbant3
            // 
            this.cbant3.AutoSize = true;
            this.cbant3.Location = new System.Drawing.Point(120, 30);
            this.cbant3.Name = "cbant3";
            this.cbant3.Size = new System.Drawing.Size(48, 16);
            this.cbant3.TabIndex = 2;
            this.cbant3.Text = "ant3";
            this.cbant3.UseVisualStyleBackColor = true;
            // 
            // cbant4
            // 
            this.cbant4.AutoSize = true;
            this.cbant4.Location = new System.Drawing.Point(172, 30);
            this.cbant4.Name = "cbant4";
            this.cbant4.Size = new System.Drawing.Size(48, 16);
            this.cbant4.TabIndex = 3;
            this.cbant4.Text = "ant4";
            this.cbant4.UseVisualStyleBackColor = true;
            // 
            // cbant5
            // 
            this.cbant5.AutoSize = true;
            this.cbant5.Location = new System.Drawing.Point(226, 30);
            this.cbant5.Name = "cbant5";
            this.cbant5.Size = new System.Drawing.Size(48, 16);
            this.cbant5.TabIndex = 4;
            this.cbant5.Text = "ant5";
            this.cbant5.UseVisualStyleBackColor = true;
            // 
            // cbant6
            // 
            this.cbant6.AutoSize = true;
            this.cbant6.Location = new System.Drawing.Point(280, 30);
            this.cbant6.Name = "cbant6";
            this.cbant6.Size = new System.Drawing.Size(48, 16);
            this.cbant6.TabIndex = 5;
            this.cbant6.Text = "ant6";
            this.cbant6.UseVisualStyleBackColor = true;
            // 
            // cbant7
            // 
            this.cbant7.AutoSize = true;
            this.cbant7.Location = new System.Drawing.Point(334, 30);
            this.cbant7.Name = "cbant7";
            this.cbant7.Size = new System.Drawing.Size(48, 16);
            this.cbant7.TabIndex = 6;
            this.cbant7.Text = "ant7";
            this.cbant7.UseVisualStyleBackColor = true;
            // 
            // cbant8
            // 
            this.cbant8.AutoSize = true;
            this.cbant8.Location = new System.Drawing.Point(388, 30);
            this.cbant8.Name = "cbant8";
            this.cbant8.Size = new System.Drawing.Size(48, 16);
            this.cbant8.TabIndex = 7;
            this.cbant8.Text = "ant8";
            this.cbant8.UseVisualStyleBackColor = true;
            // 
            // cbant9
            // 
            this.cbant9.AutoSize = true;
            this.cbant9.Location = new System.Drawing.Point(12, 69);
            this.cbant9.Name = "cbant9";
            this.cbant9.Size = new System.Drawing.Size(48, 16);
            this.cbant9.TabIndex = 8;
            this.cbant9.Text = "ant9";
            this.cbant9.UseVisualStyleBackColor = true;
            // 
            // cbant10
            // 
            this.cbant10.AutoSize = true;
            this.cbant10.Location = new System.Drawing.Point(66, 69);
            this.cbant10.Name = "cbant10";
            this.cbant10.Size = new System.Drawing.Size(54, 16);
            this.cbant10.TabIndex = 9;
            this.cbant10.Text = "ant10";
            this.cbant10.UseVisualStyleBackColor = true;
            // 
            // cbant11
            // 
            this.cbant11.AutoSize = true;
            this.cbant11.Location = new System.Drawing.Point(120, 69);
            this.cbant11.Name = "cbant11";
            this.cbant11.Size = new System.Drawing.Size(54, 16);
            this.cbant11.TabIndex = 10;
            this.cbant11.Text = "ant11";
            this.cbant11.UseVisualStyleBackColor = true;
            // 
            // cbant12
            // 
            this.cbant12.AutoSize = true;
            this.cbant12.Location = new System.Drawing.Point(172, 69);
            this.cbant12.Name = "cbant12";
            this.cbant12.Size = new System.Drawing.Size(54, 16);
            this.cbant12.TabIndex = 11;
            this.cbant12.Text = "ant12";
            this.cbant12.UseVisualStyleBackColor = true;
            // 
            // cbant14
            // 
            this.cbant14.AutoSize = true;
            this.cbant14.Location = new System.Drawing.Point(280, 69);
            this.cbant14.Name = "cbant14";
            this.cbant14.Size = new System.Drawing.Size(54, 16);
            this.cbant14.TabIndex = 12;
            this.cbant14.Text = "ant14";
            this.cbant14.UseVisualStyleBackColor = true;
            // 
            // cbant13
            // 
            this.cbant13.AutoSize = true;
            this.cbant13.Location = new System.Drawing.Point(226, 69);
            this.cbant13.Name = "cbant13";
            this.cbant13.Size = new System.Drawing.Size(54, 16);
            this.cbant13.TabIndex = 13;
            this.cbant13.Text = "ant13";
            this.cbant13.UseVisualStyleBackColor = true;
            // 
            // cbant16
            // 
            this.cbant16.AutoSize = true;
            this.cbant16.Location = new System.Drawing.Point(388, 69);
            this.cbant16.Name = "cbant16";
            this.cbant16.Size = new System.Drawing.Size(54, 16);
            this.cbant16.TabIndex = 16;
            this.cbant16.Text = "ant16";
            this.cbant16.UseVisualStyleBackColor = true;
            // 
            // cbant15
            // 
            this.cbant15.AutoSize = true;
            this.cbant15.Location = new System.Drawing.Point(334, 69);
            this.cbant15.Name = "cbant15";
            this.cbant15.Size = new System.Drawing.Size(54, 16);
            this.cbant15.TabIndex = 17;
            this.cbant15.Text = "ant15";
            this.cbant15.UseVisualStyleBackColor = true;
            // 
            // btnsetrp
            // 
            this.btnsetrp.Location = new System.Drawing.Point(198, 339);
            this.btnsetrp.Name = "btnsetrp";
            this.btnsetrp.Size = new System.Drawing.Size(75, 23);
            this.btnsetrp.TabIndex = 18;
            this.btnsetrp.Text = "确定";
            this.btnsetrp.UseVisualStyleBackColor = true;
            this.btnsetrp.Click += new System.EventHandler(this.btnselants_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbant12);
            this.groupBox1.Controls.Add(this.cbant1);
            this.groupBox1.Controls.Add(this.cbant15);
            this.groupBox1.Controls.Add(this.cbant2);
            this.groupBox1.Controls.Add(this.cbant16);
            this.groupBox1.Controls.Add(this.cbant3);
            this.groupBox1.Controls.Add(this.cbant13);
            this.groupBox1.Controls.Add(this.cbant4);
            this.groupBox1.Controls.Add(this.cbant14);
            this.groupBox1.Controls.Add(this.cbant5);
            this.groupBox1.Controls.Add(this.cbant6);
            this.groupBox1.Controls.Add(this.cbant11);
            this.groupBox1.Controls.Add(this.cbant7);
            this.groupBox1.Controls.Add(this.cbant10);
            this.groupBox1.Controls.Add(this.cbant8);
            this.groupBox1.Controls.Add(this.cbant9);
            this.groupBox1.Location = new System.Drawing.Point(12, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(447, 108);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "天线选择";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbpotlipx256);
            this.groupBox2.Controls.Add(this.rbpotlipx64);
            this.groupBox2.Controls.Add(this.rbpotl6b);
            this.groupBox2.Controls.Add(this.rbpotlgen2);
            this.groupBox2.Location = new System.Drawing.Point(12, 150);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(447, 54);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "协议选择";
            // 
            // rbpotlipx256
            // 
            this.rbpotlipx256.AutoSize = true;
            this.rbpotlipx256.Location = new System.Drawing.Point(360, 20);
            this.rbpotlipx256.Name = "rbpotlipx256";
            this.rbpotlipx256.Size = new System.Drawing.Size(59, 16);
            this.rbpotlipx256.TabIndex = 3;
            this.rbpotlipx256.TabStop = true;
            this.rbpotlipx256.Text = "ipx256";
            this.rbpotlipx256.UseVisualStyleBackColor = true;
            // 
            // rbpotlipx64
            // 
            this.rbpotlipx64.AutoSize = true;
            this.rbpotlipx64.Location = new System.Drawing.Point(253, 20);
            this.rbpotlipx64.Name = "rbpotlipx64";
            this.rbpotlipx64.Size = new System.Drawing.Size(53, 16);
            this.rbpotlipx64.TabIndex = 2;
            this.rbpotlipx64.TabStop = true;
            this.rbpotlipx64.Text = "ipx64";
            this.rbpotlipx64.UseVisualStyleBackColor = true;
            // 
            // rbpotl6b
            // 
            this.rbpotl6b.AutoSize = true;
            this.rbpotl6b.Location = new System.Drawing.Point(140, 20);
            this.rbpotl6b.Name = "rbpotl6b";
            this.rbpotl6b.Size = new System.Drawing.Size(65, 16);
            this.rbpotl6b.TabIndex = 1;
            this.rbpotl6b.TabStop = true;
            this.rbpotl6b.Text = "180006b";
            this.rbpotl6b.UseVisualStyleBackColor = true;
            // 
            // rbpotlgen2
            // 
            this.rbpotlgen2.AutoSize = true;
            this.rbpotlgen2.Location = new System.Drawing.Point(31, 20);
            this.rbpotlgen2.Name = "rbpotlgen2";
            this.rbpotlgen2.Size = new System.Drawing.Size(47, 16);
            this.rbpotlgen2.TabIndex = 0;
            this.rbpotlgen2.TabStop = true;
            this.rbpotlgen2.Text = "Gen2";
            this.rbpotlgen2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 21;
            this.label1.Text = "读功率：";
            // 
            // tbreadpwr
            // 
            this.tbreadpwr.Location = new System.Drawing.Point(78, 20);
            this.tbreadpwr.Name = "tbreadpwr";
            this.tbreadpwr.Size = new System.Drawing.Size(100, 21);
            this.tbreadpwr.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(184, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 23;
            this.label2.Text = "写功率：";
            // 
            // tbwritepwr
            // 
            this.tbwritepwr.Location = new System.Drawing.Point(243, 20);
            this.tbwritepwr.Name = "tbwritepwr";
            this.tbwritepwr.Size = new System.Drawing.Size(100, 21);
            this.tbwritepwr.TabIndex = 24;
            // 
            // btnsetpwr
            // 
            this.btnsetpwr.Location = new System.Drawing.Point(360, 18);
            this.btnsetpwr.Name = "btnsetpwr";
            this.btnsetpwr.Size = new System.Drawing.Size(75, 23);
            this.btnsetpwr.TabIndex = 25;
            this.btnsetpwr.Text = "设置";
            this.btnsetpwr.UseVisualStyleBackColor = true;
            this.btnsetpwr.Click += new System.EventHandler(this.btnsetpwr_Click);
            // 
            // rbenablerf
            // 
            this.rbenablerf.AutoSize = true;
            this.rbenablerf.Location = new System.Drawing.Point(6, 20);
            this.rbenablerf.Name = "rbenablerf";
            this.rbenablerf.Size = new System.Drawing.Size(47, 16);
            this.rbenablerf.TabIndex = 26;
            this.rbenablerf.TabStop = true;
            this.rbenablerf.Text = "启用";
            this.rbenablerf.UseVisualStyleBackColor = true;
            this.rbenablerf.CheckedChanged += new System.EventHandler(this.rbenablerf_CheckedChanged);
            // 
            // rbdisablerf
            // 
            this.rbdisablerf.AutoSize = true;
            this.rbdisablerf.Location = new System.Drawing.Point(61, 20);
            this.rbdisablerf.Name = "rbdisablerf";
            this.rbdisablerf.Size = new System.Drawing.Size(47, 16);
            this.rbdisablerf.TabIndex = 27;
            this.rbdisablerf.TabStop = true;
            this.rbdisablerf.Text = "禁用";
            this.rbdisablerf.UseVisualStyleBackColor = true;
            this.rbdisablerf.CheckedChanged += new System.EventHandler(this.rbdisablerf_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbenablerf);
            this.groupBox3.Controls.Add(this.btnsetrssif);
            this.groupBox3.Controls.Add(this.rbdisablerf);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.tbSession0dur);
            this.groupBox3.Location = new System.Drawing.Point(12, 275);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(447, 51);
            this.groupBox3.TabIndex = 28;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Rssi过滤";
            // 
            // btnsetrssif
            // 
            this.btnsetrssif.Location = new System.Drawing.Point(360, 17);
            this.btnsetrssif.Name = "btnsetrssif";
            this.btnsetrssif.Size = new System.Drawing.Size(75, 23);
            this.btnsetrssif.TabIndex = 31;
            this.btnsetrssif.Text = "设置";
            this.btnsetrssif.UseVisualStyleBackColor = true;
            this.btnsetrssif.Click += new System.EventHandler(this.btnsetrssif_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(118, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 12);
            this.label3.TabIndex = 30;
            this.label3.Text = "Session0过滤时间：";
            // 
            // tbSession0dur
            // 
            this.tbSession0dur.Location = new System.Drawing.Point(243, 19);
            this.tbSession0dur.Name = "tbSession0dur";
            this.tbSession0dur.Size = new System.Drawing.Size(100, 21);
            this.tbSession0dur.TabIndex = 29;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.tbreadpwr);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.tbwritepwr);
            this.groupBox4.Controls.Add(this.btnsetpwr);
            this.groupBox4.Location = new System.Drawing.Point(12, 211);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(447, 52);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "功率设置";
            // 
            // Frm16portAnts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 375);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnsetrp);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Frm16portAnts";
            this.Text = "16口天线设置";
            this.Load += new System.EventHandler(this.Frm16portAnts_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox cbant1;
        private System.Windows.Forms.CheckBox cbant2;
        private System.Windows.Forms.CheckBox cbant3;
        private System.Windows.Forms.CheckBox cbant4;
        private System.Windows.Forms.CheckBox cbant5;
        private System.Windows.Forms.CheckBox cbant6;
        private System.Windows.Forms.CheckBox cbant7;
        private System.Windows.Forms.CheckBox cbant8;
        private System.Windows.Forms.CheckBox cbant9;
        private System.Windows.Forms.CheckBox cbant10;
        private System.Windows.Forms.CheckBox cbant11;
        private System.Windows.Forms.CheckBox cbant12;
        private System.Windows.Forms.CheckBox cbant14;
        private System.Windows.Forms.CheckBox cbant13;
        private System.Windows.Forms.CheckBox cbant16;
        private System.Windows.Forms.CheckBox cbant15;
        private System.Windows.Forms.Button btnsetrp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbpotlipx256;
        private System.Windows.Forms.RadioButton rbpotlipx64;
        private System.Windows.Forms.RadioButton rbpotl6b;
        private System.Windows.Forms.RadioButton rbpotlgen2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbreadpwr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbwritepwr;
        private System.Windows.Forms.Button btnsetpwr;
        private System.Windows.Forms.RadioButton rbenablerf;
        private System.Windows.Forms.RadioButton rbdisablerf;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbSession0dur;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnsetrssif;
        private System.Windows.Forms.GroupBox groupBox4;
    }
}